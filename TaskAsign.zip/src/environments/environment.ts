export const environment = {
    type: "service_account",
    project_id: "mapget-355707",
    private_key_id: "cba3c129888505de45a2dd262aa89099ee66520d",
    private_key: "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQDNa6eJeNwSaLjr\nBX74Ac57g2uup1zJyyMIsJMdPgPTNmg9XS+AuSygIcscUp4h6R/alE4kJgybQZC2\nHuIe2AKFpnWtyGeE1igKzm2XWeqNtma2ubfqLhZjKstH0QQCGFrW3P7W6prcEz1e\n7yBA4dCqCBkxZlSFhDhwVglqIFnmB+QIlOQhIoAPQHJ2k5WO3Ytl8jJ7jng7UJxP\n3WYsurhDF3uMEGc/RGslDKsokXP3ymK4aG7H4SbCzwF4cgy4WKh/ZOrVx5Ix2qdj\nPVJkSd8kc0BUNh0UqlTod3vfKCH7uCztWGmGsH3idg4om4eTQKs9fwdtI238zvuq\nWVsl7gZJAgMBAAECggEAKpDAKpBMqdPhXXHKGYHmU1msGoi7hWT+YXKVSV3sVPvV\nJcIFcdrtEFFwUPIdqlEwNI6+kmb//bvcTKCholqIS0Fu6Q+5w6DMs1CLDO2o2KyP\nJBXfsjrSkMHxVXROLFD3ocYxWD9Mz4V9Fgre2BLytgjvj3jw0qnPOBfb443Ikw14\nfE/l1526jv7RZ3RRxs/Z6qXDuOFDs7aWrwM+0kqOe/Q37PnsUG8d7VyvMw8QGpXv\nxj3MUFKlwzJ5z3KFlXeQNqTPgM3JeX/OZ+DxcElsl4WulN+KeTtHvqpnGvVP6f0Z\ndHXhYPrbKHgbQvGG2TvZs1XQmGohEpdwXmFkxI59wQKBgQDnq+MiYBIxViXPdWUR\nXJ/x6cqqlLATJ9/fu0zFD5zhdBXPFbwu9M9rUj/rAkMgpzLEWsX6rSOygAIItlb2\nDuvM6dOy84TyfAEZEeA9faS713Y8wWTkSXw/zhj1qQkEaE5S93qbVLWOADB9ijD2\nbIwqHyUM4xZAG4y2Zab9jORqJQKBgQDi/g3JJyuQKTSRixCh/2MP5i4L4tqJx517\nZnTFNCodkQxO3LGyoPURYj8N0lZo2X1B/cPim7PDU3XvcnjMKXD5LUNI0cwx7yIs\nOMs5ORWM2ZNoRDSK5SljkByC8X7AFjjZQJr2QbxF27mxlrXJk9c19ILGKomRxyi6\nVojVYS0oVQKBgCvi/PkjF+8usaT2STobwNT0BAeCeUR3tkpM0gM2rPJsqkD7jhWb\nHLvo7eDYId1KryxRQdX1/KAw7bG20Qx10SeVWBw7U4EYCqE0KLWdWpqW+3gQ7srs\nPNRdd476AZJLLCM9bIWGa4pF8OmnRxU3hOnp0nv5fNqSHXrkENlRWmfdAoGAQaKA\nTfe7ivW/M45ogs8bz88Y5Wr1Ef3cNYBMp3EL9HyqeGssHqCX/CzSWqbFQZARvfEo\noO+wrPwHD/OjpjUda4+A8x9m0dF5qhvJ94PgDVgkXXPLVZYpv5Y+CEbYBabnTTp3\nFFmxnOmJ6iXP7reG9Rz8a1yFZteVmTvIWRq+OfkCgYA3ETRT2G7v22PB+cwtAsZs\nmGkGgxqscFnbp/R7lMSLK3FVPlGf8EJYWoGJIdxVnDlXSfI5VT2t4lf1JstTFeaB\nJq9RNf52vTWwYlBtpO3gRf8ZmqoANLsBoarv5aHcMS63dxIfiTdqDsrEU80w4JYB\nBlb683GWPrhM++7Gsq7c5g==\n-----END PRIVATE KEY-----\n",
    client_email: "uploadfilegoogledrive@mapget-355707.iam.gserviceaccount.com",
    client_id: "109523051523264198602",
    auth_uri: "https://accounts.google.com/o/oauth2/auth",
    token_uri: "https://oauth2.googleapis.com/token",
    auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
    client_x509_cert_url: "https://www.googleapis.com/robot/v1/metadata/x509/uploadfilegoogledrive%40mapget-355707.iam.gserviceaccount.com",
    universe_domain: "googleapis.com"
};
