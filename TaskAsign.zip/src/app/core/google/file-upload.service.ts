import { Injectable, OnInit, ViewChild } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable, Subject, single } from 'rxjs';
import { GoogleloginComponent } from 'src/app/shared/googlelogin/googlelogin.component';
import { NewMultimpleArrayCheckComponent } from 'src/app/modules/task-components/components/new-multimple-array-check/new-multimple-array-check.component';
import { JsonPipe } from '@angular/common';
declare var google: any;
@Injectable({
  providedIn: 'root'
})
export class FileUploadService implements OnInit {
  accessToken: string = '';
  googleDriveList: any[] = [];
  tokenClient: any;
  access_token: any;
  getDataFromGoogleDriveData = new Subject();
  private readonly baseUrl = 'https://www.googleapis.com/upload/drive/v3/files/';
  // @ViewChild(GoogleloginComponent) Googlelogin!: GoogleloginComponent;
  @ViewChild(NewMultimpleArrayCheckComponent) NewMultimpleArrayCheck!: NewMultimpleArrayCheckComponent;

  constructor(private http: HttpClient) {
    console.log("services component");
    if (!sessionStorage.getItem('token')?.length) {
      debugger
      this.googleAuthantication();
    } else {
      this.getFileList();
    }
  }

  setToken() {
    this.accessToken = JSON.stringify(sessionStorage.getItem('token') || '').replace(/"/g, '');
  }

  ngOnInit(): void {

  }

  downloadOnGoogleDrive() {
    const headers = new HttpHeaders()
      .set('Authorization', `Bearer ${this.accessToken}`);

    this.http.get('https://www.googleapis.com/drive/v3/files', { headers }).subscribe((googleDriveList: any) => {
      googleDriveList.files.map((res: any) => {
        debugger
        if (res.name == "moduleRoleDoc.json") {
          this.http.get(`https://www.googleapis.com/drive/v3/files/${res.id}?alt=media`, { headers, responseType: 'blob' })
            .subscribe((response: Blob) => {
              debugger
              // Create a blob URL from the file content
              const blob = new Blob([response], { type: 'application/octet-stream' });
              const url = window.URL.createObjectURL(blob);

              // Create a link element and trigger the download
              const link = document.createElement('a');
              link.href = url;
              link.download = 'moduleRoleDoc.json'; // Provide the desired file name
              document.body.appendChild(link);
              link.click();

              // Cleanup
              window.URL.revokeObjectURL(url);
            }, error => {
              console.error('Error downloading file:', error);
            });
        }
      })
    })

  }

  getFileList() {
    debugger
    this.setToken();
    const headers = new HttpHeaders()
      .set('Authorization', `Bearer ${this.accessToken}`);

    this.http.get('https://www.googleapis.com/drive/v3/files', { headers }).subscribe((googleDriveList: any) => {
      this.googleDriveList = googleDriveList.files;
      googleDriveList.files.map((res: any) => {
        if (res.name == "moduleRoleDoc.json") {
          debugger
          this.http.get(`https://www.googleapis.com/drive/v3/files/${res.id}?alt=media`, { headers, responseType: 'blob' })
            .subscribe((response: Blob) => {

              console.log(response);
              const reader = new FileReader();
              reader.onload = () => {
                // Assign the file data to a variable
                let fileData: any = reader.result;
                console.log(fileData);
                debugger
                sessionStorage.setItem("readyToDowloadData", fileData)
                let object = JSON.parse(fileData);
                this.getDataFromGoogleDriveData.next(object);
                console.log(object);
                // this.NewMultimpleArrayCheck.moduleAccessData.push(object);

              };
              reader.readAsText(response);

            })
        }
      })
    })
  }

  fileuploadOnGoogleDrive(uploadData: any) {
    debugger
    this.getFileList();
    const headers = new HttpHeaders()
      .set('Authorization', `Bearer ${this.accessToken}`);

    let noFileFound: boolean = false;
    // const modulesData = {
    //   "moduleRoles": uploadData
    // }

    if (this.googleDriveList.length) {
      debugger
      this.googleDriveList.map((file: any) => {
        if (file.name == "moduleRoleDoc.json") {
          debugger
          this.http.delete(`https://www.googleapis.com/drive/v3/files/${file.id}`, { headers }).subscribe((res) => {
            noFileFound = false;
          })
        }
        else {
          noFileFound = true;
        }
      })

      if (noFileFound) {
        debugger
        this.uploadFile(uploadData).subscribe(
          (uploadResponse) => {

            const fileId = uploadResponse.id;
            const newName = "moduleRoleDoc.json";
            this.updateFileName(fileId, newName, this.accessToken).subscribe(
              (updateResponse) => {
                console.log('successfly file insterted :- ', updateResponse);
              },
              (error) => {
                console.error('File upload issue :- ', error);
              }
            );
          },
          (error) => {
            console.error('Error uploading file:', error);

          })
      }
    }




  }

  uploadFile(uploadData: any): Observable<any> {
    debugger
    const folderId: string = '1hqcdAR2NiQX-0e6dt_vkCHJih8zCeaPI';
    const headers = new HttpHeaders()
      .set('Authorization', `Bearer ${this.accessToken}`);

    // const formData = new FormData();
    debugger
    // formData.append('metadata', JSON.stringify(uploadData));
    // formData.append('file', file);

    return this.http.post<any>(`${this.baseUrl}?uploadType=media`, uploadData, { headers });
  }

  // Function to update file name in Google Drive
  updateFileName(fileId: string, newName: string, accessToken: string): Observable<any> {
    debugger
    const headers = new HttpHeaders()
      .set('Authorization', `Bearer ${accessToken}`);

    const metadata = { name: newName };

    // Send a PATCH request to update the file name
    // return this.http.patch<any>(`https://www.googleapis.com/drive/v3/files/${fileId}`, metadata, { headers });
    return this.http.patch<any>(`https://www.googleapis.com/drive/v3/files/${fileId}`, metadata, { headers });
  }


  googleAuthantication() {
    debugger
    this.initTokenClient('631148325332-t36rn3c2isnhcjd7vm777fgsjs9ei8pc.apps.googleusercontent.com');
    // google.accounts.id.renderButton(
    //   document.getElementById('button-google'),
    //   {
    //     Type: "Standard",
    //     theme: "filled_black",
    //     size: "large",
    //     text: "signup_with",
    //     shape: "rectangular",
    //   }
    // )
  }

  initTokenClient(clientId: any) {
    debugger
    this.tokenClient = google.accounts.oauth2.initTokenClient({
      client_id: clientId,
      scope: 'https://www.googleapis.com/auth/drive',
      callback: (tokenResponse: any) => {
        this.access_token = tokenResponse.access_token;
        sessionStorage.setItem("token", this.access_token);
        this.getFileList();
      },
    });
    this.tokenClient.requestAccessToken()
  }
}
