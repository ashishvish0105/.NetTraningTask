import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

export const routeGuardsGuard: CanActivateFn = (route, state) => {
  // debugger
  const router = inject(Router)
  let token: string = sessionStorage.getItem("generatedToken") || '';
  if (token?.length > 0) {
    return true;
  }
  else {
    router.navigate(['/', 'taskModule', 'jwt-token-implement'])
  }
  return false;
};
