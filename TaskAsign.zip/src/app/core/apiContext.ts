export const stackOverFlow = {
    stackexchangsAnswers: "https://api.stackexchange.com/2.3/answers",

}