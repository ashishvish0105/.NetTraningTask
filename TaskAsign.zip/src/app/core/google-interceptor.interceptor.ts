import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class GoogleInterceptorInterceptor implements HttpInterceptor {

  constructor() { }

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    const get_accessToken = sessionStorage.getItem('token');
    if (get_accessToken) {
      request = request.clone({
        setHeaders: {
          Authorization: `Bearer ${get_accessToken}`
        }
      });
    }
    return next.handle(request);
  }
}
