import { OnInit } from "@angular/core";

export const accessdata = [
    {
        privileages: "full access go seller",
        admin: false,
        superUser: false,
        user: true,
    },
    {
        privileages: "full access go banner",
        admin: false,
        superUser: true,
        user: true,
    },
    {
        privileages: "full access go comapny",
        admin: false,
        superUser: false,
        user: true,
    }
]

export const modules = ['Go company', 'Go seller'];
export const permission = ['read', 'full acesss'];
export const rollAccess = ['admin', 'superUser', 'user'];
export const rollAccessData = { admin: false, superUser: false, user: false };

export const moduleRoles = [
    {
        "moduleid": "Go company",
        "roleid": "admin",
        "permisstion": "read"
    },
    {
        "moduleid": "Go company",
        "roleid": "admin",
        "permisstion": "full acesss"
    },
    {
        "moduleid": "Go company",
        "roleid": "superUser",
        "permisstion": "read"
    },
    {
        "moduleid": "Go company",
        "roleid": "superUser",
        "permisstion": "full acesss"
    },
    {
        "moduleid": "Go company",
        "roleid": "user",
        "permisstion": "read"
    },
    {
        "moduleid": "Go company",
        "roleid": "user",
        "permisstion": "full acesss"
    },
    {
        "moduleid": "Go seller",
        "roleid": "admin",
        "permisstion": "read"
    },
    {
        "moduleid": "Go seller",
        "roleid": "admin",
        "permisstion": "full acesss"
    },
    {
        "moduleid": "Go seller",
        "roleid": "superUser",
        "permisstion": "full acesss"
    },
    {
        "moduleid": "Go seller",
        "roleid": "superUser",
        "permisstion": "read"
    },
    {
        "moduleid": "Go seller",
        "roleid": "user",
        "permisstion": "read"
    },
    {
        "moduleid": "Go seller",
        "roleid": "user",
        "permisstion": "full acesss"
    }
]



// class userAccessData implements OnInit{
//     ngOnInit(): void {
//         const data = rollAccess
//         console.log(data);
//     }
// } 