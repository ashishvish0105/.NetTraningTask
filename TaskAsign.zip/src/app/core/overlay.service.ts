import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OverlayService {

  overlayRef = new BehaviorSubject<any>(null);

  data = new Subject<any>;


  constructor() { }

  dataPush(commingData: any) {
    this.data.next(commingData);
  }

  getData(): Observable<any> {
    return this.data.asObservable();
  }

}
