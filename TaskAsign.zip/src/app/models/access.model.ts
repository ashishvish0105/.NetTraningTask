export interface access {
    privileages: string,
    admin: boolean,
    superUser: boolean,
    user: boolean,
}