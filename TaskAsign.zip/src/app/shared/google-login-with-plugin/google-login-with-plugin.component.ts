import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import {
//   SocialAuthService,
//   GoogleLoginProvider,
//   SocialUser,
// } from '@abacritt/angularx-social-login';


@Component({
  selector: 'app-google-login-with-plugin',
  templateUrl: './google-login-with-plugin.component.html',
  styleUrls: ['./google-login-with-plugin.component.scss']
})
export class GoogleLoginWithPluginComponent {
  // loginForm!: FormGroup;
  // socialUser!: SocialUser;
  // isLoggedin?: boolean = false;


  // constructor(
  //   private formBuilder: FormBuilder,
  //   private socialAuthService: SocialAuthService
  // ) {
  //   // "@abacritt/angularx-social-login": "^2.2.0",
  //   this.loginForm = this.formBuilder.group({
  //     email: ['', Validators.required],
  //     password: ['', Validators.required],
  //   });
  //   this.socialAuthService.authState.subscribe((user) => {
  //     sessionStorage.setItem('googleToken', user.idToken)
  //     this.socialUser = user;
  //     this.isLoggedin = user != null;
  //     console.log(this.socialUser);
  //   });
  // }
  // generateToken(payload: any, secretKey: string, expiresIn: string = '1h'): string {
  //   // Encode payload and create JWT token
  //   const token = jwt.sign(payload, secretKey, { expiresIn });
  //   return token;
  // }

  // loginWithGoogle(): void {
  //   this.socialAuthService.signIn(GoogleLoginProvider.PROVIDER_ID);

  // }
  // logOut(): void {
  //   this.socialAuthService.signOut();
  // }
}
