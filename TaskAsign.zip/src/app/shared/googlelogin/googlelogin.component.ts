import { Component, OnInit } from '@angular/core';
declare var google: any;

@Component({
  selector: 'app-googlelogin',
  templateUrl: './googlelogin.component.html',
  styleUrls: ['./googlelogin.component.scss']
})
export class GoogleloginComponent implements OnInit {
  tokenClient: any
  access_token: any
  constructor() {
    console.log("login component");
    debugger
    // if (!sessionStorage.getItem('token')?.length) {
    //   this.googleAuthantication();
    // }
  }
  ngOnInit(): void {

    // google.accounts.id.initialize({
    //   client_id: '631148325332-t36rn3c2isnhcjd7vm777fgsjs9ei8pc.apps.googleusercontent.com',
    //   callback: (res: any) => {

    //   }
    // });
  }

  googleAuthantication() {
    debugger
    this.initTokenClient('631148325332-t36rn3c2isnhcjd7vm777fgsjs9ei8pc.apps.googleusercontent.com');
    google.accounts.id.renderButton(
      document.getElementById('button-google'),
      {
        Type: "Standard",
        theme: "filled_black",
        size: "large",
        text: "signup_with",
        shape: "rectangular",
      }
    )
  }

  initTokenClient(clientId: any) {
    debugger
    this.tokenClient = google.accounts.oauth2.initTokenClient({
      client_id: clientId,
      scope: 'https://www.googleapis.com/auth/drive',
      callback: (tokenResponse: any) => {
        this.access_token = tokenResponse.access_token;
        this.handleLogin()
      },
    });
    this.tokenClient.requestAccessToken()
  }

  handleLogin() {
    debugger
    sessionStorage.setItem("token", this.access_token);
    //const playload = this.decodedcode(res.credential);
    // sessionStorage.setItem("googletoken", JSON.stringify(playload));

    // if (playload) {
    //   this.router.createUrlTree(['dashboard'])
    // }
  }

  private decodedcode(token: any) {
    return JSON.parse(atob(token.split(".")[1]))
  }
}
