import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-task-info',
  templateUrl: './task-info.component.html',
  styleUrls: ['./task-info.component.scss']
})
export class TaskInfoComponent {
  @Input() taskName: string = 'task Name';
  @Input() description: string = 'task Name'
  @Input() taskStatus: boolean = false;
  @Input() onTaskWork: boolean = false

}
