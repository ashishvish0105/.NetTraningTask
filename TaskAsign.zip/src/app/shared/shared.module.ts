import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TaskInfoComponent } from './task-info/task-info.component';
import { FileUploadComponent } from './file-upload/file-upload.component';
import { HttpClientModule } from '@angular/common/http';
import { FullscreenOverlayContainer, OverlayContainer, OverlayModule } from '@angular/cdk/overlay';
import { GoogleloginComponent } from './googlelogin/googlelogin.component';
import { GoogleLoginWithPluginComponent } from './google-login-with-plugin/google-login-with-plugin.component';
import { ReactiveFormsModule } from '@angular/forms';
import { AlertComponent } from './tools/alert/alert.component';


@NgModule({
  declarations: [
    TaskInfoComponent,
    FileUploadComponent,
    GoogleloginComponent,
    GoogleLoginWithPluginComponent,
    AlertComponent
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    OverlayModule,
    ReactiveFormsModule,
  ],
  exports: [
    TaskInfoComponent,
    FileUploadComponent,
    GoogleloginComponent,
    GoogleLoginWithPluginComponent,
    AlertComponent

  ],
  providers: [{ provide: OverlayContainer, useClass: FullscreenOverlayContainer }],
})
export class SharedModule { }
