import { coerceStringArray } from '@angular/cdk/coercion';
import { OverlayRef } from '@angular/cdk/overlay';
import { Component, EventEmitter, Output, ViewChild } from '@angular/core';
import { OverlayService } from 'src/app/core/overlay.service';
import { MultimpleArrayCheckComponent } from 'src/app/modules/task-components/components/multimple-array-check/multimple-array-check.component';

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.scss']
})

export class FileUploadComponent {
  @ViewChild(MultimpleArrayCheckComponent) fileUploadComponentRef!: MultimpleArrayCheckComponent;
  @Output() overlayClosed = new EventEmitter<void>();
  // @Output() dragDropUploadFileEvent = new EventEmitter<any>;
  // @Output() dragDropUploadFileEventSeve = new EventEmitter<any>;
  uploadedFileInfo: fileType[] = [];
  modulesDataGet: any[] = [];
  isOpen = false;
  constructor(private overlayService: OverlayService) { }

  dragDropUploadFile() {
    const fileInfo: any[] = [];
    let module: any[] = [];
    const fileElement = document.createElement('input');
    fileElement.setAttribute('type', 'file');
    fileElement.click();

    fileElement.addEventListener('change', (event) => {
      const inputElement = event.target as HTMLInputElement;
      const selectedFiles: FileList | null = inputElement.files;

      if (selectedFiles) {
        for (let i = 0; i < selectedFiles.length; i++) {
          fileInfo.push({
            fileName: selectedFiles[i].name,
            fileSize: `${selectedFiles[i].size} bytes`,
            fileType: selectedFiles[i].type,
            filePath: inputElement.value
          });
        }
      }

      const file = inputElement.files?.[0];

      if (file) {

        const reader = new FileReader();
        reader.onload = function (e: any) {
          const fileContent = e.target?.result;
          sessionStorage.setItem('fileContent', fileContent)
          console.log(JSON.parse(fileContent));
        };
        reader.readAsText(file);
      }
    });
    this.uploadedFileInfo = fileInfo;

  }

  removeFile() {
    this.uploadedFileInfo = [];
  }

  UploadData() {
    // debugger
    // this.uploadedFileInfo = [];
    const sessionDataGet = JSON.parse(sessionStorage.getItem('fileContent') || '');
    this.overlayService.dataPush(sessionDataGet);
   


    // this.uploadedFileInfo.map((res) => {
    //   const ApiUrl = `http://127.0.0.1:8081/` + res.fileName;

    //   // this.http.get('assets/'+ res.fileName).subscribe((res) => {
    //   //   debugger
    //   //   console.log(res);
    //   // })

    // });
  }

  checkdata(event: any) {
    debugger
    console.log(event)
  }

  inputData(event: any) {
    const file = event.target.files[0];

    if (file) {
      const reader = new FileReader();

      reader.onload = function (e: any) {
        const fileContent = e.target.result;

        try {
          debugger
          const jsonData = JSON.parse(fileContent);
          console.log(jsonData)
        } catch (error) {

        }
      };

      reader.readAsText(file);
    }
  }

  closeOverlap(ref: any): void {
    // this.overlayService.overlayRef.asObservable().subscribe((res) => {
    //   console.log(res);
    //   debugger
    //   res._backdropClick.closed = true;
    //   // res.backdropClick().subscribe(() => res.detach())
    // })

    ref.isOpen = false;

  }


}

interface fileType {
  fileName: string, fileSize: string, fileType: string, filePath: string
}