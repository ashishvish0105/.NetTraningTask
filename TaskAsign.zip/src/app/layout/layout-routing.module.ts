import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainComponent } from './main/main.component';

const routes: Routes = [
  {
    path: '',
    component: MainComponent,
    children: [
      {
        path: '',
        // loadChildren: () => import('../modules/task-components/task-components.module').then(m => m.TaskComponentsModule)
        redirectTo: 'taskComponet',
        pathMatch: 'full'
      },
      {
        path: 'taskComponet',
        loadChildren: () => import('../modules/task-components/task-components.module').then(m => m.TaskComponentsModule)
      },
      {
        path: 'taskModule',
        loadChildren: () => import('../modules/task-modules/task-modules.module').then(m => m.TaskModulesModule)
      }
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LayoutRoutingModule { }
