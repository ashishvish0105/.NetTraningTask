import { Component, OnInit } from '@angular/core';
import { GlobleDataService } from 'src/app/core/globle-data.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],

})
export class HeaderComponent implements OnInit {

  headerShow: boolean = true;
  constructor(private _GlobleDataService: GlobleDataService) { }
  ngOnInit(): void {
    this._GlobleDataService.headerShow.subscribe((res: any) => {
      console.log(res)
      this.headerShow = res;
    })
  }

}
