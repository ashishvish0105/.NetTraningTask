import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainComponentComponent } from './main-component/main-component.component';
import { CheckResponsiveDesignComponent } from './components/check-responsive-design/check-responsive-design.component';
import { CheckBoxOptionComponent } from './components/check-box-option/check-box-option.component';
import { MultimpleArrayCheckComponent } from './components/multimple-array-check/multimple-array-check.component';
import { NewMultimpleArrayCheckComponent } from './components/new-multimple-array-check/new-multimple-array-check.component';
import { OverlayWithCustomeOverlayComponent } from './components/overlay-with-custome-overlay/overlay-with-custome-overlay.component';
import { GooglefileUploadComponent } from './components/googlefile-upload/googlefile-upload.component';
import { routeGuardsGuard } from 'src/app/core/routeGuards/route-guards.guard';

const routes: Routes = [
  {
    path: '',
    // component: MainComponentComponent,
    children: [
      {
        path: '',
        component: MainComponentComponent
      },
      {
        path: 'checkResponsive',
        component: CheckResponsiveDesignComponent
      },
      {
        path: 'check-box-option',
        component: CheckBoxOptionComponent
      },
      {
        path: 'with-multiple-array-check',
        component: MultimpleArrayCheckComponent
      },
      {
        path: 'new-with-multiple-array-check',
        component: NewMultimpleArrayCheckComponent,
        canActivate:[routeGuardsGuard]
      },
      {
        path: 'overlay-with-custome-overlay',
        component: OverlayWithCustomeOverlayComponent
      },
      {
        path: 'google-drive',
        component: GooglefileUploadComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TaskComponentsRoutingModule { }
