import { Component } from '@angular/core';

@Component({
  selector: 'app-main-component',
  templateUrl: './main-component.component.html',
  styleUrls: ['./main-component.component.scss']
})
export class MainComponentComponent {

  taskList = [
    {
      taskStatus: false,
      onTaskWork: false,
      routerLink: "checkResponsive",
      taskName: "responsive check",
      description: "do you check your design website use it upgrate your responsive design"
    },
    {
      taskStatus: false,
      onTaskWork: false,
      routerLink: "checkResponsive",
      taskName: "Chart Implementation",
      description: "use google chat to implement"
    },
    {
      taskStatus: false,
      onTaskWork: false,
      routerLink: "checkResponsive",
      taskName: "Chart Implementation",
      description: "use google chat to implement"
    },
    {
      taskStatus: false,
      onTaskWork: false,
      routerLink: "check-box-option",
      taskName: "select option of check box",
      description: "click On edit button enable all Check-botton in column, change the check box value and click on update button  save date."
    },
    {
      taskStatus: false,
      onTaskWork: false,
      routerLink: "with-multiple-array-check",
      taskName: "we have two array and alter netive match and create new array",
      description: "click On edit button enable all Check-botton in column, change the check box value and click on update button  save date."
    },
    {
      taskStatus: false,
      onTaskWork: true,
      routerLink: "new-with-multiple-array-check",
      taskName: "change object",
      description: "click On edit button enable all Check-botton in column, change the check box value and click on update button  save date."
    },
    {
      taskStatus: false,
      onTaskWork: false,
      routerLink: 'google-drive',
      taskName: "file upload on google drive",
      description: "design page and file upload on google dive & drag& drop the file"
    },
    {
      onTaskWork: false,
      taskStatus: false,
      routerLink: "overlay-with-custome-overlay",
      taskName: "overlay with custome overlay",
      description: "create custome overlay(means a componnet showing in modal) and doing with cdn of overlay"
    }
  ]

}
