import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AngularSignalComponent } from './angular-signal.component';

describe('AngularSignalComponent', () => {
  let component: AngularSignalComponent;
  let fixture: ComponentFixture<AngularSignalComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AngularSignalComponent]
    });
    fixture = TestBed.createComponent(AngularSignalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
