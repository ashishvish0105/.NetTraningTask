import { Component } from '@angular/core';

@Component({
  selector: 'app-angular-signal',
  templateUrl: './angular-signal.component.html',
  styleUrls: ['./angular-signal.component.scss']
})
export class AngularSignalComponent {

}
