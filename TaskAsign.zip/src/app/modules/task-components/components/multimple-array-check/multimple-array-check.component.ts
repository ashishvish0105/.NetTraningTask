import { Component, EventEmitter, OnChanges, OnDestroy, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { modules, rollAccessData, permission } from 'src/app/core/Data/access';
import { access } from 'src/app/models/access.model';
import exportFromJSON from 'export-from-json';
import { Overlay, } from '@angular/cdk/overlay';
import { ComponentPortal } from '@angular/cdk/portal';
import { FileUploadComponent } from 'src/app/shared/file-upload/file-upload.component';
import { OverlayService } from 'src/app/core/overlay.service';
import { JsonPipe } from '@angular/common';


@Component({
  selector: 'app-multimple-array-check',
  templateUrl: './multimple-array-check.component.html',
  styleUrls: ['./multimple-array-check.component.scss']
})
export class MultimpleArrayCheckComponent implements OnInit, OnChanges, OnDestroy {
  // @ViewChild(FileUploadComponent) fileUploadComponentRef!: FileUploadComponent;

  moduleAccessData: any[] = [];
  oldData!: any;
  IsEditColumn = {
    admin: false,
    superUser: false,
    user: false,
  };
  moduleControl!: string;
  checkCordinet: any[] = [];
  modulesList = modules;
  permissionList = permission;
  selectModulesList: any[] = [];
  moduleControlValidation!: boolean;
  overlayRef: any;
  // @ViewChild(MultimpleArrayCheckComponent) fileUploadComponentRef!: MultimpleArrayCheckComponent;
  @Output() overlayClosed = new EventEmitter<void>();
  // @Output() dragDropUploadFileEvent = new EventEmitter<any>;
  // @Output() dragDropUploadFileEventSeve = new EventEmitter<any>;
  uploadedFileInfo: fileType[] = [];
  modulesDataGet: any[] = [];
  openModule = false;
  optionSelectAll = true;
  withFormat: any[] = [];
  listModules: any[] = [];
  moduleAccessDataGetter = false;

  constructor(private overlay: Overlay, private overlayService: OverlayService) {
    this.overlayService.getData().subscribe((res) => {
      debugger

      const response = res.moduleRoles;
      this.withFormat = response;
      const transformedArray = response.map((item: any, index: any) => {
        debugger
        return {
          "Id": `0${index}`, // You can adjust the logic for generating Id based on your requirements
          "moduleid": item.moduleid,
          "roleid": item.roleid,
          "permisstion": item.permisstion,
          value: true
        };
      });
      sessionStorage.setItem('checkCordinet', JSON.stringify(transformedArray));
      sessionStorage.setItem('withFormat', JSON.stringify(this.withFormat));
      debugger
      this.chat(response)
      this.listModules = this.getUniqueValues(response, Object.keys(response[0])[0]);
      if (this.listModules.length) {
        this.moduleAccessDataGetter = true;
      }
      const permission = this.getUniqueValues(response, Object.keys(response[0])[2]);

      // modules.map((res: any) => {
      //   this.modulesList.push(res);
      // })
      // permission.map((res: any) => {
      //   this.permissionList.push(res);
      // })
      // let modifyData: any[] = [];
      // let orinalViewData = this.uploadJsonData(modules, permission)

      // orinalViewData.map((module: any) => {
      //   for (let i = 0; i <= response.length; i++) {
      //     let accessName = response[i].roleid
      //     switch (accessName) {
      //       case accessName = 'admin':
      //         debugger
      //         // modifyData.push(this.modifyData(response[i].roleid, module));
      //         module.admin = true;
      //         break;
      //       case accessName = 'superUser':
      //         debugger
      //         // modifyData.push(this.modifyData(response[i].roleid, module));
      //         module.superUser = true;
      //         break;
      //       case accessName = 'user':
      //         debugger
      //         // modifyData.push(this.modifyData(response[i].roleid, module));
      //         module.user = true;
      //         break;
      //     }

      //   }
      //   console.log(module)
      // })
      // debugger
      // console.log(orinalViewData);

      console.log(transformedArray);
    })
  }
  ngOnDestroy(): void {
    sessionStorage.removeItem('checkCordinet');
  }
  ngOnInit(): void {
    this.createData();

    // debugger
    // this.overlayService.data.subscribe((res) => {
    //   console.log(res);
    //   return res;
    // }) 
  }

  ngOnChanges(changes: SimpleChanges): void {
    // debugger
    // this.overlayService.data.subscribe((res) => {
    //   console.log(res);
    //   return res;
    // })
  }

  transformData(array1: any) {
    debugger
    const result: any = [];
    const map = new Map();

    array1.forEach((item: any, index: any) => {
      const key = `${item.moduleid} ${item.permisstion}`;
      if (!map.has(key)) {
        map.set(key, true);

        const obj = {
          Id: result.length,
          admin: false,
          superUser: false,
          user: false,
          module: item.moduleid,
          permission: item.permisstion,
          privileages: `${item.moduleid} ${item.permisstion}`,
          upload: true
        };

        if (item.roleid === 'admin') {
          obj.admin = true;
        } else if (item.roleid === 'superUser') {
          obj.superUser = true;
        } else if (item.roleid === 'user') {
          obj.user = true;
        }

        result.push(obj);
      } else {
        const existingObj = result.find((res: any) => res.privileages === key);
        if (existingObj) {
          if (item.roleid === 'admin') {
            existingObj.admin = true;
          } else if (item.roleid === 'superUser') {
            existingObj.superUser = true;
          } else if (item.roleid === 'user') {
            existingObj.user = true;
          }
        }
      }
    });
    return result;
  }

  chat(data: any) {
    const array2 = this.transformData(data);
    this.moduleAccessData = array2;
    if (this.moduleAccessData.length) {
      sessionStorage.setItem('orginalDataMultipleCheckBox', JSON.stringify(this.moduleAccessData));
    }
    console.log(array2);
  }

  modifyData(accessName: any, module: any) {
    switch (accessName) {
      case accessName = 'admin':
        module.admin = true;
        break;
      case accessName = 'superUser':
        module.superUser = true;
        break;
      case accessName = 'user':
        module.user = true;
        break;
    }
    return module;
  }

  getUniqueValues(array: any, property: any) {
    debugger
    const set = new Set();

    for (const item of array) {
      set.add(item[property]);
    }

    return [...set];
  };

  get fileUploadData() {
    // debugger
    // return this.overlayService.data.subscribe((res) => {
    //   console.log(res);
    //   return res;
    // })
    return JSON.parse(sessionStorage.getItem('fileContent') || '');
  }

  // get moduleAccessDataGetter() {
  //   if (this.withFormat.length > 0) {
  //     return true;
  //   }
  //   return false;
  // }

  createData() {
    // this.modulesList = []

    // if (this.moduleAccessData.length > 0) {
    //   const data = JSON.parse(sessionStorage.getItem('orginalDataMultipleCheckBox') || '');
    //   this.moduleAccessData = [...data];
    // }
    // this.permissionList = [];

    let iterms: number = 0;
    // if (this.selectModulesList.length > 0) {
    for (let i = 0; i < this.modulesList.length; i++) {
      for (let J = 0; J < this.permissionList.length; J++) {
        this.moduleAccessData.push({ privileages: `${modules[i]} ${permission[J]}`, module: modules[i], permission: permission[J], ...rollAccessData, Id: iterms }); //for modul and permission
        // this.moduleAccessData.push({ privileages: `${modules[i]} ${permission[J]}`,...rollAccessData });
        iterms = iterms + 1;
      }
    }
    sessionStorage.removeItem('checkCordinet');

    if (this.moduleAccessData.length) {

      this.listModules = this.modulesList;
      sessionStorage.setItem('orginalDataMultipleCheckBox', JSON.stringify(this.moduleAccessData));

      // this.moduleAccessData.map((res: any) => {
      //   this.listModules = res.filter((res: any) => res.models)
      // })

    }

  }

  uploadJsonData(modules: any, permission: any) {
    let returnDynamicCreateData: any[] = [];
    let iterms: number = modules.length;
    // if (this.selectModulesList.length > 0) {
    for (let i = 0; i < modules.length; i++) {
      for (let J = 0; J < this.permissionList.length; J++) {
        returnDynamicCreateData.push({ privileages: `${modules[i]} ${permission[J]}`, module: modules[i], permission: permission[J], ...rollAccessData, Id: iterms }); //for modul and permission
        // this.moduleAccessData.push({ privileages: `${modulesName} ${permission[J]}`,...rollAccessData });
        iterms = iterms + 1;
      }
    }
    return returnDynamicCreateData
  }


  dynamicCreateData(modulesName: string) {
    let returnDynamicCreateData: any[] = [];
    let iterms: number = this.moduleAccessData.length;
    // if (this.selectModulesList.length > 0) {
    for (let i = 0; i < 1; i++) {
      for (let J = 0; J < this.permissionList.length; J++) {
        returnDynamicCreateData.push({ privileages: `${modulesName} ${permission[J]}`, module: modulesName, permission: permission[J], ...rollAccessData, Id: iterms }); //for modul and permission
        // this.moduleAccessData.push({ privileages: `${modulesName} ${permission[J]}`,...rollAccessData });
        iterms = iterms + 1;
      }
    }

    if (returnDynamicCreateData.length) {
      returnDynamicCreateData.map((module) => {
        debugger
        this.moduleAccessData.push({
          privileages: module.privileages, module: module.module, permission: module.permission, admin: module.admin, superUser: module.superUser, user: module.user, Id: module.Id
        });
      })
      sessionStorage.setItem('orginalDataMultipleCheckBox', JSON.stringify(this.moduleAccessData));
    }
  }

  editButton(accessName: string) {

    // if (this.oldData != undefined) {
    //   this.oldData = JSON.parse(sessionStorage.getItem('orginalDataMultipleCheckBox') || '');
    //   this.moduleAccessData = this.oldData;
    // }

    this.moduleAccessData = JSON.parse(sessionStorage.getItem('orginalDataMultipleCheckBox') || '');

    this.IsEditColumn = {
      admin: false,
      superUser: false,
      user: false,
    };

    switch (accessName) {
      case accessName = 'admin':
        this.IsEditColumn.admin = true;
        break;
      case accessName = 'superUser':
        this.IsEditColumn.superUser = true;
        break;
      case accessName = 'user':
        this.IsEditColumn.user = true;
        break;
    }

  }

  selectModulesMethod() {
    this.IsEditColumn = {
      admin: false,
      superUser: false,
      user: false,
    };

    this.modulesList.map((res) => {
      if (this.moduleControl.toLowerCase() == res.toLowerCase()) {
        this.moduleControlValidation = true;
        this.moduleControl = this.moduleControl;
      }
      else {
        this.moduleControlValidation = false;
      }
    })
    this.oldData = JSON.parse(sessionStorage.getItem('orginalDataMultipleCheckBox') || '');
    this.moduleAccessData = this.oldData;

    if (!this.moduleControlValidation) {
      this.modulesList.push(this.moduleControl);
      this.dynamicCreateData(this.moduleControl);
      this.moduleControl = '';
    }

  }

  oncheck(data: any, index: any, columnType: string, info: any) {
    let columnId: any;
    // this.filterData(this.moduleAccessData[index].module, columnType, this.moduleAccessData[index].permission, data.target.checked);
    this.oldData = JSON.parse(sessionStorage.getItem('orginalDataMultipleCheckBox') || '')
    switch (columnType) {
      case columnType = 'admin':
        columnId = 1;
        this.moduleAccessData[index].admin = data.target.checked;
        break;
      case columnType = 'superUser':
        columnId = 2;
        this.moduleAccessData[index].superUser = data.target.checked;
        break;
      case columnType = 'user':
        columnId = 3;
        this.moduleAccessData[index].user = data.target.checked;
        break;
    }
    this.filterData(info, columnType, data, columnId);
  }


  filterData(info: any, rollName: any, data: any, columnId: any) {
    debugger
    let localStorageData: any[] = [];
    if (sessionStorage.getItem('checkCordinet') !== null) {
      localStorageData = JSON.parse(sessionStorage.getItem('checkCordinet') || '');
    }
    if (data.target.checked == true) {
      localStorageData.push(
        {
          Id: `${info.Id}${columnId}`,
          moduleid: info.module,
          roleid: rollName,
          permisstion: info.permission,
          value: data.target.checked
        })
    }
    else {
      let index = `${info.Id}${columnId}`;
      localStorageData = this.removeElementById(localStorageData, index);
    }
    // setTimeout(() => {
    //   localStorageData = this.removeDuplicateIdsAndUpdateValue(localStorageData);
    //   localStorageData = this.removeRecordsWithValueFalse(localStorageData);
    //   localStorageData = this.removeDuplicates(localStorageData);
    // localStorageData = localStorageData.filter(item => item.value === true);
    console.log(localStorageData);
    // }, 3000);
    sessionStorage.setItem('checkCordinet', JSON.stringify(localStorageData));


  }
  removeDuplicates(data: any) {
    const uniqueRecords: any[] = [];
    const seenCombinations = new Set();

    data.forEach((item: any) => {
      const key = `${item.moduleid}-${item.roleid}-${item.permisstion}`;

      if (!seenCombinations.has(key)) {
        seenCombinations.add(key);
        uniqueRecords.push(item);
      }
    });

    return uniqueRecords;
  }


  removeRecordsWithValueFalse(data: any) {
    return data.filter((item: any) => item.value !== false);
  }

  removeElementById(arr: any, idToRemove: any) {
    return arr.filter((item: any) => item.Id != idToRemove);
  }

  removeDuplicateIdsAndUpdateValue(data: any) {
    debugger
    const idMap = new Map();
    // Iterate over the array in reverse order
    for (let i = data.length - 1; i >= 0; i--) {
      const currentObject = data[i];

      // If the Id is not in the map, add it
      if (!idMap.has(currentObject.Id)) {
        idMap.set(currentObject.Id, true);
      } else {
        // If the Id is already in the map, remove the current object
        data.splice(i, 1);
      }
    }

    return data;
  }

  adminAllOrNot(optionSelectAll: any) {
    if (optionSelectAll) {
      this.moduleAccessData.map((res: access) => {
        res.admin = true;
      })
    }
    else {
      this.moduleAccessData.map((res) => {
        res.admin = false;
      })
    }
  }

  superUserAllOrNot(optionSelectAll: boolean) {
    //  
    if (optionSelectAll) {
      this.moduleAccessData.map((res: access) => {
        res.superUser = true;
      })
    }
    else {
      this.moduleAccessData.map((res) => {
        res.superUser = false;
      })
    }
  }

  userAllOrNot(optionSelectAll: boolean) {
    //  
    if (optionSelectAll) {
      this.moduleAccessData.map((res: access) => {
        res.user = true;
      })
    }
    else {
      this.moduleAccessData.map((res) => {
        res.user = false;
      })
    }
  }

  updateButton(accessName?: string) {
    debugger
    sessionStorage.setItem('orginalDataMultipleCheckBox', JSON.stringify(this.moduleAccessData));
    let localStorageData = JSON.parse(sessionStorage.getItem('checkCordinet') || '');

    this.withFormat = [];
    this.moduleAccessDataGetter = true;
    localStorageData = localStorageData.sort((a: any, b: any) => a.moduleid.localeCompare(b.moduleid));

    localStorageData.map((res: any) => {
      this.withFormat.push({
        moduleid: res.moduleid, roleid: res.roleid, permisstion: res.permisstion
      })
    })
    sessionStorage.setItem('withFormatData', JSON.stringify(this.withFormat));


    // console.log(this.withFormat);

    // setTimeout(() => {
    //   console.log({ moduleRoles: this.withFormat })
    // }, 2000);

    switch (accessName) {
      case accessName = 'admin':
        this.IsEditColumn.admin = false;
        break;
      case accessName = 'superUser':
        this.IsEditColumn.superUser = false;
        break;
      case accessName = 'user':
        this.IsEditColumn.user = false;
        break;
    }

  }

  exporJsonFileDownload() {
    const withFormat = JSON.parse(sessionStorage.getItem('withFormat') || '');
    const checkCordinet = JSON.parse(sessionStorage.getItem('checkCordinet') || '');

    const mergedObjects = [...withFormat, ...checkCordinet].filter((currentObject, index, array) => {
      const key = `${currentObject.moduleid}_${currentObject.roleid}_${currentObject.permisstion}`;

      // Check if the key is the first occurrence in the array
      return array.findIndex(obj =>
        `${obj.moduleid}_${obj.roleid}_${obj.permisstion}` === key
      ) === index;
    });
    debugger
    sessionStorage.setItem('withFormat', JSON.stringify(mergedObjects));



    const data = { moduleRoles: this.withFormat };
    const date = new Date();
    const fileName = `Export-${date.toLocaleDateString().split('/').join('-')}-${date.toLocaleTimeString().split(':').join('-')}`;
    const exportType = 'json';


    exportFromJSON({ data, fileName, exportType });
  }

  clearDate() {
    // sessionStorage.removeItem('orginalDataMultipleCheckBox');
    // sessionStorage.removeItem('checkCordinet');
    location.reload();
  }

  childtoParentcall() {
    console.log("hello parent");
  }

  uploadJsonFile() {

    // this.overlayRef = this._overlay.create({
    //   hasBackdrop: true,
    //   backdropClass: "cdk-overlay-transparent-backdrop",
    //   panelClass: "mat-elevation-z8",
    //   positionStrategy: this._overlay.position().global()
    // });

    // const popupComponentPortal = new ComponentPortal(FileUploadComponent);

    // this.overlayRef.attach(popupComponentPortal);

    // this.overlayRef.backdropClick().subscribe(() => {
    //   this.overlayRef.dispose();
    // });
    const configuration = {
      // hasBackdrop: true,
      backdropClass: 'cdk-overlay-transparent-backdrop',
      panelClass: 'mat-elevation-z8',
      positionStrategy: this.overlay.position().global().centerHorizontally().centerVertically(),
      width: "60%",
    }
    this.overlayRef = this.overlay.create(configuration);
    const component = new ComponentPortal(FileUploadComponent);
    this.overlayRef.attach(component);
    // this.overlayService.overlayRef.next(this.overlayRef)
    this.overlayRef.backdropClick().subscribe(() => this.overlayRef.detach());


  }

  closeOverlay(): void {
    if (this.overlayRef) {
      this.overlayRef.detach();
      this.overlayRef = null;
    }
  }

  dragDropUploadFileEventSeve() {
    console.log('save');
  }

  dragDropUploadFile() {
    const fileInfo: any[] = [];
    let module: any[] = [];
    const fileElement = document.createElement('input');
    fileElement.setAttribute('type', 'file');
    fileElement.click();

    fileElement.addEventListener('change', (event) => {
      const inputElement = event.target as HTMLInputElement;
      const selectedFiles: FileList | null = inputElement.files;

      if (selectedFiles) {
        for (let i = 0; i < selectedFiles.length; i++) {
          fileInfo.push({
            fileName: selectedFiles[i].name,
            fileSize: `${selectedFiles[i].size} bytes`,
            fileType: selectedFiles[i].type,
            filePath: inputElement.value
          });
        }
      }

      const file = inputElement.files?.[0];

      if (file) {

        const reader = new FileReader();
        reader.onload = function (e: any) {
          const fileContent = e.target?.result;
          sessionStorage.setItem('fileContent', fileContent)
          console.log(JSON.parse(fileContent));
        };
        reader.readAsText(file);
      }
    });
    this.uploadedFileInfo = fileInfo;

  }

  removeFile() {
    this.uploadedFileInfo = [];
  }

  UploadData() {
    debugger
    const sessionDataGet = JSON.parse(sessionStorage.getItem('fileContent') || '');
    this.overlayService.dataPush(sessionDataGet);
    this.openModule = false;
    // this.uploadedFileInfo.map((res) => {
    //   const ApiUrl = `http://127.0.0.1:8081/` + res.fileName;

    //   // this.http.get('assets/'+ res.fileName).subscribe((res) => {
    //   //   debugger
    //   //   console.log(res);
    //   // })

    // });
  }

  checkdata(event: any) {
    debugger
    console.log(event)
  }

  inputData(event: any) {
    const file = event.target.files[0];

    if (file) {
      const reader = new FileReader();

      reader.onload = function (e: any) {
        const fileContent = e.target.result;

        try {
          debugger
          const jsonData = JSON.parse(fileContent);
          console.log(jsonData)
        } catch (error) {

        }
      };

      reader.readAsText(file);
    }
  }

  closeOverlap(ref: any): void {
    // this.overlayService.overlayRef.asObservable().subscribe((res) => {
    //   console.log(res);
    //   debugger
    //   res._backdropClick.closed = true;
    //   // res.backdropClick().subscribe(() => res.detach())
    // })

    ref.isOpen = false;

  }

  openModuleEvent() {
    this.openModule = true;
  }

  closeModuleEvent() {
    this.openModule = false;
  }
  deleteModule(selectOption: any) {
    // this.oldData
    let data = JSON.parse(sessionStorage.getItem('orginalDataMultipleCheckBox') || '');
    let removeModule: any[] = [];

    data.map((res: any) => {
      if (res.module !== selectOption.value) {
        debugger
        removeModule.push({
          privileages: res.privileages, module: res.module, permission: res.permission, admin: res.admin, superUser: res.superUser, user: res.user, Id: res.Id
        });
      }
    })
    this.uniqueModuleEvent(selectOption.value);
    this.moduleAccessData = removeModule;
    sessionStorage.setItem('orginalDataMultipleCheckBox', JSON.stringify(this.moduleAccessData));
  }

  uniqueModuleEvent(selectOption?: any) {
    let removeModule = JSON.parse(sessionStorage.getItem('orginalDataMultipleCheckBox') || '');
    let updateModule: any[] = [];

    removeModule.map((res: any) => {
      debugger
      if (res.module !== selectOption) {
        updateModule.push(res.module);
      }
    })

    this.listModules = [...new Set(updateModule)];
  }

}
interface fileType {
  fileName: string, fileSize: string, fileType: string, filePath: string
}