import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MultimpleArrayCheckComponent } from './multimple-array-check.component';

describe('MultimpleArrayCheckComponent', () => {
  let component: MultimpleArrayCheckComponent;
  let fixture: ComponentFixture<MultimpleArrayCheckComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MultimpleArrayCheckComponent]
    });
    fixture = TestBed.createComponent(MultimpleArrayCheckComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
