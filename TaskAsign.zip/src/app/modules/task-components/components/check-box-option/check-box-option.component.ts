import { Component, ElementRef, OnChanges, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { accessdata } from "../../../../core/Data/access"
import { access } from 'src/app/models/access.model';
import { JsonPipe } from '@angular/common';

@Component({
  selector: 'app-check-box-option',
  templateUrl: './check-box-option.component.html',
  styleUrls: ['./check-box-option.component.scss']
})
export class CheckBoxOptionComponent implements OnInit {
  @ViewChild('adminCheck') adminCheck!: ElementRef;
  @ViewChild('superUserCheck') superUserCheck!: ElementRef;
  @ViewChild('userCheck') userCheck!: ElementRef;
  AccessData!: access[];
  oldData!: access[];
  IsEditColumn = {
    admin: false,
    superUser: false,
    user: false,
  };
  CheckAll = {
    admin: false,
    superUser: false,
    user: false,
  };
  IsallCheckOptionVisible = false;
  selectAllVisible = false;
  optionSelectAll = true;
  // IsEdit!:access;
  ngOnInit(): void {
    this.AccessData = accessdata;
    sessionStorage.setItem('orginalDataCheckBox', JSON.stringify(this.AccessData))
  }


  editButton(accessName: string) {
    if (this.oldData != undefined) {

      this.oldData = JSON.parse(sessionStorage.getItem('orginalDataCheckBox') || '')
      this.AccessData = this.oldData;
    }

    this.IsEditColumn = {
      admin: false,
      superUser: false,
      user: false,
    };
    switch (accessName) {

      case accessName = 'admin':
        // this.AccessData = accessdata;
        this.IsEditColumn.admin = true;

        break;
      case accessName = 'superUser':
        // this.AccessData = accessdata;
        this.IsEditColumn.superUser = true;
        break;
      case accessName = 'user':
        // this.AccessData = accessdata;
        this.IsEditColumn.user = true;
        break;
    }
  }

  selectAll(accessName: string, IsCheck: any) {
    switch (accessName) {
      case accessName = 'admin':
        this.CheckAll.admin = true;
        this.adminAllOrNot(IsCheck.checked);
        break;
      case accessName = 'superUser':
        this.CheckAll.superUser = true;
        this.superUserAllOrNot(IsCheck.checked);
        break;
      case accessName = 'user':
        this.CheckAll.user = true;
        this.userAllOrNot(IsCheck.checked);
        break;
    }
    this.oldData = JSON.parse(sessionStorage.getItem('orginalDataCheckBox') || '')
  }

  oncheck(data: any, index: any, columnType: string) {
    this.selectAllVisible = false;
    this.oldData = JSON.parse(sessionStorage.getItem('orginalDataCheckBox') || '')
    // let allCheckOptionVisible = 0;

    // for (let i = 0; i <= this.AccessData.length; i++) {
    //   allCheckOptionVisible++
    //   if (allCheckOptionVisible == this.AccessData.length) {
    //     this.IsallCheckOptionVisible = true;
    //   }
    // }

    switch (columnType) {
      case columnType = 'admin':
  
        this.adminCheck.nativeElement.checked = false;
        this.AccessData[index].admin = data.target.checked;
        break;
      case columnType = 'superUser':
        this.superUserCheck.nativeElement.checked = false;
        this.AccessData[index].superUser = data.target.checked;
        break;
      case columnType = 'user':
  
        this.userCheck.nativeElement.checked = false;
        this.AccessData[index].user = data.target.checked;
        break;
    }

  }

  adminAllOrNot(optionSelectAll: any) {
    if (optionSelectAll) {
      this.AccessData.map((res: access) => {
        res.admin = true;
      })
    }
    else {
      this.AccessData.map((res) => {
        res.admin = false;
      })
    }
  }

  superUserAllOrNot(optionSelectAll: boolean) {
    //  
    if (optionSelectAll) {
      this.AccessData.map((res: access) => {
        res.superUser = true;
      })
    }
    else {
      this.AccessData.map((res) => {
        res.superUser = false;
      })
    }
  }

  userAllOrNot(optionSelectAll: boolean) {
    //  
    if (optionSelectAll) {
      this.AccessData.map((res: access) => {
        res.user = true;
      })
    }
    else {
      this.AccessData.map((res) => {
        res.user = false;
      })
    }
  }


  updateButton(accessName: string) {
    console.log("update")
    // const oldData = JSON.parse(sessionStorage.getItem('orginalDataCheckBox') || '')
    // const uniqueKeysArray = [...new Set(oldData.flatMap((obj: any) => Object.keys(obj)))];
    sessionStorage.setItem('orginalDataCheckBox', JSON.stringify(this.AccessData));

    switch (accessName) {
      case accessName = 'admin':
        this.IsEditColumn.admin = false;
        break;
      case accessName = 'superUser':
        this.IsEditColumn.superUser = false;
        break;
      case accessName = 'user':
        this.IsEditColumn.user = false;
        break;
    }



    // console.log(oldData)
    // console.log(accessdata)
  }

  clearDate() {
    location.reload();
  }


}
