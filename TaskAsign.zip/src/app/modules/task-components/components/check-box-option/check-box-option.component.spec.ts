import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckBoxOptionComponent } from './check-box-option.component';

describe('CheckBoxOptionComponent', () => {
  let component: CheckBoxOptionComponent;
  let fixture: ComponentFixture<CheckBoxOptionComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CheckBoxOptionComponent]
    });
    fixture = TestBed.createComponent(CheckBoxOptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
