import { HttpClient } from '@angular/common/http';
import { AfterContentInit, AfterViewInit, Component, OnInit } from '@angular/core';
import { GlobleDataService } from 'src/app/core/globle-data.service';


@Component({
  selector: 'app-check-responsive-design',
  templateUrl: './check-responsive-design.component.html',
  styleUrls: ['./check-responsive-design.component.scss']
})
export class CheckResponsiveDesignComponent implements OnInit, AfterViewInit {

  searchinWebUrl: any;
  noDataFound = true;
  zoomCountNumber = 1;
  storeView: any = 'dasktop';
  toggleDropDown = false;
  toggleSetScreenSize = false;
  showData: any[] = [];
  filterData: any[] = [];
  storeSize: any;
  toggleActive = false;
  deviceScrinSize = [
    {
      Device: "Google Chromebook Pixel",
      Width: 2560,
      Heigth: 1700,
    },
    {
      Device: "Apple iMac 21.5-inch (Late 2009 - Late 2012)",
      Width: 1921,
      Heigth: 1080,
    },
    {
      Device: "Apple MacBook Pro 13-inch (Mid 2009 - Mid 2012)",
      Width: 1280,
      Heigth: 800,
    },
    {
      Device: "Apple MacBook Pro 13-inch (Retina display)",
      Width: 2560,
      Heigth: 1600,
    },
    {
      Device: "Apple MacBook Pro 15-inch (Hi-Res screen)",
      Width: 1680,
      Heigth: 1050,
    },
    {
      Device: "Panasonic BT-4LH310P",
      Width: 2160,
      Heigth: 4096,
    },
    {
      Device: "Panasonic BT-LH1850",
      Width: 768,
      Heigth: 1366,
    },
    {
      Device: "Asus K55N-DS81 15.6 in",
      Width: 1366,
      Heigth: 768,
    },
    {
      Device: "Dell Inspiron 14 series 36",
      Width: 1600,
      Heigth: 900,
    },
    {
      Device: "Dell S2340M 23",
      Width: 1920,
      Heigth: 1080,
    },
    {
      Device: "Microsoft Surface Book",
      Width: 3000,
      Heigth: 2000,
    },
    {
      Device: "Panasonic BT-4LH310 4K LCD Monitor",
      Width: 2160,
      Heigth: 3840,
    },
    {
      Device: "Panasonic BT-LH910 LCD Video Monitor",
      Width: 768,
      Heigth: 1280,
    },
    {
      Device: "Apple MacBook 12-inch",
      Width: 2304,
      Heigth: 1440,
    },
    {
      Device: "Apple MacBook Air 13-inch",
      Width: 1440,
      Heigth: 900,
    },
    {
      Device: "Apple MacBook Pro 15-inch",
      Width: 2880,
      Heigth: 1800,
    },
    {
      Device: "Apple iMac 21.5-inch (Retina 4K Display)",
      Width: 4096,
      Heigth: 2304,
    },
    {
      Device: "Apple iMac 27-inch (Retina 5K Display)",
      Width: 5120,
      Heigth: 2880,
    },
    {
      Device: "Acer S277HK",
      Width: 3840,
      Heigth: 2160,
    },
    {
      Device: "Asus Zenfone Max ZC550KL",
      Width: 1280,
      Heigth: 720,
    },
    {
      Device: "LG GX F310L",
      Width: 1080,
      Heigth: 1920,
    },
    {
      Device: "Motorola Droid",
      Width: 480,
      Heigth: 854,
    },
    {
      Device: "Motorola Moto G",
      Width: 720,
      Heigth: 1280,
    },
    {
      Device: "VIVO Y51L",
      Width: 540,
      Heigth: 960,
    },
    {
      Device: "Motorola Moto Z",
      Width: 2560,
      Heigth: 1440,
    },
    {
      Device: "BlackBerry Q10",
      Width: 720,
      Heigth: 720,
    },
    {
      Device: "BlackBerry Z3",
      Width: 960,
      Heigth: 540,
    },
    {
      Device: "BlackBerry Porsche Design P9982",
      Width: 1280,
      Heigth: 768,
    },
    {
      Device: "BlackBerry Passport",
      Width: 1440,
      Heigth: 1440,
    },
    {
      Device: "BlackBerry Torch 9810",
      Width: 480,
      Heigth: 360,
    },
    {
      Device: "Apple iPhone 3GS",
      Width: 320,
      Heigth: 480,
    },
    {
      Device: "Apple iPhone 4 (4, 4S)",
      Width: 640,
      Heigth: 960,
    },
    {
      Device: "Google Pixel C",
      Width: 1600,
      Heigth: 1200,
    },
    {
      Device: "Apple iPad Pro 9.7",
      Width: 2048,
      Heigth: 1536,
    },
    {
      Device: "Ainol Novo 7 Crystal",
      Width: 1024,
      Heigth: 600,
    },
    {
      Device: "Amazon Kindle Fire 1st Gen",
      Width: 600,
      Heigth: 1024,
    },
    {
      Device: "Amazon Kindle Fire HD 8.9",
      Width: 1200,
      Heigth: 1920,
    },

    {
      Device: "Barnes & Noble Nook Tablet",
      Width: 600,
      Heigth: 800,
    },
    {
      Device: "Samsung Galaxy Tab 10.1",
      Width: 800,
      Heigth: 1280,
    },
    {
      Device: "Apple iPad 1 & 2",
      Width: 768,
      Heigth: 1024,
    },
    {
      Device: "Apple iPad 3 & 4",
      Width: 1536,
      Heigth: 2048,
    },
    {
      Device: "FUJITSU LIFEBOOK U745",
      Width: 900,
      Heigth: 1600,
    },
    {
      Device: "Lenovo Yoga 10 HD+",
      Width: 1920,
      Heigth: 1200,
    },
    {
      Device: "Apple iPad Pro",
      Width: 2732,
      Heigth: 2048,
    },
    {
      Device: "Microsoft Surface Pro 3",
      Width: 2160,
      Heigth: 1440,
    },
    {
      Device: "Microsoft Surface Pro 4",
      Width: 2736,
      Heigth: 1824,
    },
    {
      Device: "Apple iPhone 8",
      Width: 750,
      Heigth: 1334,
    },
    {
      Device: "Apple iPhone X",
      Width: 1125,
      Heigth: 2436,
    },
    {
      Device: "Apple iPhone XR",
      Width: 828,
      Heigth: 1792,
    },
    {
      Device: "Apple iPhone XS Max",
      Width: 1242,
      Heigth: 2688,
    },
    {
      Device: "Apple iPhone SE",
      Width: 640,
      Heigth: 1136,
    },
    {
      Device: "Samsung Galaxy S10 Lite",
      Width: 1080,
      Heigth: 2400,
    },
    {
      Device: "Huawei Nova 7i",
      Width: 1080,
      Heigth: 2310,
    },
    {
      Device: "Samsung Galaxy S7 Edge",
      Width: 1440,
      Heigth: 2560,
    },
    {
      Device: "Samsung Galaxy S20+",
      Width: 1440,
      Heigth: 3200,
    },
    {
      Device: "Samsung Galaxy Note20 Ultra",
      Width: 1440,
      Heigth: 3088,
    },
    {
      Device: "Samsung Galaxy Note10+",
      Width: 1440,
      Heigth: 3040,
    },
    {
      Device: "Samsung Galaxy Note10",
      Width: 1080,
      Heigth: 2280,
    },
    {
      Device: "Apple iPad Air (2019)",
      Width: 2224,
      Heigth: 1668,
    },
    {
      Device: "Apple iPad Air (2020)",
      Width: 2360,
      Heigth: 1640,
    },
    {
      Device: "Apple iPad 10.2 (2020)",
      Width: 2160,
      Heigth: 1620,
    },
    {
      Device: "Apple iPad Pro 11",
      Width: 2388,
      Heigth: 1668,
    },
    {
      Device: "Apple iPhone 12",
      Width: 1170,
      Heigth: 2532,
    },
    {
      Device: "Apple iPhone 12 Mini",
      Width: 1080,
      Heigth: 2340,
    }
  ];
  activedeviceSize = false;
  potradeModeOn = false;

  constructor(private http: HttpClient, private _GlobleDataService: GlobleDataService) { }

  ngAfterViewInit(): void {
    this.getdata();
  }

  ngOnInit(): void {
    this.deviceScrinSize.map((x) => {
      if (x.Width >= 1800) {
        let divicename = "dasktop";
        this.filterDataDivices(x, divicename);
      }
      else if (x.Width >= 1200 && x.Width < 1800) {
        let divicename = "laptop";
        this.filterDataDivices(x, divicename);
      }
      else if (x.Width >= 500 && x.Width < 1200) {
        let divicename = "tablet";
        this.filterDataDivices(x, divicename);
      }
      else {
        let divicename = "mobile";
        this.filterDataDivices(x, divicename);
      }
    })
    this.toggleActiveEvent()
  }

  toggleActiveEvent() {
    this.toggleActive = !this.toggleActive;
    if (this.toggleActive) {
      this._GlobleDataService.headerShow.next(false);
    }
    else {
      this._GlobleDataService.headerShow.next(true);
    }

  }

  filterDataDivices(x: any, divicename: string) {
    this.showData.push(
      {
        devicecategory: divicename,
        ...x
      }
    );
  }

  getdata() {
    if (this.storeView) {
      this.filterData = [];
      this.showData.map((x: any) => {
        if (this.storeView == x.devicecategory) {
          this.filterData.push(x);
        }
      })

    }
    this.storeSize = this.filterData[0];
  }

  setActive(view?: string) {
    this.storeView = view;
    if (this.storeView) {
      this.checkView(this.storeView)
      this.getdata();
      this.setScreenSizeDynamic(this.storeSize);
    }
  }


  setScreenSizeDynamic(item: any) {
    this.storeSize = item;
    if (this.potradeModeOn == true) {
      document.querySelector("#demo iframe")?.setAttribute('width', item.Heigth + 'px');
      document.querySelector("#demo iframe")?.setAttribute('height', item.Width + 'px');
    }
    else {
      document.querySelector("#demo iframe")?.setAttribute('width', item.Width + 'px');
      document.querySelector("#demo iframe")?.setAttribute('height', item.Heigth + 'px');
    }
  }

  webSearchingEvent(event: any) {
    this.searchinWebUrl = event.value;
    const targetdiv = document.getElementById("demo") as HTMLDivElement
    targetdiv.innerHTML = '';
    let iframe = document.createElement('iframe');
    iframe.setAttribute('src', this.searchinWebUrl);
    iframe.setAttribute("type", "text/html");
    iframe.setAttribute("allowTransparency", "true")
    iframe.setAttribute('height', this.storeSize.Heigth);
    iframe.setAttribute('width', this.storeSize.Width);
    iframe.setAttribute("allowfullscreen", "1");
    iframe.setAttribute("id", 'inframeDemoTesting');
    targetdiv?.appendChild(iframe);
    if (this.storeView) {
      this.checkView(this.storeView)
    }
  }

  checkView(storeView: any) {
    switch (storeView) {
      case 'laptop':
        this.storeView = 'laptop';
        break
      case 'tablet':
        this.storeView = 'tablet';
        break
      case 'mobile':
        this.storeView = 'mobile';
        break
      default:
        this.storeView = 'dasktop';
        break
    }
  }




  lancecapMode() {
    this.potradeModeOn = !this.potradeModeOn;
    // if (this.potradeModeOn == true) {
    this.setScreenSizeDynamic(this.storeSize);
    // }
  }
  dropDownArrow(event: any, navbar: any) {
    if (event.classList.contains('active')) {
      event.classList.remove('active');
      navbar.style.height = "60px";
      this.toggleDropDown = false;
      this.toggleSetScreenSize = false;
      setTimeout(() => {
        navbar.style.overflow = "visible";
      }, 300);
    }

    else {
      navbar.style.overflow = "hidden";
      setTimeout(() => {
        event.classList.add('active');
        navbar.style.height = "0px";
        this.toggleDropDown = false;
        this.toggleSetScreenSize = false;
      }, 300);
    }

  }

  toggleDropDownEvent() {
    this.toggleDropDown = !this.toggleDropDown;
  }

  setScreenSize() {
    this.toggleSetScreenSize = !this.toggleSetScreenSize;
  }

  zoomEvent(zoom: any) {
     
    let numberAdded = 0.25;
    if (zoom === 'plus') {
      if (this.zoomCountNumber < 2) {
        this.zoomCountNumber = this.zoomCountNumber + numberAdded;
        this.zoommethod()
        console.log(this.zoomCountNumber + 'plus')
      }
    }
    else {
      if (this.zoomCountNumber > 0.25) {
        this.zoomCountNumber = this.zoomCountNumber - numberAdded;
        console.log(this.zoomCountNumber + 'minus')
        this.zoommethod()
      }
    }
  }
  zoommethod() {
    const zoomBody = document.querySelector('#inframeDemoTesting') as HTMLBodyElement;
    if (this.searchinWebUrl) {
      if (zoomBody) {
        zoomBody.style.transform = `scale(${this.zoomCountNumber})`;
        // console.log((Math.abs(this.zoomCountNumber) / 2) / 100)
        zoomBody.style.overflow = "auto";
      }
    }
  }
}


