import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OverlayWithCustomeOverlayComponent } from './overlay-with-custome-overlay.component';

describe('OverlayWithCustomeOverlayComponent', () => {
  let component: OverlayWithCustomeOverlayComponent;
  let fixture: ComponentFixture<OverlayWithCustomeOverlayComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [OverlayWithCustomeOverlayComponent]
    });
    fixture = TestBed.createComponent(OverlayWithCustomeOverlayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
