import { Overlay } from '@angular/cdk/overlay';
import { ComponentPortal } from '@angular/cdk/portal';
import { Component } from '@angular/core';
import { FileUploadComponent } from 'src/app/shared/file-upload/file-upload.component';

@Component({
  selector: 'app-overlay-with-custome-overlay',
  templateUrl: './overlay-with-custome-overlay.component.html',
  styleUrls: ['./overlay-with-custome-overlay.component.scss']
})
export class OverlayWithCustomeOverlayComponent {
  name = "Angular";

  constructor(private overlay: Overlay) { }

  displayOverlay() {
    const target = document.querySelector("#btn") as HTMLElement;
    const overlayRef = this.overlay.create({
      hasBackdrop: true,
      backdropClass: "cdk-overlay-transparent-backdrop",
      panelClass: "mat-elevation-z8",
      positionStrategy: this.overlay
        .position()
        .flexibleConnectedTo(target)
        .withPositions([
          {
            originX: "start",
            originY: "bottom",
            overlayX: "start",
            overlayY: "top"
          }
        ])
    });
    const component = new ComponentPortal(FileUploadComponent);
    const componentRef = overlayRef.attach(component);
    overlayRef.backdropClick().subscribe(() => overlayRef.detach());
  }
}
