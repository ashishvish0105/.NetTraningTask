import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewMultimpleArrayCheckComponent } from './new-multimple-array-check.component';

describe('NewMultimpleArrayCheckComponent', () => {
  let component: NewMultimpleArrayCheckComponent;
  let fixture: ComponentFixture<NewMultimpleArrayCheckComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NewMultimpleArrayCheckComponent]
    });
    fixture = TestBed.createComponent(NewMultimpleArrayCheckComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
