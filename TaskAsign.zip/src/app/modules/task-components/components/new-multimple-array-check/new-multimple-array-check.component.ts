import { AfterViewInit, Component, ElementRef, EventEmitter, OnChanges, OnDestroy, OnInit, Output, SimpleChanges, ViewChild, signal } from '@angular/core';
import { modules, rollAccessData, permission } from 'src/app/core/Data/access';
import { access } from 'src/app/models/access.model';
import exportFromJSON from 'export-from-json';
import { Overlay, } from '@angular/cdk/overlay';
import { ComponentPortal } from '@angular/cdk/portal';
import { FileUploadComponent } from 'src/app/shared/file-upload/file-upload.component';
import { OverlayService } from 'src/app/core/overlay.service';
import { JsonPipe } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { map, mergeMap } from 'rxjs';
import { FileUploadService } from 'src/app/core/google/file-upload.service';


// import { google } from 'googleapis';
// import * as fs from 'fs';

@Component({
  selector: 'app-new-multimple-array-check',
  templateUrl: './new-multimple-array-check.component.html',
  styleUrls: ['./new-multimple-array-check.component.scss'],
  // providers: [FileUploadService]
})
export class NewMultimpleArrayCheckComponent implements OnInit, AfterViewInit, OnDestroy {
  // @ViewChild(FileUploadComponent) fileUploadComponentRef!: FileUploadComponent;
  private readonly baseUrl = 'https://www.googleapis.com/upload/drive/v3/files/';

  moduleAccessData: any[] = [];
  oldData!: any;
  IsEditColumn = {
    admin: false,
    superUser: false,
    user: false,
  };
  moduleControl!: string;
  checkCordinet: any[] = [];
  // modulesList = modules;
  // permissionList = permission;
  modulesList: any[] = [];
  permissionList: any[] = [];
  selectModulesList: any[] = [];
  moduleControlValidation!: boolean;
  overlayRef: any;
  newObject: any[] = [];
  // @ViewChild(MultimpleArrayCheckComponent) fileUploadComponentRef!: MultimpleArrayCheckComponent;
  @Output() overlayClosed = new EventEmitter<void>();
  // @Output() dragDropUploadFileEvent = new EventEmitter<any>;
  // @Output() dragDropUploadFileEventSeve = new EventEmitter<any>;
  uploadedFileInfo: fileType[] = [];
  modulesDataGet: any[] = [];
  openModule = false;
  optionSelectAll = true;
  withFormat: any[] = [];
  // listModules: any[] = [];
  moduleAccess = false;
  editmoduleName: string = '';
  editModuleNameModal = false
  IseditmoduleNameCheck: boolean = false;
  uploadModifyData = '';
  loadData = signal(false);
  isTokenSet: string = this.checkToken;
  showLoader: boolean = false;
  // @ViewChild('fileupload') fileupload!: ElementRef

  constructor(private overlay: Overlay, private overlayService: OverlayService, private http: HttpClient, private fileUploadService: FileUploadService) {
    // this.overlayService.getData().subscribe((res) => {
    //   console.log("constructor call");
    //   this.moduleAccessData = res.moduleRoles;
    //   this.mudueleList();
    //   this.setDataOnLocalStore(this.moduleAccessData)
    // })
    debugger
    // if (sessionStorage.getItem('readyToDowloadData') != null) {
    //   // this.moduleAccessData = JSON.parse(sessionStorage.getItem('readyToDowloadData') || '').moduleRoles;
    //   // this.setDataOnLocalStore(this.moduleAccessData);
    //   this.moduleAccessData.map((res) => {
    //     if (res.module) {
    //       this.modulesList.push(res.module)
    //       this.mudueleList();
    //     }
    //     if (res.permission) {
    //       this.permissionList.push(res.permission)
    //       this.permissionList = [...new Set(this.permissionList)];
    //     }
    //   })
    //   console.log(this.permissionList);
    //   console.log(this.modulesList);
    // }

  }
  ngOnDestroy(): void {
    sessionStorage.removeItem('orginalDataMultipleCheckBox');
    sessionStorage.removeItem('readyToDowloadData');
  }
  ngAfterViewInit(): void {

    // setTimeout(() => {
    //   if (this.loadData() == true) {
    this.loadData.set(true)
    this.fileUploadService.getDataFromGoogleDriveData.subscribe((res: any) => {
      this.initialData(res)
      this.loadData.set(false)
    })
    //   }
    // }, 2000)
  }


  ngOnInit(): void {
    console.log(this.isTokenSet)
    // this.createData();
  }
  // get getDataFromService() {
  //   let data: any
  //   this.fileUploadService.getDataFromGoogleDriveData.subscribe((res:any) => {
  //     console.log(res)
  //     data = res;
  //   })
  //   return data;

  // }


  get checkToken() {
    return this.fileUploadService.accessToken;
  }

  initialData(moduleAccessData?: any) {
    if (moduleAccessData.length) {
      this.moduleAccessData = moduleAccessData.moduleRoles
    }
    else {
      if (sessionStorage.getItem('readyToDowloadData') != null) {
        this.moduleAccessData = JSON.parse(sessionStorage.getItem('readyToDowloadData') || '').moduleRoles;
        this.setDataOnLocalStore(this.moduleAccessData);
      }
    }

    this.moduleAccessData.map((res) => {
      if (res.module) {
        this.modulesList.push(res.module)
        this.mudueleList();
      }
      if (res.permission) {
        this.permissionList.push(res.permission)
        this.permissionList = [...new Set(this.permissionList)];
      }
    })

  }

  // checkToken() {
  //   if (this.isTokenSet.length > 0) {
  //     this.isTokenSet = this.fileUploadService.accessToken;
  // this.fileUploadService.accessToken;
  //   }
  // }

  modifyData(accessName: any, module: any) {
    switch (accessName) {
      case accessName = 'admin':
        module.admin = true;
        break;
      case accessName = 'superUser':
        module.superUser = true;
        break;
      case accessName = 'user':
        module.user = true;
        break;
    }
    return module;
  }

  setDataOnLocalStore(moduleAccessData: any) {
    const addModuleName = { "moduleRoles": moduleAccessData }
    sessionStorage.setItem('orginalDataMultipleCheckBox', JSON.stringify(addModuleName));
    sessionStorage.setItem('readyToDowloadData', JSON.stringify(addModuleName));

  }

  getUniqueValues(array: any, property: any) {

    const set = new Set();

    for (const item of array) {
      set.add(item[property]);
    }

    return [...set];
  };

  get fileUploadData() {
    //  
    // return this.overlayService.data.subscribe((res) => {
    //   console.log(res);
    //   return res;
    // })
    return JSON.parse(sessionStorage.getItem('fileContent') || '');
  }

  // createData() {
  //   let iterms: number = 0;
  //   // if (this.selectModulesList.length > 0) {
  //   for (let i = 0; i < this.modulesList.length; i++) {
  //     for (let J = 0; J < this.permissionList.length; J++) {
  //       this.moduleAccessData.push({ module: modules[i], permission: permission[J], ...rollAccessData, Id: iterms }); //for modul and permission
  //       // this.moduleAccessData.push({ privileages: `${modules[i]} ${permission[J]}`,...rollAccessData });
  //       iterms = iterms + 1;
  //     }
  //   }

  //   if (this.moduleAccessData.length) {

  //     this.listModules = this.modulesList;
  //     this.setDataOnLocalStore(this.moduleAccessData)

  //     // this.moduleAccessData.map((res: any) => {
  //     //   this.listModules = res.filter((res: any) => res.models)
  //     // })

  //   }

  // }

  createRefrence(value: any) {
    return `#${value}`;
  }

  uploadJsonData(modules: any, permission: any) {
    debugger
    let returnDynamicCreateData: any[] = [];
    let iterms: number = modules.length;
    // if (this.selectModulesList.length > 0) {
    for (let i = 0; i < modules.length; i++) {
      for (let J = 0; J < this.permissionList.length; J++) {
        returnDynamicCreateData.push({ module: modules[i], permission: permission[J], ...rollAccessData, Id: iterms }); //for modul and permission
        // this.moduleAccessData.push({ privileages: `${modulesName} ${permission[J]}`,...rollAccessData });
        iterms = iterms + 1;
      }
    }
    return returnDynamicCreateData
  }


  dynamicCreateData(modulesName: string) {
    debugger
    let returnDynamicCreateData: any[] = [];
    let iterms: number = this.moduleAccessData.length;
    // if (this.selectModulesList.length > 0) {
    for (let i = 0; i < 1; i++) {
      for (let J = 0; J < this.permissionList.length; J++) {
        returnDynamicCreateData.push({ module: modulesName, permission: permission[J], ...rollAccessData, Id: iterms });
        iterms = iterms + 1;
      }
    }

    if (returnDynamicCreateData.length) {
      returnDynamicCreateData.map((module) => {
        if (module.module.length) {
          this.moduleAccessData.push({
            module: module.module, permission: module.permission, admin: module.admin, superUser: module.superUser, user: module.user, Id: module.Id
          });
        }
      })
      this.setDataOnLocalStore(this.moduleAccessData);
    }
  }

  editButton(accessName: string) {
    this.IsEditColumn = {
      admin: false,
      superUser: false,
      user: false,
    };

    switch (accessName) {
      case accessName = 'admin':
        this.IsEditColumn.admin = true;
        break;
      case accessName = 'superUser':
        this.IsEditColumn.superUser = true;
        break;
      case accessName = 'user':
        this.IsEditColumn.user = true;
        break;
    }
    this.moduleAccessData = JSON.parse(sessionStorage.getItem('orginalDataMultipleCheckBox') || '').moduleRoles;

  }

  selectModulesMethod() {
    debugger
    // this.modulesList = this.listModules
    this.IsEditColumn = {
      admin: false,
      superUser: false,
      user: false,
    };
    this.checkValidation(this.moduleControl);

    // this.moduleAccessData = JSON.parse(sessionStorage.getItem('orginalDataMultipleCheckBox') || '');

    if (!this.moduleControlValidation) {
      if (this.moduleControl.length) {
        this.modulesList.push(this.moduleControl);
        // this.listModules = this.modulesList
        this.dynamicCreateData(this.moduleControl);
        this.moduleControl = '';
      }
    }

  }

  checkValidation(moduleControl?: any) {
    debugger
    this.moduleControlValidation = false; // Assuming moduleControlValidation is initially false

    this.modulesList.some((res) => {
      if (moduleControl == res.toLowerCase()) {
        this.moduleControlValidation = true;
        // this.moduleControl = '';
        return true; // Break the loop
      }
      return false; // Continue looping
    });
  }

  mudueleList() {
    let module: any[] = [];
    if (this.moduleAccessData.length > 0) {
      this.moduleAccessData.map((res: any) => {
        // if (res.length) {
        module.push(res.module);
        // }
      })
    }
    this.modulesList = [...new Set(module)];
    // const orginalDataMultipleCheckBox = JSON.parse(sessionStorage.getItem('orginalDataMultipleCheckBox') || '');
    // this.modulesList = [];
    // let module: any[] = [];
    // orginalDataMultipleCheckBox.map((res: any) => {
    //   module.push(res.module);
    // })
    // this.modulesList = module;
  }

  oncheck(data: any, index: any, columnType: string, info: any) {
    let columnId: any;
    this.oldData = JSON.parse(sessionStorage.getItem('orginalDataMultipleCheckBox') || '')
    switch (columnType) {
      case columnType = 'admin':
        columnId = 1;
        this.moduleAccessData[index].admin = data.target.checked;
        break;
      case columnType = 'superUser':
        columnId = 2;
        this.moduleAccessData[index].superUser = data.target.checked;
        break;
      case columnType = 'user':
        columnId = 3;
        this.moduleAccessData[index].user = data.target.checked;
        break;
    }
  }

  removeRecord() {
    // let filteredObject = this.moduleAccessData.filter((item: any) => item.admin || item.superUser || item.user);
    // this.newObject = filteredObject;
    this.newObject = this.moduleAccessData;
    sessionStorage.setItem('readyToDowloadData', JSON.stringify(this.moduleAccessData))
  }

  moduleAccessDataGetter() {
    let readyToDowloadData
    if (sessionStorage.getItem('readyToDowloadData') != null) {
      readyToDowloadData = JSON.parse(sessionStorage.getItem('readyToDowloadData') || '');
    }

    this.moduleAccess = readyToDowloadData.length > 0 ? true : false;
  }

  removeElementById(arr: any, idToRemove: any) {
    return arr.filter((item: any) => item.Id != idToRemove);
  }

  updateButton(accessName?: string) {
    debugger
    this.showLoader = true
    // sessionStorage.setItem('orginalDataMultipleCheckBox', JSON.stringify(this.moduleAccessData));
    this.setDataOnLocalStore(this.moduleAccessData);
    // this.moduleAccessDataGetter = true;

    switch (accessName) {
      case accessName = 'admin':
        this.IsEditColumn.admin = false;
        break;
      case accessName = 'superUser':
        this.IsEditColumn.superUser = false;
        break;
      case accessName = 'user':
        this.IsEditColumn.user = false;
        break;
    }
    // this.removeRecord();
    this.moduleAccessDataGetter();
    this.UploadData(this.moduleAccessData);
    this.moduleAccessData = this.moduleAccessData;

    setTimeout(() => {
      this.showLoader = false;
    }, 6000)
    if (!this.showLoader) {
      window.alert("File upload successfuly on google drive.");
    }
  }

  exporJsonFileDownload() {

    // let data: any;
    // let date: any
    // let fileName: any
    // let exportType: any
    // setTimeout(() => {
    const data = { moduleRoles: this.newObject };
    const date = new Date();
    const fileName = `Export-${date.toLocaleDateString().split('/').join('-')}-${date.toLocaleTimeString().split(':').join('-')}`;
    const exportType = 'json';
    // }, 1000);

    setTimeout(() => {
      exportFromJSON({ data, fileName, exportType });
    }, 1000);
  }

  closeOverlay(): void {
    if (this.overlayRef) {
      this.overlayRef.detach();
      this.overlayRef = null;
    }
  }

  dragDropUploadFileEventSeve() {
    console.log('save');
  }

  dragDropUploadFile() {
    const fileInfo: any[] = [];
    let module: any[] = [];
    const fileElement = document.createElement('input');
    fileElement.setAttribute('type', 'file');
    fileElement.click();

    fileElement.addEventListener('change', (event) => {
      const inputElement = event.target as HTMLInputElement;
      const selectedFiles: FileList | null = inputElement.files;

      if (selectedFiles) {
        for (let i = 0; i < selectedFiles.length; i++) {
          fileInfo.push({
            fileName: selectedFiles[i].name,
            fileSize: `${selectedFiles[i].size} bytes`,
            fileType: selectedFiles[i].type,
            filePath: inputElement.value
          });
        }
      }

      const file = inputElement.files?.[0];

      if (file) {

        const reader = new FileReader();
        reader.onload = function (e: any) {
          const fileContent = e.target?.result;
          sessionStorage.setItem('readyToDowloadData', fileContent);
          console.log(JSON.parse(fileContent));
        };
        reader.readAsText(file);
      }
    });
    this.uploadedFileInfo = fileInfo;

  }

  removeFile() {
    this.uploadedFileInfo = [];
  }

  UploadData(moduleData?: any) {
    debugger
    this.showLoader = true;
    if (moduleData != undefined) {
      const addModuleName = { "moduleRoles": moduleData }
      this.fileUploadService.fileuploadOnGoogleDrive(addModuleName);

    }
    else {
      const sessionDataGet = sessionStorage.getItem('readyToDowloadData');
      this.fileUploadService.fileuploadOnGoogleDrive(sessionDataGet);
    }

    this.openModule = false;
    const sessionDataGet = JSON.parse(sessionStorage.getItem('readyToDowloadData') || '');
    this.moduleAccessData = sessionDataGet.moduleRoles
    this.removeFile();

    setTimeout(() => {
      this.showLoader = false;
    }, 6000)

    if (!this.showLoader) {
      window.alert("File upload successfuly on google drive.");
    }

    // this.uploadedFileInfo.map((res) => {
    //   const ApiUrl = `http://127.0.0.1:8081/` + res.fileName;

    //   // this.http.get('assets/'+ res.fileName).subscribe((res) => {
    //   //    
    //   //   console.log(res);
    //   // })

    // });
  }

  checkdata(event: any) {

    console.log(event)
  }

  inputData(event: any) {
    const file = event.target.files[0];

    if (file) {
      const reader = new FileReader();

      reader.onload = function (e: any) {
        const fileContent = e.target.result;

        try {

          const jsonData = JSON.parse(fileContent);
          console.log(jsonData)
        } catch (error) {

        }
      };

      reader.readAsText(file);
    }
  }

  closeOverlap(ref: any): void {
    // this.overlayService.overlayRef.asObservable().subscribe((res) => {
    //   console.log(res);
    //    
    //   res._backdropClick.closed = true;
    //   // res.backdropClick().subscribe(() => res.detach())
    // })

    ref.isOpen = false;

  }

  openModuleEvent() {
    debugger
    // if (!sessionStorage.getItem('token')?.length) {
    //   this.fileUploadService.googleAuthantication()
    // }
    this.openModule = true;
    this.IsEditColumn = {
      admin: false,
      superUser: false,
      user: false,
    };
  }

  editmoduleNameCheck(editmoduleNameRef: any) {
    debugger
    this.IseditmoduleNameCheck = false;
    this.modulesList.some((res) => {
      if (editmoduleNameRef.toLowerCase() == res.toLowerCase()) {
        this.IseditmoduleNameCheck = true;
        // this.moduleControl = '';
        return true; // Break the loop
      }
      return false; // Continue looping
    });
  }

  closeModuleEvent() {
    this.openModule = false;
  }

  deleteModule(selectOption?: any) {
    debugger
    let data = JSON.parse(sessionStorage.getItem('readyToDowloadData') || '').moduleRoles;
    let removeModule: any[] = [];

    data.map((res: any) => {
      if (res.module !== selectOption.value) {
        removeModule.push({
          module: res.module, permission: res.permission, admin: res.admin, superUser: res.superUser, user: res.user, Id: res.Id
        });
      }
    })
    this.moduleAccessData = removeModule;
    this.uniqueModuleEvent(this.moduleAccessData, selectOption.value);

    this.setDataOnLocalStore(this.moduleAccessData);
    // this.modulesList = this.listModules;
    this.moduleControl = '';
    this.editmoduleName = '';
    this.moduleControlValidation = false;

  }

  uniqueModuleEvent(dataobject: any, selectOption?: any) {
    debugger
    // let removeModule = JSON.parse(sessionStorage.getItem('orginalDataMultipleCheckBox') || '');
    let updateModule: any[] = [];

    dataobject.map((res: any) => {
      if (res.module !== selectOption) {
        updateModule.push(res.module);
      }
    })

    this.modulesList = [...new Set(updateModule)];
  }

  clearCheckBox(selectOption: any) {
    let filteredObject: any;
    if (selectOption.value !== 'default') {
      filteredObject = this.moduleAccessData.map((item: any) => {
        if (selectOption.value == item.module) {
          return ({
            ...item,
            admin: false,
            superUser: false,
            user: false
          })
        } else {
          return ({
            ...item
          })
        }
      })
    }
    else {
      const conformation = confirm("You sure!, checked checkbox you uncheck ?")

      if (conformation) {
        filteredObject = this.moduleAccessData.map((item: any) => ({
          ...item,
          admin: false,
          superUser: false,
          user: false
        }))
      }
      else {
        filteredObject = this.moduleAccessData;
      }
    }
    this.moduleAccessData = filteredObject;
    this.newObject = filteredObject;
    // sessionStorage.setItem('readyToDowloadData', JSON.stringify(this.moduleAccessData));
    // sessionStorage.setItem('orginalDataMultipleCheckBox', JSON.stringify(this.moduleAccessData));
    this.setDataOnLocalStore(this.moduleAccessData);
    this.moduleAccessDataGetter();
  }

  editCheckBox(selectOption?: any) {
    this.editModuleNameModal = this.editModuleNameModal ? false : true;

    if (this.editModuleNameModal == true) {
      this.editmoduleName = selectOption.value;
    }
  }

  selectChange(selectOption?: any) {

    if (selectOption !== "default" && selectOption.length > 0 && selectOption) {
      this.editmoduleName = selectOption;
    }
    else {
      this.editmoduleName = '';
    }

  }

  editModuleName() {

    this.editModuleNameModal = this.editModuleNameModal ? false : true;
  }

  changeModuleName(editmoduleNameRef: string) {
    let midifyData: any[] = [];
    this.moduleAccessData.map((res) => {

      if (res.module == this.editmoduleName) {
        res.module = editmoduleNameRef
      }
      midifyData.push(res);
    })
    // this.moduleAccessData.map((res) => {
    //   if (res.module == this.editmoduleName) {
    //     res.module = editmoduleNameRef
    //   }
    // })
    // sessionStorage.setItem('readyToDowloadData', JSON.stringify(midifyData));
    // sessionStorage.setItem('orginalDataMultipleCheckBox', JSON.stringify(midifyData));
    this.setDataOnLocalStore(this.moduleAccessData);
    this.moduleControl = '';


    this.editCheckBox();
    this.mudueleList();
    // this.selectModulesMethod();
    this.checkValidation();

  }

  fileUploadContent(fileupload: any) {
    const file = fileupload.files[0];
    if (file) {
      const fileReader = new FileReader();

      fileReader.onload = (e) => {
        const fileContent = fileReader.result as string;
        setTimeout(() => {
          this.uploadFileToGoogleDrive(fileContent);
        }, 1000)

      };
      fileReader.readAsText(file);
    }
  }
  uploadFileToGoogleDrive(fileContent: any) {
    this.uploadModifyData = fileContent;

    // if (sessionStorage.getItem('readyToDowloadData') != null) {
    //   this.uploadModifyData = JSON.parse(sessionStorage.getItem('readyToDowloadData') || '');
    // }
    // else {
    //   this.uploadModifyData = '';
    // }
  }

  fileuploadOnGoogleDrive(fileupload?: any) {
    debugger
    this.fileUploadService.fileuploadOnGoogleDrive(this.moduleAccessData);

  }
  downloadOnGoogleDrive() {
    this.fileUploadService.downloadOnGoogleDrive();
  }
  pageRefresh() {
    debugger
    // this.loadData.set(true);

    // setTimeout(() => {
    //   if (this.loadData() == true) {
    //     debugger
    //     this.fileUploadService.getFileList();
    //   }
    // }, 5000)
    this.fileUploadService.getDataFromGoogleDriveData.subscribe((res: any) => {
      debugger
      console.log(res);

    })


    // setTimeout(() => {
    //   location.reload();
    //   this.loadData.set(false);
    // }, 5000);
  }

  private getFileExtension(filename: string): string {
    return filename.split('.').pop() || '';
  }
}



interface fileType {
  fileName: string, fileSize: string, fileType: string, filePath: string
}