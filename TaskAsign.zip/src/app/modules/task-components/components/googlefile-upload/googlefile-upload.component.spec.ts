import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GooglefileUploadComponent } from './googlefile-upload.component';

describe('GooglefileUploadComponent', () => {
  let component: GooglefileUploadComponent;
  let fixture: ComponentFixture<GooglefileUploadComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [GooglefileUploadComponent]
    });
    fixture = TestBed.createComponent(GooglefileUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
