import { Component } from '@angular/core';

@Component({
  selector: 'app-googlefile-upload',
  templateUrl: './googlefile-upload.component.html',
  styleUrls: ['./googlefile-upload.component.scss']
})
export class GooglefileUploadComponent {

}
