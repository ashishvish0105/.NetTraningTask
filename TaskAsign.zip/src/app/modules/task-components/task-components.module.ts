import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TaskComponentsRoutingModule } from './task-components-routing.module';
import { CheckResponsiveDesignComponent } from './components/check-responsive-design/check-responsive-design.component';
import { MainComponentComponent } from './main-component/main-component.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CheckBoxOptionComponent } from './components/check-box-option/check-box-option.component';
import { MultimpleArrayCheckComponent } from './components/multimple-array-check/multimple-array-check.component';
import { AngularSignalComponent } from './components/angular-signal/angular-signal.component';
import { FullscreenOverlayContainer, OverlayContainer } from '@angular/cdk/overlay';
import { NewMultimpleArrayCheckComponent } from './components/new-multimple-array-check/new-multimple-array-check.component';
import { OverlayWithCustomeOverlayComponent } from './components/overlay-with-custome-overlay/overlay-with-custome-overlay.component';
import { GooglefileUploadComponent } from './components/googlefile-upload/googlefile-upload.component';


@NgModule({
  declarations: [
    CheckResponsiveDesignComponent,
    MainComponentComponent,
    CheckBoxOptionComponent,
    MultimpleArrayCheckComponent,
    AngularSignalComponent,
    NewMultimpleArrayCheckComponent,
    OverlayWithCustomeOverlayComponent,
    GooglefileUploadComponent
  ],
  imports: [
    CommonModule,
    TaskComponentsRoutingModule,
    SharedModule,
    FormsModule,
    HttpClientModule,
  ],
  providers: [{ provide: OverlayContainer, useClass: FullscreenOverlayContainer }],
})
export class TaskComponentsModule { }
