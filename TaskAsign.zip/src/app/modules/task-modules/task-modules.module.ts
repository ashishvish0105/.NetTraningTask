import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TaskModulesRoutingModule } from './task-modules-routing.module';
import { MainComponent } from './main/main.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { ModulelistComponent } from './components/modulelist/modulelist.component';
import { HttpClientModule } from '@angular/common/http';



@NgModule({
  declarations: [
    MainComponent,
    ModulelistComponent
  ],
  imports: [
    CommonModule,
    TaskModulesRoutingModule,
    SharedModule,
    HttpClientModule
  ]
})
export class TaskModulesModule { }
