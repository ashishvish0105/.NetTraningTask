import { Component } from '@angular/core';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})
export class MainComponent {
  taskModuleWise = [{
    taskStatus: false,
    onTaskWork: false,
    routerLink: "single search",
    taskName: "single search",
    description: "In here we devloping a single serching input that show multiple resuilt relative to serach"
  },
  {
    taskStatus: false,
    onTaskWork: true,
    routerLink: "google drive",
    taskName: "google file upload",
    description: "this module base on google"
  },
  {
    taskStatus: false,
    onTaskWork: true,
    routerLink: "jwt-token-implement",
    taskName: "implement jwt token",
    description: "here we can see jwt token and implement in anguler"
  }
  ]

}
