import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { JWTTokenServiceService } from '../services/jwttoken-service.service';
// import * as jwt from 'jsonwebtoken';
import jwt_decode from 'jwt-decode';
import { JwtTokenGerateService } from '../services/jwt-token-gerate.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})
export class MainComponent implements OnInit {

  loginFrom!: FormGroup;

  constructor(private formbuilder: FormBuilder, private jwtTokenServiceService: JWTTokenServiceService,
    private jwtTokenGerateService: JwtTokenGerateService, private router: Router) { }

  ngOnInit(): void {
    this.loginFrom = this.formbuilder.group({
      email: new FormControl('ashish@gmail.com'),
      password: new FormControl('ashish@gmail')
    })
  }

  loginFromLoginMEthod(formValue: any) {
    debugger
    console.log(formValue);
    this.getEmailToken();
    this.jwtTokenServiceService.decodedToken = formValue;
    const payload = { username: formValue.email, password: formValue.password };
    const secretKey = 'my_secret_key_12345';
    const expiresIn = '1h';
    debugger
    const toeknget = this.jwtTokenGerateService.encodeToken(payload)
    // console.log(toeknget);
    // const token = this.generateToken(payload, secretKey, expiresIn)
    if (toeknget) {
      sessionStorage.setItem('generatedToken', JSON.stringify(toeknget));
      this.router.navigate(['/','taskModule','jwt-token-implement','file-upload-googleDrive'])
    }
  }

  getEmailToken() {
    const data = this.jwtTokenServiceService.getEmailId()
    console.log(data);
  }

  generateToken(payload: any, secretKey: string, expiresIn: string = '1h') {
    // Encode payload and create JWT token
    const token = { payload, secretKey };
    return token;
  }

  decodeToken(token: string): any {
    // Decode JWT token
    const decodedToken = jwt_decode(token);
    return decodedToken;
  }
}
