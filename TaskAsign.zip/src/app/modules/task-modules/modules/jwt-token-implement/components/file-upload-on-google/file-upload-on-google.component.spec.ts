import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FileUploadOnGoogleComponent } from './file-upload-on-google.component';

describe('FileUploadOnGoogleComponent', () => {
  let component: FileUploadOnGoogleComponent;
  let fixture: ComponentFixture<FileUploadOnGoogleComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FileUploadOnGoogleComponent]
    });
    fixture = TestBed.createComponent(FileUploadOnGoogleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
