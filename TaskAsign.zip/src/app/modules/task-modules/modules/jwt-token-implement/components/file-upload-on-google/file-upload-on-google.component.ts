

import { AfterViewInit, Component, ElementRef, EventEmitter, OnChanges, OnDestroy, OnInit, Output, SimpleChanges, ViewChild, signal } from '@angular/core';
import { modules, rollAccessData, permission } from 'src/app/core/Data/access';
import { access } from 'src/app/models/access.model';
import exportFromJSON from 'export-from-json';
import { Overlay, } from '@angular/cdk/overlay';
import { ComponentPortal } from '@angular/cdk/portal';
import { FileUploadComponent } from 'src/app/shared/file-upload/file-upload.component';
import { OverlayService } from 'src/app/core/overlay.service';
import { JsonPipe } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { map, mergeMap } from 'rxjs';
import { GoogleDriveObserableService } from 'src/app/modules/task-modules/modules/jwt-token-implement/services/google-drive-obserable.service';
import { StoreTokenService } from '../../services/store-token.service';


// import { google } from 'googleapis';
// import * as fs from 'fs';

@Component({
  selector: 'app-file-upload-on-google',
  templateUrl: './file-upload-on-google.component.html',
  styleUrls: ['./file-upload-on-google.component.scss'],
  providers: [GoogleDriveObserableService]
})
export class FileUploadOnGoogleComponent implements OnInit, AfterViewInit {
  // @ViewChild(FileUploadComponent) fileUploadComponentRef!: FileUploadComponent;
  private readonly baseUrl = 'https://www.googleapis.com/upload/drive/v3/files/';

  moduleAccessData: any[] = [];
  oldData!: any;
  IsEditColumn = {
    admin: false,
    superUser: false,
    user: false,
  };
  moduleControl!: string;
  modulesList: any[] = [];
  permissionList: any[] = [];
  moduleControlValidation!: boolean;
  overlayRef: any;
  newObject: any[] = [];
  uploadedFileInfo: fileType[] = [];
  modulesDataGet: any[] = [];
  openModule = false;
  optionSelectAll = true;
  withFormat: any[] = [];
  moduleAccess = false;
  editmoduleName: string = '';
  editModuleNameModal = false
  IseditmoduleNameCheck: boolean = false;
  uploadModifyData = '';
  loadData = signal(false);
  showLoader: boolean = false;



  constructor(private overlay: Overlay, private overlayService: OverlayService, private googleDriveObserableService: GoogleDriveObserableService, private storeTokenService: StoreTokenService) {

  }


  ngAfterViewInit(): void {
    this.initialData()
  }



  ngOnInit(): void {
    // this.googleDriveObserableService.googleAuthantication().subscribe((res) => {
    //    
    //   console.log(res)
    // })
  }


  initialData() {
    this.loadData.set(true)
    setTimeout(() => {
      this.loadData.set(true)
      this.googleDriveObserableService.getDataFromGoogleDriveData?.subscribe((res: any) => {

        if (res.moduleRoles.length > 0) {
          this.moduleAccessData = res.moduleRoles;
          this.setDataOnLocalStore(res.moduleRoles)
          this.loadDataLoad(res.moduleRoles)
        } else {
          this.setDefaultdata();
        }

        this.loadData.set(false)
      })
    }, 3000)
  }

  loadDataLoad(moduleAccessData: any) {
    debugger
    moduleAccessData.map((res: any) => {
      if (res.module) {
        this.modulesList.push(res.module)
        this.mudueleList();
      }
      if (res.permission) {
        this.permissionList.push(res.permission)
        this.permissionList = [...new Set(this.permissionList)];
      }
    })

  }


  setDataOnLocalStore(moduleAccessData: any) {
    const addModuleName = { "moduleRoles": moduleAccessData }
    sessionStorage.setItem('orginalDataMultipleCheckBox', JSON.stringify(addModuleName));
    sessionStorage.setItem('readyToDowloadData', JSON.stringify(addModuleName));

  }


  dynamicCreateData(modulesName: string) {

    let returnDynamicCreateData: any[] = [];
    let iterms: number = this.moduleAccessData.length;

    for (let i = 0; i < 1; i++) {
      for (let J = 0; J < this.permissionList.length; J++) {
        returnDynamicCreateData.push({ module: modulesName, permission: permission[J], ...rollAccessData, Id: iterms });
        iterms = iterms + 1;
      }
    }

    if (returnDynamicCreateData.length) {
      returnDynamicCreateData.map((module) => {
        if (module.module.length) {
          this.moduleAccessData.push({
            module: module.module, permission: module.permission, admin: module.admin, superUser: module.superUser, user: module.user, Id: module.Id
          });
        }
      })
      this.setDataOnLocalStore(this.moduleAccessData);
    }
  }

  editButton(accessName: string) {
    this.IsEditColumn = {
      admin: false,
      superUser: false,
      user: false,
    };

    switch (accessName) {
      case accessName = 'admin':
        this.IsEditColumn.admin = true;
        break;
      case accessName = 'superUser':
        this.IsEditColumn.superUser = true;
        break;
      case accessName = 'user':
        this.IsEditColumn.user = true;
        break;
    }
    this.moduleAccessData = JSON.parse(sessionStorage.getItem('orginalDataMultipleCheckBox') || '').moduleRoles;

  }

  selectModulesMethod() {


    this.IsEditColumn = {
      admin: false,
      superUser: false,
      user: false,
    };
    this.checkValidation(this.moduleControl);

    if (!this.moduleControlValidation) {
      if (this.moduleControl.length) {
        this.modulesList.push(this.moduleControl);

        this.dynamicCreateData(this.moduleControl);
        this.moduleControl = '';
      }
    }

  }

  checkValidation(moduleControl?: any) {

    this.moduleControlValidation = false; // Assuming moduleControlValidation is initially false

    this.modulesList.some((res) => {
      if (moduleControl == res.toLowerCase()) {
        this.moduleControlValidation = true;
        // this.moduleControl = '';
        return true; // Break the loop
      }
      return false; // Continue looping
    });
  }

  mudueleList() {
    let module: any[] = [];
    if (this.moduleAccessData.length > 0) {
      this.moduleAccessData.map((res: any) => {
        // if (res.length) {
        module.push(res.module);
        // }
      })
    }
    this.modulesList = [...new Set(module)];

  }

  oncheck(data: any, index: any, columnType: string, info: any) {
    let columnId: any;
    switch (columnType) {
      case columnType = 'admin':
        columnId = 1;
        this.moduleAccessData[index].admin = data.target.checked;
        break;
      case columnType = 'superUser':
        columnId = 2;
        this.moduleAccessData[index].superUser = data.target.checked;
        break;
      case columnType = 'user':
        columnId = 3;
        this.moduleAccessData[index].user = data.target.checked;
        break;
    }
  }

  moduleAccessDataGetter() {
    let readyToDowloadData
    if (sessionStorage.getItem('readyToDowloadData') != null) {
      readyToDowloadData = JSON.parse(sessionStorage.getItem('readyToDowloadData') || '');
    }

    this.moduleAccess = readyToDowloadData.length > 0 ? true : false;
  }

  removeElementById(arr: any, idToRemove: any) {
    return arr.filter((item: any) => item.Id != idToRemove);
  }

  updateButton(accessName?: string) {

    this.showLoader = true;
    this.setDataOnLocalStore(this.moduleAccessData);

    switch (accessName) {
      case accessName = 'admin':
        this.IsEditColumn.admin = false;
        break;
      case accessName = 'superUser':
        this.IsEditColumn.superUser = false;
        break;
      case accessName = 'user':
        this.IsEditColumn.user = false;
        break;
    }
    // this.removeRecord();
    this.moduleAccessDataGetter();
    this.UploadData();
    this.moduleAccessData = this.moduleAccessData;

    setTimeout(() => {
      this.showLoader = false;
    }, 6000)
    if (!this.showLoader) {
      window.alert("File upload successfuly on google drive.");
    }
  }

  exporJsonFileDownload() {

    // let data: any;
    // let date: any
    // let fileName: any
    // let exportType: any
    // setTimeout(() => {
    const data = { moduleRoles: this.newObject };
    const date = new Date();
    const fileName = `Export-${date.toLocaleDateString().split('/').join('-')}-${date.toLocaleTimeString().split(':').join('-')}`;
    const exportType = 'json';
    // }, 1000);

    setTimeout(() => {
      exportFromJSON({ data, fileName, exportType });
    }, 1000);
  }

  closeOverlay(): void {
    if (this.overlayRef) {
      this.overlayRef.detach();
      this.overlayRef = null;
    }
  }

  dragDropUploadFileEventSeve() {
    console.log('save');
  }

  dragDropUploadFile() {

    const fileInfo: any[] = [];
    let module: any[] = [];
    const fileElement = document.createElement('input');
    fileElement.setAttribute('type', 'file');
    fileElement.click();

    fileElement.addEventListener('change', (event) => {
      const inputElement = event.target as HTMLInputElement;
      const selectedFiles: FileList | null = inputElement.files;

      if (selectedFiles) {
        for (let i = 0; i < selectedFiles.length; i++) {
          fileInfo.push({
            fileName: selectedFiles[i].name,
            fileSize: `${selectedFiles[i].size} bytes`,
            fileType: selectedFiles[i].type,
            filePath: inputElement.value
          });
        }
      }

      const file = inputElement.files?.[0];

      if (file) {
        // let data: any
        const reader = new FileReader();
        reader.onload = function (e: any) {
          const fileContent = e.target?.result;
          sessionStorage.setItem('readyToDowloadData', fileContent);
          sessionStorage.setItem('orginalDataMultipleCheckBox', fileContent);
          // data = JSON.parse(fileContent);
          console.log(JSON.parse(fileContent));
        };
        reader.readAsText(file);

        // this.moduleAccessData = data.moduleRoles;
      }
    });
    this.uploadedFileInfo = fileInfo;
  }

  removeFile() {
    this.uploadedFileInfo = [];
  }

  UploadData() {
    this.showLoader = true;
    const sessionDataGet = sessionStorage.getItem('readyToDowloadData');

    this.googleDriveObserableService.fileuploadOnGoogleDrive(sessionDataGet)?.subscribe((res) => {
      window.alert(res);
      this.showLoader = false;
      this.moduleAccessData = JSON.parse(sessionDataGet || '').moduleRoles
    });
    this.removeFile();
    this.openModule = false;

    // const sessionDataGet = JSON.parse(sessionStorage.getItem('readyToDowloadData') || '');
    // this.moduleAccessData = sessionDataGet.moduleRoles

  }

  checkdata(event: any) {

    console.log(event)
  }

  inputData(event: any) {
    const file = event.target.files[0];

    if (file) {
      const reader = new FileReader();

      reader.onload = function (e: any) {
        const fileContent = e.target.result;

        try {

          const jsonData = JSON.parse(fileContent);
          console.log(jsonData)
        } catch (error) {

        }
      };

      reader.readAsText(file);
    }
  }

  closeOverlap(ref: any): void {


    ref.isOpen = false;

  }

  openModuleEvent() {


    this.openModule = true;
    this.IsEditColumn = {
      admin: false,
      superUser: false,
      user: false,
    };
  }

  editmoduleNameCheck(editmoduleNameRef: any) {

    this.IseditmoduleNameCheck = false;
    this.modulesList.some((res) => {
      if (editmoduleNameRef.toLowerCase() == res.toLowerCase()) {
        this.IseditmoduleNameCheck = true;

        return true; // Break the loop
      }
      return false; // Continue looping
    });
  }

  closeModuleEvent() {
    this.openModule = false;
  }

  deleteModule(selectOption?: any) {

    let data = JSON.parse(sessionStorage.getItem('readyToDowloadData') || '').moduleRoles;
    let removeModule: any[] = [];

    data.map((res: any) => {
      if (res.module !== selectOption.value) {
        removeModule.push({
          module: res.module, permission: res.permission, admin: res.admin, superUser: res.superUser, user: res.user, Id: res.Id
        });
      }
    })
    this.moduleAccessData = removeModule;
    this.uniqueModuleEvent(this.moduleAccessData, selectOption.value);

    this.setDataOnLocalStore(this.moduleAccessData);
    // this.modulesList = this.listModules;
    this.moduleControl = '';
    this.editmoduleName = '';
    this.moduleControlValidation = false;
    this.UploadData()
  }

  uniqueModuleEvent(dataobject: any, selectOption?: any) {


    let updateModule: any[] = [];

    dataobject.map((res: any) => {
      if (res.module !== selectOption) {
        updateModule.push(res.module);
      }
    })

    this.modulesList = [...new Set(updateModule)];
  }

  clearCheckBox(selectOption: any) {
    let filteredObject: any;
    if (selectOption.value !== 'default') {
      filteredObject = this.moduleAccessData.map((item: any) => {
        if (selectOption.value == item.module) {
          return ({
            ...item,
            admin: false,
            superUser: false,
            user: false
          })
        } else {
          return ({
            ...item
          })
        }
      })
    }
    else {
      const conformation = confirm("You sure!, checked checkbox you uncheck ?")

      if (conformation) {
        filteredObject = this.moduleAccessData.map((item: any) => ({
          ...item,
          admin: false,
          superUser: false,
          user: false
        }))
      }
      else {
        filteredObject = this.moduleAccessData;
      }
    }
    this.moduleAccessData = filteredObject;
    this.newObject = filteredObject;

    this.setDataOnLocalStore(this.moduleAccessData);
    this.moduleAccessDataGetter();
  }

  editCheckBox(selectOption?: any) {
    this.editModuleNameModal = this.editModuleNameModal ? false : true;

    if (this.editModuleNameModal == true) {
      this.editmoduleName = selectOption.value;
    }
  }

  selectChange(selectOption?: any) {

    if (selectOption !== "default" && selectOption.length > 0 && selectOption) {
      this.editmoduleName = selectOption;
    }
    else {
      this.editmoduleName = '';
    }

  }

  editModuleName() {

    this.editModuleNameModal = this.editModuleNameModal ? false : true;
  }

  changeModuleName(editmoduleNameRef: string) {
    let midifyData: any[] = [];
    this.moduleAccessData.map((res) => {

      if (res.module == this.editmoduleName) {
        res.module = editmoduleNameRef
      }
      midifyData.push(res);
    })
    this.setDataOnLocalStore(this.moduleAccessData);
    this.moduleControl = '';


    this.editCheckBox();
    this.mudueleList();
    this.checkValidation();

  }

  fileUploadContent(fileupload: any) {
    const file = fileupload.files[0];
    if (file) {
      const fileReader = new FileReader();

      fileReader.onload = (e) => {
        const fileContent = fileReader.result as string;
        setTimeout(() => {
          this.uploadFileToGoogleDrive(fileContent);
        }, 1000)

      };
      fileReader.readAsText(file);
    }
  }

  uploadFileToGoogleDrive(fileContent: any) {
    this.uploadModifyData = fileContent;
  }

  fileuploadOnGoogleDriveIcon(fileupload?: any) {

    // this.fileUploadService.fileuploadOnGoogleDrive(this.moduleAccessData);

  }

  downloadOnGoogleDrive() {
    this.googleDriveObserableService.downloadOnGoogleDrive();
  }

  refreshpage() {
    location.reload();
  }

  setDefaultdata() {

    this.googleDriveObserableService.setDefaultdataFromlocal().subscribe((res) => {
      this.setDataOnLocalStore(res);
      this.moduleAccessData = res;
      this.loadDataLoad(res)
    })
  }
  private getFileExtension(filename: string): string {
    return filename.split('.').pop() || '';
  }



                
}



interface fileType {
  fileName: string, fileSize: string, fileType: string, filePath: string
}