import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { JwtTokenImplementRoutingModule } from './jwt-token-implement-routing.module';
import { MainComponent } from './main/main.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FileUploadOnGoogleComponent } from './components/file-upload-on-google/file-upload-on-google.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { GoogleDriveObserableService } from 'src/app/modules/task-modules/modules/jwt-token-implement/services/google-drive-obserable.service';


@NgModule({
  declarations: [
    MainComponent,
    FileUploadOnGoogleComponent
  ],
  imports: [
    CommonModule,
    JwtTokenImplementRoutingModule,
    ReactiveFormsModule,
    ReactiveFormsModule,
    SharedModule,
    FormsModule
  ]
})
export class JwtTokenImplementModule { }
