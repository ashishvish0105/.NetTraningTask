import { Injectable, OnInit, ViewChild } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, EMPTY, Observable, Subject, catchError, from, map, mergeMap, of, single, switchMap, timeout, toArray } from 'rxjs';
import { GoogleloginComponent } from 'src/app/shared/googlelogin/googlelogin.component';
import { NewMultimpleArrayCheckComponent } from 'src/app/modules/task-components/components/new-multimple-array-check/new-multimple-array-check.component';
import { JsonPipe } from '@angular/common';
import { StoreTokenService } from './store-token.service';
import { Router } from '@angular/router';
declare var google: any;
@Injectable({
  providedIn: 'root'
})
export class GoogleDriveObserableService {
  accessToken: string = '';
  googleDriveList: any[] = [];
  tokenClient: any;
  access_token: any;
  getDataFromGoogleDriveData = new Subject();
  private readonly baseUrl = 'https://www.googleapis.com';
  // @ViewChild(GoogleloginComponent) Googlelogin!: GoogleloginComponent;
  @ViewChild(NewMultimpleArrayCheckComponent) NewMultimpleArrayCheck!: NewMultimpleArrayCheckComponent;

  constructor(private http: HttpClient, private storeTokenService: StoreTokenService, private router: Router) {
    if (!this.storeTokenService.get('accessToken')) {
      this.googleAuthantication();
    }
    else {
      this.tokenClient = this.storeTokenService.get('accessToken')
      this.filterSingleFileData();
    }
  }

  setDefaultdataFromlocal(): Observable<any> {
    return this.http.get('./assets/defaultData.json');
  }


  googleAuthantication() {
    let token: any;
    this.tokenClient = google.accounts.oauth2.initTokenClient({
      client_id: '631148325332-t36rn3c2isnhcjd7vm777fgsjs9ei8pc.apps.googleusercontent.com',
      scope: 'https://www.googleapis.com/auth/drive',
      callback: (tokenResponse: any) => {
        this.access_token = tokenResponse.access_token;
        token = this.access_token
        this.storeTokenService.set('accessToken', token)
      },
    });
    this.tokenClient.requestAccessToken()
  }

  filterSingleFileData(): Observable<any> {
    let singleFileData: any;
    this.googleDriveListMethod()?.subscribe({
      next: (fileData) => {
        fileData.files.map((file: any) => {
          if (file.name == "moduleRoleDoc.json") {
            this.getSingleFileData(file.id).subscribe(
              {
                next: (fileData) => {
                  this.getDataFromGoogleDriveData.next(fileData)
                  console.log(fileData)
                  return fileData;
                },
                error: (error) => {
                  if (error.status == 401) {
                    this.storeTokenService.remove('accessToken');
                    this.router.navigate(['/', 'taskModule', 'jwt-token-implement']);
                  }
                }
              });
          }
        });
      },
      error: (error) => {
         
        if (error.status == 401) {
          this.storeTokenService.remove('accessToken');
          this.router.navigate(['/', 'taskModule', 'jwt-token-implement']);
        }
      }
    });
    return singleFileData;
  }

  fileuploadOnGoogleDrive(uploadData: any): Observable<any> {
    return this.googleDriveListMethod().pipe(
      switchMap((fileData) => {
        let noFileFound = false;
        return from(fileData.files).pipe(
          mergeMap((file: any) => {
            if (file.name == "moduleRoleDoc.json") {
              return this.deleteFileFromGoogle(file.id);
            } else {
              noFileFound = true;
              return of(null); // Placeholder observable to continue the observable chain
            }
          }),
          toArray(),
          switchMap(() => {
            if (noFileFound) {
              return this.fileuploadMethod(uploadData);
            } else {
              return EMPTY; // Return an empty observable if no file found
            }
          })
        );
      })
    );
  }

  fileuploadMethod(uploadData: any): Observable<any> {
    return this.uploadFile(uploadData).pipe(
      switchMap((uploadResponse) => {
        const fileId = uploadResponse.id;
        const newName = "moduleRoleDoc.json";
        return this.updateFileName(fileId, newName).pipe(
          map(() => "Successfully uploaded file"),
          catchError(() => of("Error updating file name"))
        );
      }),
      catchError(() => of("Error uploading file"))
    );
  }

  // fileuploadMethod(uploadData: any): Observable<any> {
  //    
  //   let responseReturn: any;
  //   this.uploadFile(uploadData).subscribe({
  //     next: (uploadResponse) => {
  //        
  //       const fileId = uploadResponse.id;
  //       const newName = "moduleRoleDoc.json";
  //       this.updateFileName(fileId, newName)?.subscribe({
  //         next: (updateResponse) => {
  //           responseReturn = "successflt upload file";
  //         },
  //         error: (error) => {
  //           responseReturn = "issue file upload";
  //         }
  //       });
  //     },
  //     error: (error) => {
  //      responseReturn = "issue file upload";
  //     }
  //   });
  //   return responseReturn;

  // }

  deleteFileFromGoogle(fileId: any): Observable<any> {
    const token = this.storeTokenService.get('accessToken');
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return this.http.delete(`https://www.googleapis.com/drive/v3/files/${fileId}`, { headers })
  }

  updateFileName(fileId: string, newName: string): Observable<any> {
     
    const token = this.storeTokenService.get('accessToken');
    const headers = new HttpHeaders()
      .set('Authorization', `Bearer ${token}`);
    const metadata = { name: newName };
    return this.http.patch<any>(`https://www.googleapis.com/drive/v3/files/${fileId}`, metadata, { headers });
  }

  uploadFile(uploadData: any): Observable<any> {
     
    const baseUrl = 'https://www.googleapis.com/upload/drive/v3/files/';
    // const folderId: string = '1hqcdAR2NiQX-0e6dt_vkCHJih8zCeaPI';
    const token = this.storeTokenService.get('accessToken');
    const headers = new HttpHeaders()
      .set('Authorization', `Bearer ${token}`);

    return this.http.post<any>(`${baseUrl}?uploadType=media`, uploadData, { headers });
  }

  getSingleFileData(fileId: any): Observable<any> {
    const token = this.storeTokenService.get('accessToken');
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);

    return this.http.get(`${this.baseUrl}/drive/v3/files/${fileId}?alt=media`, { headers, responseType: 'blob' })
      .pipe(
        switchMap((response: Blob) => this.reanderdata(response))
      );
  }

  reanderdata(response: any): Promise<any> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const reader = new FileReader();
        reader.onload = () => {
          const Data: any = reader.result;
          const dataObject = JSON.parse(Data);
          resolve(dataObject);
        };
        reader.readAsText(response);
      }, 2000);
    });
  }

  googleDriveListMethod(): Observable<any> {
     
    const token = this.storeTokenService.get('accessToken');
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return this.http.get(`${this.baseUrl}/drive/v3/files`, { headers });
  }

  downloadOnGoogleDrive() {
    const token = this.storeTokenService.get('accessToken');
    const headers = new HttpHeaders()
      .set('Authorization', `Bearer ${token}`);

    this.http.get('https://www.googleapis.com/drive/v3/files', { headers }).subscribe((googleDriveList: any) => {
      googleDriveList.files.map((res: any) => {
         
        if (res.name == "moduleRoleDoc.json") {
          this.http.get(`https://www.googleapis.com/drive/v3/files/${res.id}?alt=media`, { headers, responseType: 'blob' })
            .subscribe((response: Blob) => {
               
              // Create a blob URL from the file content
              const blob = new Blob([response], { type: 'application/octet-stream' });
              const url = window.URL.createObjectURL(blob);

              // Create a link element and trigger the download
              const link = document.createElement('a');
              link.href = url;
              link.download = 'moduleRoleDoc.json'; // Provide the desired file name
              document.body.appendChild(link);
              link.click();
              window.URL.revokeObjectURL(url);
            }, error => {
              console.error('Error downloading file:', error);
            });
        }
      })
    })

  }
}



