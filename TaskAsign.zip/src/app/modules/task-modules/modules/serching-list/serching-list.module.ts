import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SerchingListRoutingModule } from './serching-list-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { MainComponent } from './main/main.component';
import { SearchingListService } from './searching-list.service';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    MainComponent
  ],
  imports: [
    CommonModule,
    SerchingListRoutingModule,
    SharedModule,
    FormsModule
  ],
  providers: [
    SearchingListService
  ]
})
export class SerchingListModule { }
