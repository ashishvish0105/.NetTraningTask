
import { Component, OnInit } from '@angular/core';
import { SearchingListService } from '../searching-list.service';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})
export class MainComponent implements OnInit {
  Searchingdata: any;
  constructor(private _searchingListService: SearchingListService) {

  }
  ngOnInit(): void {

  }

  webSearchingEvent(webSearching: string) {
     
    this._searchingListService.stackexchangeSearch(webSearching).subscribe((res: any) => {
      this.Searchingdata = res.items;
    })
  }


}