
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { stackOverFlow } from 'src/app/core/apiContext';

@Injectable({
  providedIn: 'root'
})
export class SearchingListService {

  constructor(private http: HttpClient) { }


  stackexchangsAnswersGetdata(page: number, pagesize: number) {
     
    return this.http.get(`${stackOverFlow.stackexchangsAnswers}/2.3/answers?page=${page}&pagesize=${pagesize}&order=asc&sort=activity&site=stackoverflow`);
  }

  stackexchangeSearch(searchingText: string) {
    return this.http.get(`https://api.stackexchange.com/2.3/search?key=U4DMV*8nvpm3EOpvf69Rxw((&site=stackoverflow&page=1&pagesize=5&order=desc&sort=activity&intitle=${searchingText}&filter=default`)
  }
}
