import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GoogleDriveRoutingModule } from './google-drive-routing.module';
import { MainComponent } from './main/main.component';
import { FileUploadComponent } from './components/file-upload/file-upload.component';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [
    MainComponent,
    FileUploadComponent
  ],
  imports: [
    CommonModule,
    GoogleDriveRoutingModule
  ]
})
export class GoogleDriveModule { }
