import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
declare var gapi: any;

@Injectable({
    providedIn: 'root'
})
export class GoogleDriveService {
    Client_ID = '631148325332-t36rn3c2isnhcjd7vm777fgsjs9ei8pc.apps.googleusercontent.com';
    Api_key = "AIzaSyBJY95xVnAUbRrhKDTraPJE6CM3iGFbVFY";
    scopes = "https://www.googleapis.com/auth/drive";
    discovery_docs = ['https://www.googleapis.com/discovery/v1/apis/drive/v3/rest'];
    constructor(private http: HttpClient) { }

    initClient() {
        return new Promise<void>((resolve, reject) => {
            gapi.load('client', () => {
                gapi.client.init({
                    apiKey: this.Api_key,
                    clientId: this.Client_ID,
                    discoveryDocs: ['https://www.googleapis.com/discovery/v1/apis/drive/v3/rest'],
                    scope: 'https://www.googleapis.com/auth/drive'
                }).then(() => {
                    resolve();
                }).catch((error: any) => {
                    reject(error);
                });
            });
        });
    }

    signIn() {
        return gapi.auth2.getAuthInstance().signIn();
    }

    uploadFile(fileName: string, folderId: string) {
        const fileContent = 'Hello, world!';
        const file = new Blob([fileContent], { type: 'text/plain' });
        const metadata = {
            name: fileName,
            parents: [folderId]
        };

        const formData = new FormData();
        formData.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
        formData.append('file', file);

        return gapi.client.drive.files.create({
            resource: metadata,
            media: {
                mimeType: 'text/plain',
                body: file
            }
        });
    }

    searchFolder(folderName: string) {
        return gapi.client.drive.files.list({
            q: `mimeType='application/vnd.google-apps.folder' and name='${folderName}'`,
            fields: 'files(id, name)'
        });
    }

    createFolder(folderName: string, parentFolderId: string) {
        const fileMetadata = {
            name: folderName,
            mimeType: 'application/vnd.google-apps.folder',
            parents: [parentFolderId]
        };

        return gapi.client.drive.files.create({
            resource: fileMetadata,
            fields: 'id'
        });
    }
}
