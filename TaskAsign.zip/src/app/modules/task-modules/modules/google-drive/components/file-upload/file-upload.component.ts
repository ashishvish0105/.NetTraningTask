import { Component, OnInit } from '@angular/core';
import { GoogleDriveService } from '../../services/google-drive.service';
declare var gapi: any;
@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.scss']
})
export class FileUploadComponent implements OnInit {

  IsGooglelogin = false;


  constructor(private googleDriveService: GoogleDriveService) { }

  ngOnInit(): void {
    // Initialize the Google Drive API client
    this.googleDriveService.initClient().then(() => {
      console.log('Google Drive API initialized successfully');
    }).catch((error: any) => {
      console.error('Error initializing Google Drive API:', error);
    });
  }

  signIn() {
    // Authenticate the user
    this.googleDriveService.signIn().then(() => {
      console.log('User authenticated successfully');
    }).catch((error: any) => {
      console.error('Error authenticating user:', error);
    });
  }

  uploadFile() {
    // Upload a file
    this.googleDriveService.uploadFile('file.txt', 'Folder ID').then((response: { result: any; }) => {
      console.log('File uploaded:', response.result);
    }).catch((error: any) => {
      console.error('Error uploading file:', error);
    });
  }

  searchFolder() {
    // Search for a folder
    this.googleDriveService.searchFolder('Folder Name').then((response: { result: { files: any; }; }) => {
      const folders = response.result.files;
      if (folders && folders.length > 0) {
        console.log('Folder found:', folders[0]);
      } else {
        console.log('Folder not found');
      }
    }).catch((error: any) => {
      console.error('Error searching for folder:', error);
    });
  }

  createFolder() {
    // Create a folder
    this.googleDriveService.createFolder('New Folder', 'Parent Folder ID').then((response: { result: any; }) => {
      console.log('Folder created:', response.result);
    }).catch((error: any) => {
      console.error('Error creating folder:', error);
    });
  }









  // ngOnInit(): void {
  //   gapi.load('client', this.initclient());
  // }

  // initclient() {
  //   gapi.client.init(
  //     {
  //       apiKey: this.Api_key,
  //       clientId: this.Client_ID,
  //       discoveryDocs: this.discovery_docs,
  //       scope: this.scopes,
  //     }
  //   ).then(() => {
  //     return gapi.auth2.getAuthInstance().signIn();
  //     // gapi.auth2.getAuthInstance().isSignedIn.Listen(this.updat);
  //   }).then(() => {
  //     // Upload a file
  //     let folderId = "1hqcdAR2NiQX-0e6dt_vkCHJih8zCeaPI"
  //     this.uploadFile('file.txt', folderId);

  //     // Search for a folder
  //     // this.searchFolder('Folder Name');

  //     // // Create a folder
  //     // this.createFolder('New Folder', 'Parent Folder ID');
  //   }).catch((error: any) => {
  //     console.error('Error initializing the Google Drive API:', error);
  //   });
  // }

  // uploadFile(fileName: any, folderId: any) {
  //   const fileContent = 'Hello, world!';
  //   const file = new Blob([fileContent], { type: 'text/plain' });
  //   const metadata = {
  //     name: fileName,
  //     parents: [folderId]
  //   };
  //   const formData = new FormData();
  //   formData.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
  //   formData.append('file', file);

  //   gapi.client.drive.files.create({
  //     resource: metadata,
  //     media: {
  //       mimeType: 'text/plain',
  //       body: file
  //     }
  //   }).then((response: any) => {
  //     console.log('File uploaded:', response.result);
  //   }).catch((error: any) => {
  //     console.error('Error uploading file:', error);
  //   });
  // }


  // searchFolder(folderName: any) {
  //   gapi.client.drive.files.list({
  //     q: `mimeType='application/vnd.google-apps.folder' and name='${folderName}'`,
  //     fields: 'files(id, name)'
  //   }).then((response: any) => {
  //     const folders = response.result.files;
  //     if (folders && folders.length > 0) {
  //       console.log('Folder found:', folders[0]);
  //     } else {
  //       console.log('Folder not found');
  //     }
  //   }).catch((error: any) => {
  //     console.error('Error searching for folder:', error);
  //   });
  // }

  // createFolder(folderName: any, parentFolderId: any) {
  //   const fileMetadata = {
  //     name: folderName,
  //     mimeType: 'application/vnd.google-apps.folder',
  //     parents: [parentFolderId]
  //   };

  //   gapi.client.drive.files.create({
  //     resource: fileMetadata,
  //     fields: 'id'
  //   }).then((response: any) => {
  //     console.log('Folder created:', response.result);
  //   }).catch((error: any) => {
  //     console.error('Error creating folder:', error);
  //   });
  // }
}
