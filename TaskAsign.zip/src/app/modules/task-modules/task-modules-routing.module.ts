import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainComponent } from './main/main.component';
import { ModulelistComponent } from './components/modulelist/modulelist.component';

const routes: Routes = [
  {
    path: '',
    component: MainComponent,
    // children: [
    //   {
    //     path: '',
    //     component: ModulelistComponent
    //   },
      // {
      //   path: 'single search',
      //   loadChildren: () => import('./modules/serching-list/serching-list.module').then(m => m.SerchingListModule)
      // },
      // {
      //   path: 'google drive',
      //   loadChildren: () => import('./modules/google-drive/google-drive.module').then(m => m.GoogleDriveModule)
      // }, {
      //   path: 'jwt-token-implement',
      //   loadChildren: () => import('./modules/jwt-token-implement/jwt-token-implement.module').then(m => m.JwtTokenImplementModule)
      // }
    // ]

  },
  {
    path: 'single search',
    loadChildren: () => import('./modules/serching-list/serching-list.module').then(m => m.SerchingListModule)
  },
  {
    path: 'google drive',
    loadChildren: () => import('./modules/google-drive/google-drive.module').then(m => m.GoogleDriveModule)
  }, {
    path: 'jwt-token-implement',
    loadChildren: () => import('./modules/jwt-token-implement/jwt-token-implement.module').then(m => m.JwtTokenImplementModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TaskModulesRoutingModule { }
