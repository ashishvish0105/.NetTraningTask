﻿namespace IdentiuServerDemo.Models
{
    public class UserInfo
    {
        public int UserId { get; set; }
        public string? UserName { get; set; }
        public string? Email { get; set; }  = null;
        public string? password { get; set; }

    }
}
