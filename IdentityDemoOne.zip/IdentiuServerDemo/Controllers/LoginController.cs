﻿using Microsoft.AspNetCore.Mvc;

namespace IdentiuServerDemo.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View("~/Areas/Identity/Pages/Account/Login.cshtml");
        }
    }
}
