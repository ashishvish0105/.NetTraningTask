﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ApiDemoTopic.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        [HttpGet]
        public async Task<IActionResult> Login()
        {
            var data = new
            {
                userName = "ashish",
                password = "ashish@123"
            };

            return await Task.FromResult(Ok(data));
        }

    }
}
