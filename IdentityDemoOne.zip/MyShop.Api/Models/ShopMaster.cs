﻿using System.ComponentModel.DataAnnotations;

namespace MyShop_Api.Models
{
    public class ShopMaster
    {
        [Key]
        public int ShopID { get; set; }
        public string ShopName { get; set; }
        public string ShopAddress { get; set; }
        public string ShopContact { get; set; }
        public int OwnerID { get; set; }
        public string OwnerName { get; set; }
        public string OwnerContact { get; set; }
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public string EmployeeContact { get; set; }
    }

    public class InsertShopMaster
    {
        public string ShopName { get; set; }
        public string ShopAddress { get; set; }
        public string ShopContact { get; set; }
        public int OwnerID { get; set; }
        public string OwnerName { get; set; }
        public string OwnerContact { get; set; }
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public string EmployeeContact { get; set; }
    }
}
