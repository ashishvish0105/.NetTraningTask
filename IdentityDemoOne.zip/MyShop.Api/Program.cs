
using Microsoft.EntityFrameworkCore;
using myshop.api.Interface;
using myshop.api.Services;
using myshop.Data.Data;
using myshop.service.Services;
//using myshop.api.Data;
//using myshop.api.Interface;
//using myshop.api.Services;
using myshop.service.Interface;
using myshop.api.HelperServices;
using myshop.service.HelperServices;
using System.Configuration;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Configuration;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//DataBaseHelper returnobject = new DataBaseHelper();

//DbServices.setDbcontext(returnobject.ReturnDbcontext());

//DbServices.setDbcontext();



ConfigurationSetting.setValueConfiguration(builder.Configuration);

//builder.Services.AddDbContext<MyShopContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("defaultConnection")));
//builder.Services.AddDbContext<MyShopContext>(option => option.UseSqlServer(builder.Configuration.GetConnectionString("defaultConnection")).ServiceLifetime.Singleton);

//builder.Services.AddDbContext<MyShopContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("defaultConnection")),ServiceLifetime.Singleton);

// Configure DbContextOptions
var optionsBuilder = new DbContextOptionsBuilder<MyShopContext>();
optionsBuilder.UseSqlServer(builder.Configuration.GetConnectionString("defaultConnection"));

// Register DataBaseServices as a singleton
builder.Services.AddDbContext<MyShopContext>(ServiceLifetime.Singleton);

//DbServices.setDbcontext(DataBaseHelper.ReturnDbcontext());

builder.Services.AddScoped<IShopMasterService, shopMasterWithDbFirst>();
builder.Services.AddScoped<IStoreProcedureInterface, StoreProcedureService>();


var app = builder.Build();
using (var scope = app.Services.CreateScope())
{
    MyShopContext dbContext = scope.ServiceProvider.GetRequiredService<MyShopContext>();
    DbContextData.SetDbcontextData(new DataBaseServices(dbContext).ReturnDbcontext());


    //MyShopContext database = new MyShopContext(dbContext);
    //}
    //using (var scope = app.Services.CreateScope())
    //{
    //    MyShopContext dbContext = scope.ServiceProvider.GetRequiredService<MyShopContext>();

    //DbContextData dbcon = new DbContextData(dbContext);

    //DbServices.setDbcontext(dbContext);
    //}
}

    // Configure the HTTP request pipeline.
    if (app.Environment.IsDevelopment())
    {
        app.UseSwagger();
        app.UseSwaggerUI();
    }

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
