﻿using myshop.Data.Data;

namespace myshop.api.HelperServices
{
    public class DataBaseServices
    {
        public  MyShopContext _dbContext;

        public DataBaseServices(MyShopContext dbContext)
        {
            _dbContext = dbContext;
        }

        public MyShopContext ReturnDbcontext()
        {
            return _dbContext;
        }

    }
}
