﻿using Microsoft.AspNetCore.Mvc;
using myshop.api.Services;

namespace myshop.api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AppConfigController : ControllerBase
    {

        public AppConfigController(){}

        //[HttpGet]
        //public IActionResult GetConnnectiontring() {
        //    ConfigurationSetting _config = new ConfigurationSetting(_configuration);
        //    var data = _config.getProjectName();
        //    return Ok(data);
        //}


        [HttpGet]
        public IActionResult GetConnnectiontring()
        {
            var data = ConfigurationSetting.getProjectName("ProjectName");
            return Ok(data);
        }

        [HttpPost]
        public IActionResult GetConnnectiontring(string keyName)
        {
            var data = ConfigurationSetting.getProjectName(keyName);
            return Ok(data);
        }

    }
}
