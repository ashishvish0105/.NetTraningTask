﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using myshop.service.Interface;
using myshop.service.Model;
using System.Threading.Tasks;

namespace myshop.api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StoreProcedureController : ControllerBase
    {
        private readonly IStoreProcedureInterface _storeProcedureInterface;
        public StoreProcedureController(IStoreProcedureInterface storeProcedureInterface)
        {
            _storeProcedureInterface= storeProcedureInterface;
        }

        [HttpGet]
        public async Task<IActionResult> getShopListSp() {

            List<ShopMasterDTO> data = await _storeProcedureInterface.getShopListSp();

            return Ok(data);
        }
    }
}
