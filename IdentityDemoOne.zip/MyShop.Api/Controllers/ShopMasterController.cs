﻿using Microsoft.AspNetCore.Mvc;
using myshop.api.Interface;
using myshop.service.Model;

namespace myshop.api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShopMasterController : ControllerBase
    {
        private readonly IShopMasterService _shopMasterService; 
        public ShopMasterController(IShopMasterService shopMater) {
            _shopMasterService = shopMater;
        }

        [HttpGet]
        [Route("GetListShop")]
        public async Task<IActionResult> GetListShop() {
            List<ShopMasterDTO> ShopMaster  = await _shopMasterService.GetListShop();

            var item = from s in ShopMaster where s.EmployeeId == 1 select s;

            return Ok(ShopMaster);
        }


        [HttpGet]
        [Route("ShopDetail")]
        public async Task<IActionResult> ShopDetail(int shopId)
        {
            ShopMasterDTO ShopMaster = await _shopMasterService.ShopDetail(shopId);
            return Ok(ShopMaster);
        }

        [HttpPost]
        [Route("InsertShopDetail")]
        public async Task<IActionResult> InsertShopDetail(ShopMasterDTO shopDetail)
        {
            bool IsInsert = await _shopMasterService.InsertShopDetail(shopDetail);
            if (IsInsert)
            {
                return Ok("Successfly Insert Record");
            }
            else
            {
                return NotFound("Not Inserted record");
            }
        }

        [HttpPut]
        [Route("UpdateShopDetail")]
        public async Task<IActionResult> UpdateShopDetail(ShopMasterDTO shopDetail)
        {
            bool IsInsert = await _shopMasterService.UpdateShopDetail(shopDetail);
            if (IsInsert)
            {
                return Ok("Successfly Update Record");
            }
            else
            {
                return NotFound("Not Inserted record");
            }
        }
        [HttpDelete]
        [Route("DeleteShopDetail")]
        public async Task<IActionResult> DeleteShopDetail(int ShopId)
        {
            bool IsInsert = await _shopMasterService.DeleteShopDetail(ShopId);
            if (IsInsert)
            {
                return Ok("Successfly Update Record");
            }
            else
            {
                return NotFound("Not Inserted record");
            }
        }
    }
}
