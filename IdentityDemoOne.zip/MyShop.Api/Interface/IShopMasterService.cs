﻿
using myshop.api.Data;

namespace myshop.api.Interface
{
    public interface IShopMasterService
    {
        public Task<List<ShopMaster>> GetListShop();
        public Task<bool> InsertShopDetail(ShopMaster shopMaster);
        public Task<bool> DeleteShopDetail(int ShopID);
        public Task<bool> UpdateShopDetail(ShopMaster shop);
        public Task<ShopMaster> ShopDetail(int ShopID);

    }
}
