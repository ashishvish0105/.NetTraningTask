﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace myshop.api.Data;

public partial class MyShopContext : DbContext
{
    public MyShopContext()
    {
    }

    public MyShopContext(DbContextOptions<MyShopContext> options)
        : base(options)
    {
    }

    public virtual DbSet<ShopMaster> ShopMasters { get; set; }

//    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
//        => optionsBuilder.UseSqlServer("Data Source=DESKTOP-3P7C59Q;Initial Catalog=MyShop;Persist Security Info=True;User ID=sa;Password=vision;Encrypt=True;Trust Server Certificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<ShopMaster>(entity =>
        {
            entity.HasKey(e => e.ShopId).HasName("PK__ShopMast__67C556291E463C38");

            entity.ToTable("ShopMaster");

            entity.Property(e => e.ShopId).HasColumnName("ShopID");
            entity.Property(e => e.EmployeeContact).HasMaxLength(50);
            entity.Property(e => e.EmployeeId).HasColumnName("EmployeeID");
            entity.Property(e => e.EmployeeName).HasMaxLength(100);
            entity.Property(e => e.OwnerContact).HasMaxLength(50);
            entity.Property(e => e.OwnerId).HasColumnName("OwnerID");
            entity.Property(e => e.OwnerName).HasMaxLength(100);
            entity.Property(e => e.ShopAddress).HasMaxLength(255);
            entity.Property(e => e.ShopContact).HasMaxLength(50);
            entity.Property(e => e.ShopName).HasMaxLength(100);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
