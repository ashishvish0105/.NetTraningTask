﻿using Microsoft.EntityFrameworkCore;

namespace myshop.api.Data
{
    public class DataBaseContext:DbContext
    {
        public DataBaseContext(DbContextOptions<DataBaseContext> dbContextOptions):base(dbContextOptions) { }

        public DbSet<ShopMaster> ShopMaster {  get; set; } 
    }
}
