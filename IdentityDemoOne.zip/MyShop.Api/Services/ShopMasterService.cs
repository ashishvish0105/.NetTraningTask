﻿using Microsoft.EntityFrameworkCore;
using MyShop_Api.Data;
using MyShop_Api.Interface;
using MyShop_Api.Models;

namespace MyShop_Api.Services
{
    public class ShopMasterService : IShopMasterService
    {
        private readonly DataBaseContext _dbcontext;
        public ShopMasterService(DataBaseContext dbcontext)
        {
            _dbcontext = dbcontext;
        }

        public async Task<List<Data.ShopMaster>> GetListShop()
        {
            List<Data.ShopMaster> ShopMaster = await _dbcontext.ShopMaster.ToListAsync();
            return ShopMaster;
        }

        public async Task<Data.ShopMaster> ShopDetail(int ShopID)
        {
            Data.ShopMaster ShopMaster = await _dbcontext.ShopMaster.FirstOrDefaultAsync(x => x.ShopId == ShopID);
            return ShopMaster;
        }

        public async Task<bool> UpdateShopDetail(Data.ShopMaster shop)
        {
            var shopDetail = await _dbcontext.ShopMaster.FirstOrDefaultAsync(x => x.ShopId == shop.ShopId);

            if (shopDetail == null)
            {
                return false;
            }

            Data.ShopMaster ShopMaster = new Data.ShopMaster()
            {
                ShopAddress = shop.ShopAddress,
                ShopName = shop.ShopName,
                EmployeeContact = shop.EmployeeContact,
                EmployeeId = shop.EmployeeId,
                EmployeeName = shop.EmployeeName,
                OwnerContact = shop.OwnerContact,
                OwnerId = shop.OwnerId,
                OwnerName = shop.OwnerName,
                ShopContact = shop.ShopContact,
            };

            _dbcontext.ShopMaster.Update(ShopMaster);
            int IsUpdatedate = await _dbcontext.SaveChangesAsync();


            return IsUpdatedate > 0 ? true : false;
        }

        public async Task<bool> DeleteShopDetail(int ShopID)
        {
            Data.ShopMaster shopDetail = await _dbcontext.ShopMaster.FirstOrDefaultAsync(x => x.ShopId == ShopID);

            if (shopDetail == null)
            {
                return false;
            }

            _dbcontext.ShopMaster.Remove(shopDetail);
            int ISdelete = await _dbcontext.SaveChangesAsync();

            return ISdelete > 0 ? true : false;
        }

        public async Task<bool> InsertShopDetail(InsertShopMaster shopMaster)
        {
            Data.ShopMaster ShopMaster = new Data.ShopMaster()
            {
                ShopId = 0,
                ShopAddress = shopMaster.ShopAddress,
                ShopName = shopMaster.ShopName,
                EmployeeContact = shopMaster.EmployeeContact,
                EmployeeId= shopMaster.EmployeeID,
                EmployeeName = shopMaster.EmployeeName,
                OwnerContact = shopMaster.OwnerContact,
                OwnerId = shopMaster.OwnerID,
                OwnerName = shopMaster.OwnerName,
                ShopContact = shopMaster.ShopContact,
            };

            if (shopMaster == null)
            {
                return false;
            }
            _dbcontext.ShopMaster.AddAsync(ShopMaster);

            int ISdelete = await _dbcontext.SaveChangesAsync();

            return ISdelete > 0 ? true : false;
        }



    }
}
