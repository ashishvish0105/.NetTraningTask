﻿using Microsoft.EntityFrameworkCore;
using myshop.api.Data;
using myshop.api.Interface;

namespace myshop.api.Services
{
    public class shopMasterWithDbFirst: IShopMasterService
    {


        private readonly DataBaseContext _dbcontext;
        public shopMasterWithDbFirst(DataBaseContext dbcontext)
        {
            _dbcontext = dbcontext;
        }

        public async Task<List<ShopMaster>> GetListShop()
        {
            List<ShopMaster> ShopMaster = await _dbcontext.ShopMaster.ToListAsync();
            return ShopMaster;
        }

        public async Task<ShopMaster> ShopDetail(int ShopID)
        {
            ShopMaster ShopMaster = await _dbcontext.ShopMaster.FirstOrDefaultAsync(x => x.ShopId == ShopID);
            return ShopMaster;
        }

        public async Task<bool> UpdateShopDetail(ShopMaster shop)
        {
            var shopDetail = await _dbcontext.ShopMaster.FirstOrDefaultAsync(x => x.ShopId == shop.ShopId);

            if (shopDetail == null)
            {
                return false;
            }

            ShopMaster ShopMaster = new ShopMaster()
            {
                ShopAddress = shop.ShopAddress,
                ShopName = shop.ShopName,
                EmployeeContact = shop.EmployeeContact,
                EmployeeId = shop.EmployeeId,
                EmployeeName = shop.EmployeeName,
                OwnerContact = shop.OwnerContact,
                OwnerId= shop.OwnerId,
                OwnerName = shop.OwnerName,
                ShopContact = shop.ShopContact,
            };

            _dbcontext.ShopMaster.Update(ShopMaster);
            int IsUpdatedate = await _dbcontext.SaveChangesAsync();


            return IsUpdatedate > 0 ? true : false;
        }

        public async Task<bool> DeleteShopDetail(int ShopID)
        {
            ShopMaster shopDetail = await _dbcontext.ShopMaster.FirstOrDefaultAsync(x => x.ShopId == ShopID);

            if (shopDetail == null)
            {
                return false;
            }

            _dbcontext.ShopMaster.Remove(shopDetail);
            int ISdelete = await _dbcontext.SaveChangesAsync();

            return ISdelete > 0 ? true : false;
        }

        public async Task<bool> InsertShopDetail(ShopMaster shopMaster)
        {
            ShopMaster ShopMaster = new ShopMaster()
            {
                ShopId = 0,
                ShopAddress = shopMaster.ShopAddress,
                ShopName = shopMaster.ShopName,
                EmployeeContact = shopMaster.EmployeeContact,
                EmployeeId = shopMaster.EmployeeId,
                EmployeeName = shopMaster.EmployeeName,
                OwnerContact = shopMaster.OwnerContact,
                OwnerId = shopMaster.OwnerId,
                OwnerName = shopMaster.OwnerName,
                ShopContact = shopMaster.ShopContact,
            };

            if (shopMaster == null)
            {
                return false;
            }
            _dbcontext.ShopMaster.AddAsync(ShopMaster);

            int ISdelete = await _dbcontext.SaveChangesAsync();

            return ISdelete > 0 ? true : false;
        }

    }
}
