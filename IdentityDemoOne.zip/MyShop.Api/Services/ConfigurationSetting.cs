﻿namespace myshop.api.Services
{
    public static class ConfigurationSetting
    {
        private static IConfiguration _configuration;


        public static string getProjectName(string objctKeyName)
        {
            return _configuration.GetValue<string>(objctKeyName);
        }
        public static void setValueConfiguration(IConfiguration configuration)
        {
            _configuration = configuration;
        }
    
    }
}
