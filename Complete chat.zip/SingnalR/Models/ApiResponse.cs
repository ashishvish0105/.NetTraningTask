﻿namespace SingnalR.Models
{
    public class ApiResponse
    {
        public bool? success { get; set; }
        public int statusCode { get; set; }
        public string? Message { get; set; }
        public object? Data { get; set; }

        public ApiResponse()
        {
            success = false;
            statusCode = 500;
            Message = "default message";
            Data = null;
        }

    }
}
