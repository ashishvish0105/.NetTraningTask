using Microsoft.AspNetCore.Mvc;
using SingnalR.InserFaces;
using SingnalR.Models;
using SingnalR.Services;
using System.Diagnostics;

namespace SingnalR.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IMessage _messageServices;

        public HomeController(ILogger<HomeController> logger, IMessage messageServices)
        {
            _logger = logger;
            _messageServices = messageServices;
        }
        public IActionResult Index()
        {
            List<GetMesssage> GetListMesssage = _messageServices.GetListMessage();
            return View(GetListMesssage);
        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
