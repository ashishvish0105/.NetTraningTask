﻿using Microsoft.AspNetCore.SignalR;
using SingnalR.InserFaces;
using SingnalR.Models;
using SingnalR.Services;

namespace SingnalR.Hubs
{
    public class ChatHub : Hub
    {
        private readonly IMessage messageServices;
        public ChatHub(IMessage _messageServices)
        {
            messageServices = _messageServices;
        }

        public async Task SendMessage(string user, string message)
        {
            MessageModel MessageModel = new MessageModel()
            {
                UseName = user,
                Messgae = message
            };

            messageServices.InsertMessage(MessageModel);
            //await Clients.All.SendAsync("ReceiveMessage", user, message);
        }

        //public async Task SendMessage(string user, string message)
        //{
        //    await Clients.All.SendAsync("ReceiveMessage", user, message);
        //}

        public async Task GetListMessage()
            {
            List<GetMesssage> messsages = messageServices.GetListMessage();
            await Clients.All.SendAsync("GetListMessage", messsages);
        }

        public async Task GetMessage()
        {
            GetMesssage messsages = messageServices.GetMessage();
            await Clients.All.SendAsync("DisplayIsertedMessage", messsages);
        }

        //public async Task StartAsync(CancellationToken cancellationToken)
        //{
        //    List<GetMesssage> messsages = messageServices.GetListMessage();
        //    await Clients.All.SendAsync("GetListMessage", messsages);
        //}

        //public Task StopAsync(CancellationToken cancellationToken)
        //{
        //    // Your implementation here
        //    return Task.CompletedTask;
        //}

        //public async Task SendUpdate(string message)
        //{
        //    await Clients.All.SendAsync("ReceiveUpdate", message);
        //}


    }
}
