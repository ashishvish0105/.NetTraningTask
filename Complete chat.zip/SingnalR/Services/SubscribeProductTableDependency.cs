﻿using SingnalR.AppData.TablesEntity;
using SingnalR.Hubs;
using SingnalR.InserFaces;
using TableDependency.SqlClient;
using TableDependency.SqlClient.Base;

namespace SingnalR.Services
{
    public class SubscribeProductTableDependency : ISubscribeTableDependency
    {
        public SqlTableDependency<MessageTable> tableDependency;
        public ChatHub dashboardHub;
        private DateTime _lastCheckTime;

        public SubscribeProductTableDependency(ChatHub dashboardHub)
        {
            this.dashboardHub = dashboardHub;
        }

        public void SubscribeTableDependency(string connectionString)
        {
            tableDependency = new SqlTableDependency<MessageTable>(connectionString);
            tableDependency.OnChanged += TableDependency_OnChanged;
            tableDependency.OnError += TableDependency_OnError;
            tableDependency.Start();
        }

        private async void TableDependency_OnChanged(object sender, TableDependency.SqlClient.Base.EventArgs.RecordChangedEventArgs<MessageTable> e)
        { 
            if (e.ChangeType == TableDependency.SqlClient.Base.Enums.ChangeType.Update)
            {
                await dashboardHub.GetListMessage();
            }

            if (e.ChangeType == TableDependency.SqlClient.Base.Enums.ChangeType.Insert)
            {
                await dashboardHub.GetMessage();
            }
        }
        //public async void MessageSetup()
        //{
        //    await dashboardHub.GetListMessage();
        //}

        private void TableDependency_OnError(object sender, TableDependency.SqlClient.Base.EventArgs.ErrorEventArgs e)
        {
            Console.WriteLine($"{nameof(MessageTable)} SqlTableDependency error: {e.Error.Message}");
        }

    }
}
