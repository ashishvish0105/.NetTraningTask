﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using SingnalR.AppData;
using SingnalR.AppData.TablesEntity;
using SingnalR.InserFaces;
using SingnalR.Models;
using System.Collections.Generic;

namespace SingnalR.Services
{
    public class MessageServices: IMessage
    {
        private readonly AppDatabase _dbcontext;
        private readonly IMapper _mapper;
        public MessageServices(AppDatabase dbcontext, IMapper mapper) {
            _dbcontext = dbcontext;
            _mapper = mapper;   
        }

        public bool InsertMessage(MessageModel message)
        {
            try
            {
                //MessageTable MesT = new MessageTable()
                //{
                //    UseName = message.UseName,
                //    Messgae = message.Messgae,
                //    MessageCoute = 1,
                //};

                //_dbcontext.MessageTable.Add(MesT);
                //int returnResult = _dbcontext.SaveChanges();

                var returnResult = _dbcontext.Database.ExecuteSqlRaw("INSERT INTO MessageTable(UseName, Messgae) VALUES (@p0, @p1)", message.UseName, message.Messgae);

                if (returnResult > 0)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return false;
        }
        public List<GetMesssage> GetListMessage()
        {
            List<MessageTable> listMessageTable = _dbcontext.MessageTable.Where(x=>x.UseName== "User2" || x.UseName=="User1").ToList();
          

            foreach (var emp in listMessageTable)
            {
                _dbcontext.Entry(emp).Reload();
            }
            List<GetMesssage> getMesssages = _mapper.Map<List<GetMesssage>>(listMessageTable);

            return getMesssages;
        }

        public GetMesssage GetMessage()
        {
            MessageTable message = _dbcontext.MessageTable.Where(x => x.UseName == "User2" || x.UseName == "User1").OrderByDescending(x => x.UseId).FirstOrDefault();
            //_dbcontext.Entry(message).Reload();
            GetMesssage getMesssages = _mapper.Map<GetMesssage>(message);

            return getMesssages;
        }
    }
}
