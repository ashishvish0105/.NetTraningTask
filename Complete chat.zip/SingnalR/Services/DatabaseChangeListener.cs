﻿using Microsoft.AspNetCore.SignalR;
using SingnalR.AppData;
using SingnalR.Hubs;

namespace SingnalR.Services
{
    //public class DatabaseChangeListener
    //{
    //    private readonly IHubContext<ChatHub> _hubContext;

    //    public DatabaseChangeListener(IHubContext<ChatHub> hubContext)
    //    {
    //        _hubContext = hubContext;
    //    }

    //    public void ListenForChanges()
    //    {
    //        // Set up a SQL Server Change Tracking listener or a database trigger
    //        // to detect changes in the database table

    //        // When a change is detected, send a message to the SignalR hub
    //        _hubContext.Clients.All.SendAsync("receiveMessage", "Database change detected!");
    //    }
    //}

    public class DatabaseMonitorService : IHostedService
    {
        private readonly IServiceScopeFactory _scopeFactory;
        private readonly IHubContext<ChatHub> _hubContext;
        private Timer _timer;
        private DateTime _lastCheckTime;

        public DatabaseMonitorService(IServiceScopeFactory scopeFactory, IHubContext<ChatHub> hubContext)
        {
            _scopeFactory = scopeFactory;
            _hubContext = hubContext;
            _lastCheckTime = DateTime.Now;
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            CheckForChanges();
            return Task.CompletedTask;
            //_timer = new Timer(CheckForChanges, null, TimeSpan.Zero, TimeSpan.FromSeconds(10));
            //return Task.CompletedTask;
        }

        private void CheckForChanges()
        {
            using (var scope = _scopeFactory.CreateScope())
            {
                var dbContext = scope.ServiceProvider.GetRequiredService<AppDatabase>();
                // Logic to check for changes in the database
                //var hasChanges = true; /* your logic here */

                //if (hasChanges)
                //{
                //    _hubContext.Clients.All.SendAsync("ReceiveMessage", "Database has changed");
                //}


                var newMessages = dbContext.MessageTable
                .Where(m => m.Timestamp > _lastCheckTime)
                .ToList();

                if (newMessages.Any())
                {
                    foreach (var message in newMessages)
                    {
                        _hubContext.Clients.All.SendAsync("GetListMessage");
                    }

                    _lastCheckTime = DateTime.Now;
                }
                else { }
            }
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _timer?.Change(Timeout.Infinite, 0);
            return Task.CompletedTask;
        }
    }

}
