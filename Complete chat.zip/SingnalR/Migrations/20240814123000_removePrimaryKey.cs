﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SingnalR.Migrations
{
    /// <inheritdoc />
    public partial class removePrimaryKey : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "MessageTable",
                columns: table => new
                {
                    UseId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UseName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Messgae = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MessageCoute = table.Column<int>(type: "int", nullable: false, defaultValue: 0),
                    MessageSeen = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    Timestamp = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MessageTable", x => x.UseId);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MessageTable");
        }
    }
}
