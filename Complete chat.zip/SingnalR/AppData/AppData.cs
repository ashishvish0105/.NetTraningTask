﻿using Microsoft.EntityFrameworkCore;
using SingnalR.AppData.TablesEntity;

namespace SingnalR.AppData
{
    public class AppDatabase:DbContext
    {
        public AppDatabase(DbContextOptions<AppDatabase> options):base(options) { }
        public DbSet<MessageTable> MessageTable { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<MessageTable>(entity =>
            {
                entity.Property(e => e.MessageCoute)
                    .HasDefaultValue(0);

                entity.Property(e => e.MessageSeen)
                    .HasDefaultValue(false);

                entity.Property(e => e.Timestamp)
                    .HasDefaultValueSql("GETDATE()");
            });
        }
    }
}
