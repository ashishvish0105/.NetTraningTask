﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SingnalR.AppData.TablesEntity
{
    public class MessageTable
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int UseId  { get; set; }
        public  string UseName { get; set; }
        public  string Messgae { get; set; }
        public  int MessageCoute { get; set; } = 0;
        public bool MessageSeen { get; set; } = false;
        public DateTime Timestamp { get; set; } = DateTime.Now;
        public MessageTable()
        {
            MessageCoute = 0;
            MessageSeen = false;
            Timestamp = DateTime.Now;
        }
    }
}
