﻿namespace SingnalR.InserFaces
{
    //public interface ISubscribeTableDependency
    //{
    //    void SubscribeTableDependency(string connectionString);
    //}

    public interface ISubscribeTableDependency
    {
        void SubscribeTableDependency(string connectionString);
        //void MessageSetup();
    }
}
