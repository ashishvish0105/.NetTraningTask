﻿using AutoMapper;
using CodeFirstApiDemo.DbContextApp;
using CodeFirstApiDemo.DbContextApp.DataBaseTables;
using CodeFirstApiDemo.InterFaces;
using CodeFirstApiDemo.Models;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.EntityFrameworkCore;
using System.Linq;


namespace CodeFirstApiDemo.Services
{
    public class UserService : IUserServices
    {
        private readonly CodeFirstApproachDbContext DatabaseContext;
        private readonly IMapper MapperService;
        const string GetUserListSuccessMessage = "User list fetched successfully";
        const string GetUserSuccessMessage = "User fetched successfully";
        const string InternalServerError = "Internal Server Error";
        const string UserAddedSuccessMessage = "User added successfully";
        const string UserAddedErrrorMessage = "User not added successfully";
        const string UserUpdateSuccessMessage = "User updated successfully";
        const string UserNotUpdateErrorMessage = "User data not updated";
        const string UserNotAvailableMessage = "User not available";
        const string UserDeleteSuccessMessage = "User Delete successfully";
        const string UserDeleteErrorMessage = "User Not Delete successfully";
 


        public UserService(CodeFirstApproachDbContext databaseContext, IMapper mapperService)
        {
            DatabaseContext = databaseContext;
            MapperService = mapperService;
        }

        public async Task<ReturnResponseModel> GetUserList()
        {
            ReturnResponseModel returnResponseModel = new ReturnResponseModel();
            List<UserTableModel> UserModel = await DatabaseContext.Users.ToListAsync();
            List<UserModel> UserList = MapperService.Map<List<UserModel>>(UserModel);

            try
            {               
                returnResponseModel.Success = true;
                returnResponseModel.StatusCode = StatusCodes.Status200OK;
                returnResponseModel.Payload = UserList;
                returnResponseModel.Message = GetUserListSuccessMessage;
            }
            catch (Exception)
            {
                returnResponseModel.StatusCode = StatusCodes.Status500InternalServerError;
                returnResponseModel.Message = InternalServerError;
            }

            return returnResponseModel;
        }

        public async Task<ReturnResponseModel> GetUser(Guid userId)
        {
            ReturnResponseModel returnResponseModel = new ReturnResponseModel();
            var UserModel = await DatabaseContext.Users.FirstOrDefaultAsync(x => x.UserId == userId);
            UserModel User = MapperService.Map<UserModel>(UserModel);

            try
            {
                returnResponseModel.Success = true;
                returnResponseModel.StatusCode = StatusCodes.Status200OK;
                returnResponseModel.Payload = User;
                returnResponseModel.Message = GetUserSuccessMessage;
            }
            catch (Exception ex)
            {
                returnResponseModel.StatusCode = StatusCodes.Status500InternalServerError;
                returnResponseModel.Message = InternalServerError;
            }

            return returnResponseModel;
        }

        public async Task<ReturnResponseModel> AddUser(AddUser user)
        {
            ReturnResponseModel returnResponseModel = new ReturnResponseModel();

            try
            {
                UserTableModel userEntity = MapperService.Map<UserTableModel>(user);
                var data = await DatabaseContext.Users.AddAsync(userEntity);
                int returnValue = await DatabaseContext.SaveChangesAsync();
                if (returnValue > 0)
                {
                    returnResponseModel.Success = true;
                    returnResponseModel.StatusCode = StatusCodes.Status200OK; ;
                    returnResponseModel.Payload = data.Entity;
                    returnResponseModel.Message = UserAddedSuccessMessage;
                }
                else
                {
                    returnResponseModel.StatusCode = StatusCodes.Status400BadRequest;
                    returnResponseModel.Payload = user;
                    returnResponseModel.Message = UserAddedErrrorMessage;
                }
            }
            catch (Exception ex)
            {
                returnResponseModel.StatusCode = StatusCodes.Status500InternalServerError;
                returnResponseModel.Message = InternalServerError;
            }
            return returnResponseModel;
        }

        public async Task<ReturnResponseModel> UpdateUser(UserModel user)
        {
            var returnResponseModel = new ReturnResponseModel();
            try
            {
                var verifyUser = await DatabaseContext.Users.FirstOrDefaultAsync(x => x.UserId == user.UserId);

                if (verifyUser != null)
                {
                    // Map the updated user data to the existing entity
                    MapperService.Map(user, verifyUser);

                    DatabaseContext.Users.Update(verifyUser);
                    int returnValue = await DatabaseContext.SaveChangesAsync();

                    if (returnValue > 0)
                    {
                        returnResponseModel.Success = true;
                        returnResponseModel.StatusCode = StatusCodes.Status200OK;
                        returnResponseModel.Payload = verifyUser;
                        returnResponseModel.Message = UserUpdateSuccessMessage;
                    }
                    else
                    {
                        returnResponseModel.Success = false;
                        returnResponseModel.StatusCode = StatusCodes.Status400BadRequest ;
                        returnResponseModel.Message = UserNotUpdateErrorMessage;
                    }
                }
                else
                {
                    returnResponseModel.Success = false;
                    returnResponseModel.StatusCode = StatusCodes.Status404NotFound;
                    returnResponseModel.Message = UserNotAvailableMessage;
                }
            }
            catch (Exception ex)
            {
                returnResponseModel.Success = false;
                returnResponseModel.StatusCode = StatusCodes.Status500InternalServerError;
                returnResponseModel.Message = InternalServerError;
            }

            return returnResponseModel;
        }

        public async Task<ReturnResponseModel> UpdateUserById(Guid userId, AddUser updateInfo)
        {
            ReturnResponseModel returnResponseModel = new ReturnResponseModel();
            try
            {
                var VerifyUser = await DatabaseContext.Users.FirstOrDefaultAsync(x => x.UserId == userId);
                //UserTableModel GetUser = MapperService.Map<UserTableModel>(VerifyUser);
                int returnValue = 0;
                if (GetUser != null)
                {
                    MapperService.Map(updateInfo, VerifyUser);
                    DatabaseContext.Users.Update(VerifyUser);
                    returnValue = await DatabaseContext.SaveChangesAsync();

                    if (returnValue > 0)
                    {
                        returnResponseModel.Success = true;
                        returnResponseModel.StatusCode = StatusCodes.Status200OK;
                        returnResponseModel.Payload = returnValue;
                        returnResponseModel.Message = UserUpdateSuccessMessage;
                    }
                    else
                    {
                        returnResponseModel.StatusCode = StatusCodes.Status400BadRequest;
                        returnResponseModel.Payload = returnValue;
                        returnResponseModel.Message = UserNotUpdateErrorMessage;
                    }
                }
                else
                {
                    returnResponseModel.StatusCode = StatusCodes.Status404NotFound;
                    returnResponseModel.Payload = returnValue;
                    returnResponseModel.Message = UserNotAvailableMessage;
                }
            }
            catch (Exception ex)
            {
                returnResponseModel.StatusCode = StatusCodes.Status500InternalServerError;
                returnResponseModel.Message = InternalServerError;
            }
            return returnResponseModel;
        }

        public async Task<ReturnResponseModel> DeleteUser(Guid userId)
        {
            ReturnResponseModel returnResponseModel = new ReturnResponseModel();
            try
            {
                var findUser = DatabaseContext.Users.FirstOrDefault(x => x.UserId == userId);
                int returnValue = 0;

                if (findUser?.UserId != null)
                {
                    DatabaseContext.Users.Remove(findUser);
                    returnValue = await DatabaseContext.SaveChangesAsync();

                    if(returnValue > 0)
                    {
                        returnResponseModel.Success = true;
                        returnResponseModel.StatusCode = StatusCodes.Status200OK;
                        returnResponseModel.Message = UserDeleteSuccessMessage;
                    }
                    else
                    {
                        returnResponseModel.StatusCode = StatusCodes.Status400BadRequest;
                        returnResponseModel.Message = UserDeleteErrorMessage;
                    }
                }
                else
                {
                    returnResponseModel.StatusCode = StatusCodes.Status404NotFound;
                    returnResponseModel.Payload = userId;
                    returnResponseModel.Message = UserNotAvailableMessage;
                }
            }
            catch (Exception ex)
            {
                returnResponseModel.StatusCode = StatusCodes.Status500InternalServerError;
                returnResponseModel.Message = InternalServerError;
            }
            return returnResponseModel;
        }

        //public async Task<ReturnResponseModel> UpdateUser(UserModel user)
        //{
        //    ReturnResponseModel returnResponseModel = new ReturnResponseModel();
        //    try
        //    {
        //        var VerifyUser = await DatabaseContext.Users.FirstOrDefaultAsync(x=>x.UserId == user.UserId);
        //        //UserTableModel GetUser = MapperService.Map<UserTableModel>(VerifyUser);

        //        if (VerifyUser != null)
        //        {
        //            int returnValue = 0;
        //            MapperService.Map<UserTableModel>(user);
        //            DatabaseContext.Users.Update(userEntity);
        //            returnValue = await DatabaseContext.SaveChangesAsync();

        //            if (returnValue > 0)
        //            {
        //                returnResponseModel.Success = true;
        //                returnResponseModel.StatusCode = 200;
        //                returnResponseModel.Payload = user;
        //                returnResponseModel.Message = "User Update successfully";
        //            }
        //            else
        //            {
        //                returnResponseModel.StatusCode = 400;
        //                returnResponseModel.Payload = user;
        //                returnResponseModel.Message = "User Date Not Update";
        //            }
        //        }
        //        else
        //        {
        //            returnResponseModel.StatusCode = 404;
        //            returnResponseModel.Payload = user;
        //            returnResponseModel.Message = "User Not availble";
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        returnResponseModel.StatusCode = 500;
        //        returnResponseModel.Message = "Server side error" + ex.Message;
        //    }

        //    return returnResponseModel;
        //}

        //public int UpdateUserById(Guid userId, AddUser UpdateInfo)
        //{
        //    int returnValue = 0;

        //    var FindUser = _dbContext.Users.FirstOrDefault(x => x.UserId == userId);


        //    if (FindUser?.UserId != null)
        //    {
        //        //var userEntity = _mapper.Map<UserTableModel>(UpdateInfo);

        //        UserTableModel userEntity = new UserTableModel()
        //        {
        //            UserId = FindUser.UserId,
        //            UserName = UpdateInfo.UserName,
        //            FirstName = UpdateInfo.FirstName,
        //            LastName = UpdateInfo.LastName,
        //            Gender = UpdateInfo.Gender,
        //            PhoneNumber = UpdateInfo.PhoneNumber,
        //        };

        //        _dbContext.Users.Update(userEntity);
        //        returnValue = _dbContext.SaveChanges();
        //    }

        //    return returnValue;
        //}

    }
}
