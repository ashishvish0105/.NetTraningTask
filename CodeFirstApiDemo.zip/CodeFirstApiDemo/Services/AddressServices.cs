﻿using AutoMapper;
using CodeFirstApiDemo.DbContextApp;
using CodeFirstApiDemo.InterFaces;
using CodeFirstApiDemo.Models;

namespace CodeFirstApiDemo.Services
{
    public class AddressServices: IAddressServices
    {
        private readonly CodeFirstApproachDbContext DatabaseContext;
        private readonly IMapper mapper;

        public AddressServices(CodeFirstApproachDbContext databaseContext, IMapper mapper) {
            DatabaseContext = databaseContext;
            this.mapper = mapper;
        }

        public List<AddressModel> GetAddressList()
        {
            var addressList = DatabaseContext.Addresses.ToList();
            List<AddressModel> GetAddreessList =  mapper.Map<List<AddressModel>>(addressList);
            return GetAddreessList;
        }

    }
}
