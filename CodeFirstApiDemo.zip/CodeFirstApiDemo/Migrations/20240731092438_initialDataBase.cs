﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace CodeFirstApiDemo.Migrations
{
    /// <inheritdoc />
    public partial class initialDataBase : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Addresses",
                columns: table => new
                {
                    AddressID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Street = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    CityId = table.Column<int>(type: "int", nullable: false),
                    StateId = table.Column<int>(type: "int", nullable: false),
                    CountryId = table.Column<int>(type: "int", nullable: false),
                    ZipcodeId = table.Column<int>(type: "int", nullable: false),
                    UserId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Addresses", x => x.AddressID);
                });

            migrationBuilder.CreateTable(
                name: "Cities",
                columns: table => new
                {
                    CityId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CityName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StateId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cities", x => x.CityId);
                });

            migrationBuilder.CreateTable(
                name: "Countries",
                columns: table => new
                {
                    CountryId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CountryName = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Countries", x => x.CountryId);
                });

            migrationBuilder.CreateTable(
                name: "States",
                columns: table => new
                {
                    StateId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StateName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CountryId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_States", x => x.StateId);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    UserId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    UserName = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Gender = table.Column<string>(type: "nvarchar(1)", maxLength: 1, nullable: false),
                    PhoneNumber = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.UserId);
                });

            migrationBuilder.CreateTable(
                name: "Zipcodes",
                columns: table => new
                {
                    ZipcodeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Zipcode = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Zipcodes", x => x.ZipcodeId);
                });

            migrationBuilder.InsertData(
                table: "Addresses",
                columns: new[] { "AddressID", "CityId", "CountryId", "StateId", "Street", "UserId", "ZipcodeId" },
                values: new object[,]
                {
                    { new Guid("16f363c6-bf29-40c7-be66-10968f6b0849"), 1, 1, 1, "Street 1", new Guid("11111111-1111-1111-1111-111111111111"), 1 },
                    { new Guid("290b5ca4-41c9-4401-9a3d-16b3eab4094d"), 3, 1, 2, "Street 3", new Guid("33333333-3333-3333-3333-333333333333"), 3 },
                    { new Guid("402f5cb6-1188-4a6c-a173-5696de8debfe"), 2, 1, 1, "Street 2", new Guid("22222222-2222-2222-2222-222222222222"), 2 },
                    { new Guid("4ce52e1e-4f08-496d-97fc-226c34de4c03"), 1, 1, 1, "Street 10", new Guid("10101010-1010-1010-1010-101010101010"), 10 },
                    { new Guid("5e74c85c-899d-4a82-b948-1bb28c3995e8"), 3, 1, 2, "Street 9", new Guid("99999999-9999-9999-9999-999999999999"), 9 },
                    { new Guid("783c99a6-728f-4c3c-a1a9-938da3d5b088"), 2, 1, 1, "Street 8", new Guid("88888888-8888-8888-8888-888888888888"), 8 },
                    { new Guid("7c7a6871-e659-4271-b316-9e3cd5b8d1e1"), 3, 1, 2, "Street 6", new Guid("66666666-6666-6666-6666-666666666666"), 6 },
                    { new Guid("c3b2ecb7-f362-4190-b543-01d72349ff6c"), 2, 1, 1, "Street 5", new Guid("55555555-5555-5555-5555-555555555555"), 5 },
                    { new Guid("e7aac7a1-c68d-4410-bda2-a8cdc70d47f5"), 1, 1, 1, "Street 4", new Guid("44444444-4444-4444-4444-444444444444"), 4 },
                    { new Guid("ecc82dda-0803-49db-b74f-abc0d3c4a2f8"), 1, 1, 1, "Street 7", new Guid("77777777-7777-7777-7777-777777777777"), 7 }
                });

            migrationBuilder.InsertData(
                table: "Cities",
                columns: new[] { "CityId", "CityName", "StateId" },
                values: new object[,]
                {
                    { 1, "Mumbai", 1 },
                    { 2, "Pune", 1 },
                    { 3, "Bangalore", 2 },
                    { 4, "Chennai", 3 },
                    { 5, "Hyderabad", 4 },
                    { 6, "Ahmedabad", 5 },
                    { 7, "Kolkata", 6 },
                    { 8, "Surat", 5 },
                    { 9, "Jaipur", 7 },
                    { 10, "Lucknow", 8 }
                });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "CountryId", "CountryName" },
                values: new object[,]
                {
                    { 1, "India" },
                    { 2, "USA" },
                    { 3, "Canada" },
                    { 4, "Australia" },
                    { 5, "Germany" },
                    { 6, "France" },
                    { 7, "Japan" },
                    { 8, "China" },
                    { 9, "Brazil" },
                    { 10, "South Africa" }
                });

            migrationBuilder.InsertData(
                table: "States",
                columns: new[] { "StateId", "CountryId", "StateName" },
                values: new object[,]
                {
                    { 1, 1, "Maharashtra" },
                    { 2, 1, "Karnataka" },
                    { 3, 1, "Tamil Nadu" },
                    { 4, 1, "Uttar Pradesh" },
                    { 5, 1, "Gujarat" },
                    { 6, 1, "Rajasthan" },
                    { 7, 1, "West Bengal" },
                    { 8, 1, "Madhya Pradesh" },
                    { 9, 1, "Odisha" },
                    { 10, 1, "Punjab" }
                });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "UserId", "FirstName", "Gender", "LastName", "PhoneNumber", "UserName" },
                values: new object[,]
                {
                    { new Guid("12d15f03-1c9e-404d-8c97-0923b734e522"), "Vivaan", "M", "Gupta", "9111111111", "User3" },
                    { new Guid("14c3c926-8acc-4676-b0c5-8e028ae5c08d"), "Krishna", "M", "Iyer", "9111111111", "User6" },
                    { new Guid("4df3d431-24cb-4d08-ae16-e28cb6c11a20"), "Aryan", "M", "Verma", "9111111111", "User7" },
                    { new Guid("63b6f61a-cb94-44ba-bf84-843c37911bf6"), "Vihaan", "M", "Kumar", "9111111111", "User2" },
                    { new Guid("7623795e-bafe-4fb6-98dc-2d9fbf7fa73a"), "Diya", "F", "Patil", "9111111111", "User8" },
                    { new Guid("8654d06a-3e86-42be-af7e-0b2de4cdd1cc"), "Aarav", "M", "Sharma", "9111111111", "User1" },
                    { new Guid("90483587-4641-475b-9abf-70e00a528d8b"), "Ishaan", "M", "Reddy", "9111111111", "User9" },
                    { new Guid("bc309d1c-295d-4ca4-bd45-d133ee1e4e3f"), "Riya", "F", "Das", "9111111111", "User10" },
                    { new Guid("d42b7ae2-ac65-464c-bcdd-8ae5e66c09aa"), "Aadhya", "F", "Raj", "9111111111", "User5" },
                    { new Guid("edc68e0f-c790-4388-b641-744b7ff7bb43"), "Anaya", "F", "Singh", "9111111111", "User4" }
                });

            migrationBuilder.InsertData(
                table: "Zipcodes",
                columns: new[] { "ZipcodeId", "Zipcode" },
                values: new object[,]
                {
                    { 1, 400001 },
                    { 2, 411001 },
                    { 3, 560001 },
                    { 4, 110001 },
                    { 5, 700001 },
                    { 6, 600001 },
                    { 7, 380001 },
                    { 8, 500001 },
                    { 9, 682001 },
                    { 10, 751001 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Addresses");

            migrationBuilder.DropTable(
                name: "Cities");

            migrationBuilder.DropTable(
                name: "Countries");

            migrationBuilder.DropTable(
                name: "States");

            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.DropTable(
                name: "Zipcodes");
        }
    }
}
