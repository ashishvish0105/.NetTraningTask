﻿using AutoMapper;
using CodeFirstApiDemo.DbContextApp.DataBaseTables;
using CodeFirstApiDemo.Models;

namespace CodeFirstApiDemo.Helpers.AutoMapperHelpers
{
    public class ApplicationAutoMapper : Profile
    {
        public ApplicationAutoMapper()
        {
            CreateMap<UserTableModel, UserModel>();
            CreateMap<UserModel, UserTableModel>();

            CreateMap<AddUser, UserTableModel>()
             .BeforeMap((src, dest) => { if (dest.UserId == Guid.Empty) dest.UserId = Guid.NewGuid(); });



            CreateMap<UserModel, UserTableModel>()
            .ForMember(dest => dest.UserId, opt => opt.Ignore());

            CreateMap<AddressTableModel, AddressModel>();
        }
    }
}
