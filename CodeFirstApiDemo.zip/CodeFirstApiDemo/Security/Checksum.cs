﻿using System.Security.Cryptography;
using System.Text;

namespace CodeFirstApiDemo.Security
{
    public static class Checksum
    {
        public static string generateSignature(string data, string key)
        {
            // Convert the key to bytes
            byte[] keyBytes = Encoding.UTF8.GetBytes(key);

            // Convert the data to bytes
            byte[] dataBytes = Encoding.UTF8.GetBytes(data);

            // Compute the HMACSHA256 hash
            using (HMACSHA256 hmac = new HMACSHA256(keyBytes))
            {
                byte[] hashBytes = hmac.ComputeHash(dataBytes);

                // Convert the hash bytes to a hexadecimal string
                StringBuilder hash = new StringBuilder();
                foreach (byte b in hashBytes)
                {
                    hash.Append(b.ToString("x2"));
                }

                return hash.ToString();
            }
        }
    }

}
