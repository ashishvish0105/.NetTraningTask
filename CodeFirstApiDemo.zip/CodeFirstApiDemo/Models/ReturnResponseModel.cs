﻿using Microsoft.OpenApi.Any;

namespace CodeFirstApiDemo.Models
{
    public class ReturnResponseModel
    {
        public bool Success { get; set; }
        public int StatusCode { get; set; }
        public string? Message { get; set; }
        public object? Payload { get; set; }
    
        public ReturnResponseModel()
        {
            this.Payload = null;
            this.Success = false;
            this.StatusCode = 404;
            this.Message = "Default Message";
        }
    }

}
