﻿using CodeFirstApiDemo.DbContextApp.DataBaseTables;
using Microsoft.EntityFrameworkCore;

namespace CodeFirstApiDemo.DbContextApp
{
    public class CodeFirstApproachDbContext : DbContext
    {
        public CodeFirstApproachDbContext(DbContextOptions<CodeFirstApproachDbContext> options) : base(options)
        {
        }

        public DbSet<AddressTableModel> Addresses { get; set; }
        public DbSet<CityTableModel> Cities { get; set; }
        public DbSet<StateTableModel> States { get; set; }
        public DbSet<CountryTableModel> Countries { get; set; }
        public DbSet<UserTableModel> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

 //           // Seeding UserModel data
 //           modelBuilder.Entity<UserModel>().HasData(
 //                 new UserModel { UserId = Guid.NewGuid(), UserName = "User1", FirstName = "Aarav", LastName = "Sharma", Gender = "M", PhoneNumber = "9111111111" },
 //                 new UserModel { UserId = Guid.NewGuid(), UserName = "User2", FirstName = "Vihaan", LastName = "Kumar", Gender = "M", PhoneNumber = "9111111111" },
 //                 new UserModel { UserId = Guid.NewGuid(), UserName = "User3", FirstName = "Vivaan", LastName = "Gupta", Gender = "M", PhoneNumber = "9111111111" },
 //                 new UserModel { UserId = Guid.NewGuid(), UserName = "User4", FirstName = "Anaya", LastName = "Singh", Gender = "F", PhoneNumber = "9111111111" },
 //                 new UserModel { UserId = Guid.NewGuid(), UserName = "User5", FirstName = "Aadhya", LastName = "Raj", Gender = "F", PhoneNumber = "9111111111" },
 //                 new UserModel { UserId = Guid.NewGuid(), UserName = "User6", FirstName = "Krishna", LastName = "Iyer", Gender = "M", PhoneNumber = "9111111111" },
 //                 new UserModel { UserId = Guid.NewGuid(), UserName = "User7", FirstName = "Aryan", LastName = "Verma", Gender = "M", PhoneNumber = "9111111111" },
 //                 new UserModel { UserId = Guid.NewGuid(), UserName = "User8", FirstName = "Diya", LastName = "Patil", Gender = "F", PhoneNumber = "9111111111" },
 //                 new UserModel { UserId = Guid.NewGuid(), UserName = "User9", FirstName = "Ishaan", LastName = "Reddy", Gender = "M", PhoneNumber = "9111111111" },
 //                 new UserModel { UserId = Guid.NewGuid(), UserName = "User10", FirstName = "Riya", LastName = "Das", Gender = "F", PhoneNumber = "9111111111" }
 //             );

 //           modelBuilder.Entity<CountryModel>().HasData(
 //                new CountryModel { CountryId = 1, CountryName = "India" },
 //                new CountryModel { CountryId = 2, CountryName = "USA" },
 //                new CountryModel { CountryId = 3, CountryName = "Canada" },
 //                new CountryModel { CountryId = 4, CountryName = "Australia" },
 //                new CountryModel { CountryId = 5, CountryName = "Germany" },
 //                new CountryModel { CountryId = 6, CountryName = "France" },
 //                new CountryModel { CountryId = 7, CountryName = "Japan" },
 //                new CountryModel { CountryId = 8, CountryName = "China" },
 //                new CountryModel { CountryId = 9, CountryName = "Brazil" },
 //                new CountryModel { CountryId = 10, CountryName = "South Africa" }
 //            );

 //           modelBuilder.Entity<StateModel>().HasData(
 //              new StateModel { StateId = 1, StateName = "Maharashtra", CountryId = 1 },
 //              new StateModel { StateId = 2, StateName = "Karnataka", CountryId = 1 },
 //              new StateModel { StateId = 3, StateName = "Tamil Nadu", CountryId = 1 },
 //              new StateModel { StateId = 4, StateName = "Uttar Pradesh", CountryId = 1 },
 //              new StateModel { StateId = 5, StateName = "Gujarat", CountryId = 1 },
 //              new StateModel { StateId = 6, StateName = "Rajasthan", CountryId = 1 },
 //              new StateModel { StateId = 7, StateName = "West Bengal", CountryId = 1 },
 //              new StateModel { StateId = 8, StateName = "Madhya Pradesh", CountryId = 1 },
 //              new StateModel { StateId = 9, StateName = "Odisha", CountryId = 1 },
 //              new StateModel { StateId = 10, StateName = "Punjab", CountryId = 1 }
 //          );

 //           modelBuilder.Entity<CityModel>().HasData(
 //    new CityModel { CityId = 1, CityName = "Mumbai", StateId = 1 },
 //    new CityModel { CityId = 2, CityName = "Pune", StateId = 1 },
 //    new CityModel { CityId = 3, CityName = "Bangalore", StateId = 2 },
 //    new CityModel { CityId = 4, CityName = "Chennai", StateId = 3 },
 //    new CityModel { CityId = 5, CityName = "Hyderabad", StateId = 4 },
 //    new CityModel { CityId = 6, CityName = "Ahmedabad", StateId = 5 },
 //    new CityModel { CityId = 7, CityName = "Kolkata", StateId = 6 },
 //    new CityModel { CityId = 8, CityName = "Surat", StateId = 5 },
 //    new CityModel { CityId = 9, CityName = "Jaipur", StateId = 7 },
 //    new CityModel { CityId = 10, CityName = "Lucknow", StateId = 8 }
 //);

 //           modelBuilder.Entity<ZipcodeModel>().HasData(
 //          new ZipcodeModel { ZipcodeId = 1, Zipcode = 400001 },
 //          new ZipcodeModel { ZipcodeId = 2, Zipcode = 411001 },
 //          new ZipcodeModel { ZipcodeId = 3, Zipcode = 560001 },
 //          new ZipcodeModel { ZipcodeId = 4, Zipcode = 110001 },
 //          new ZipcodeModel { ZipcodeId = 5, Zipcode = 700001 },
 //          new ZipcodeModel { ZipcodeId = 6, Zipcode = 600001 },
 //          new ZipcodeModel { ZipcodeId = 7, Zipcode = 380001 },
 //          new ZipcodeModel { ZipcodeId = 8, Zipcode = 500001 },
 //          new ZipcodeModel { ZipcodeId = 9, Zipcode = 682001 },
 //          new ZipcodeModel { ZipcodeId = 10, Zipcode = 751001 }
 //      );

 //           // Seeding AddressModel data
 //           modelBuilder.Entity<AddressModel>().HasData(
 //               new AddressModel { AddressID = Guid.NewGuid(), Street = "Street 1", CityId = 1, StateId = 1, CountryId = 1, ZipcodeId = 1, UserId = new Guid("11111111-1111-1111-1111-111111111111") },
 //               new AddressModel { AddressID = Guid.NewGuid(), Street = "Street 2", CityId = 2, StateId = 1, CountryId = 1, ZipcodeId = 2, UserId = new Guid("22222222-2222-2222-2222-222222222222") },
 //               new AddressModel { AddressID = Guid.NewGuid(), Street = "Street 3", CityId = 3, StateId = 2, CountryId = 1, ZipcodeId = 3, UserId = new Guid("33333333-3333-3333-3333-333333333333") },
 //               new AddressModel { AddressID = Guid.NewGuid(), Street = "Street 4", CityId = 1, StateId = 1, CountryId = 1, ZipcodeId = 4, UserId = new Guid("44444444-4444-4444-4444-444444444444") },
 //               new AddressModel { AddressID = Guid.NewGuid(), Street = "Street 5", CityId = 2, StateId = 1, CountryId = 1, ZipcodeId = 5, UserId = new Guid("55555555-5555-5555-5555-555555555555") },
 //               new AddressModel { AddressID = Guid.NewGuid(), Street = "Street 6", CityId = 3, StateId = 2, CountryId = 1, ZipcodeId = 6, UserId = new Guid("66666666-6666-6666-6666-666666666666") },
 //               new AddressModel { AddressID = Guid.NewGuid(), Street = "Street 7", CityId = 1, StateId = 1, CountryId = 1, ZipcodeId = 7, UserId = new Guid("77777777-7777-7777-7777-777777777777") },
 //               new AddressModel { AddressID = Guid.NewGuid(), Street = "Street 8", CityId = 2, StateId = 1, CountryId = 1, ZipcodeId = 8, UserId = new Guid("88888888-8888-8888-8888-888888888888") },
 //               new AddressModel { AddressID = Guid.NewGuid(), Street = "Street 9", CityId = 3, StateId = 2, CountryId = 1, ZipcodeId = 9, UserId = new Guid("99999999-9999-9999-9999-999999999999") },
 //               new AddressModel { AddressID = Guid.NewGuid(), Street = "Street 10", CityId = 1, StateId = 1, CountryId = 1, ZipcodeId = 10, UserId = new Guid("10101010-1010-1010-1010-101010101010") }
 //           );
        }
    }
}
