﻿using System.ComponentModel.DataAnnotations;

namespace CodeFirstApiDemo.DbContextApp.DataBaseTables
{
    public class UserTableModel
    {
        [Key]
        public Guid UserId { get; set; }
        [MaxLength(20)]
        public string? UserName { get; set; }
        [Required,MaxLength(20)]
        public string? FirstName { get; set; }
        [Required,MaxLength(20)]
        public string? LastName { get; set; }
        [MaxLength(1)]
        public string? Gender { get; set; }
        [MaxLength(10)]
        public string? PhoneNumber { get; set; }
    }
}
