﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CodeFirstApiDemo.DbContextApp.DataBaseTables
{
    public class AddressTableModel
    {
        [Key]
        public Guid AddressID { get; set; }
        
        [MaxLength(50)]
        public string? Street { get; set; }
        public int CityId { get; set; }
        public int StateId { get; set; }
        public int CountryId { get; set; }
        public int ZipcodeId { get; set; }
        public Guid UserId { get; set; }


        [ForeignKey(nameof(CityId))]
        public CityTableModel? CityTableModel { get; set; }

        [ForeignKey(nameof(StateId))]
        public StateTableModel? StateTableModel { get; set; }

        [ForeignKey(nameof(CountryId))]
        public CountryTableModel? Country { get; set; }


        [ForeignKey(nameof(UserId))]
        public UserTableModel? UserTable { get; set; }
    }

    public class CityTableModel
    {
        [Key]
        public int CityId { get; set; }
        public string? CityName { get; set; }
        public int Zipcode { get; set; }
        public int StateId { get; set; }

        [ForeignKey(nameof(StateId))]
        public StateTableModel? StateTableModel { get; set; }   
    }

    public class StateTableModel
    {
        [Key]
        public int StateId { get; set; }
        public string? StateName { get; set; }
        public int CountryId { get; set;}

        [ForeignKey(nameof(CountryId))]
        public CountryTableModel? CountryTableModel { get; set; }
    }
    public class CountryTableModel
    {
        [Key]
        public int CountryId { get; set; }
        public string? CountryName { get; set; }
    }

}
