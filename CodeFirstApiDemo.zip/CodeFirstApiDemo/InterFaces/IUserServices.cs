﻿using CodeFirstApiDemo.Models;

namespace CodeFirstApiDemo.InterFaces
{
    public interface IUserServices
    {
        public Task<ReturnResponseModel> GetUserList();
        public Task<ReturnResponseModel> GetUser(Guid userId);
        public Task<ReturnResponseModel> AddUser(AddUser user);
        public Task<ReturnResponseModel> UpdateUser(UserModel user);
        public Task<ReturnResponseModel> UpdateUserById(Guid userId, AddUser updateInfo);
        public Task<ReturnResponseModel> DeleteUser(Guid userId);
    }
}
