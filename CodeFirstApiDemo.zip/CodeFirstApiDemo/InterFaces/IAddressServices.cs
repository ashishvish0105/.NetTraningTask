﻿using CodeFirstApiDemo.Models;

namespace CodeFirstApiDemo.InterFaces
{
    public interface IAddressServices
    {
        public List<AddressModel> GetAddressList();
    }
}
