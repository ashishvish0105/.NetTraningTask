﻿using CodeFirstApiDemo.InterFaces;
using CodeFirstApiDemo.Models;
using Microsoft.AspNetCore.Mvc;

namespace CodeFirstApiDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AddressController : ControllerBase
    {
        private readonly IAddressServices _addressServices;

        public AddressController(IAddressServices addressServices)
        {
            _addressServices = addressServices;
        }

        [HttpGet("GetAddressList")]
        public ReturnResponseModel GetAddressList()
        {
            ReturnResponseModel returnResponseModel = new ReturnResponseModel();
            returnResponseModel.Payload = _addressServices.GetAddressList();
            return returnResponseModel;
        }
    }
}
