﻿using CodeFirstApiDemo.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.JSInterop;

namespace CodeFirstApiDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaytmController : ControllerBase
    {
        [HttpGet]
        public ActionResult PayAmount()
        {
            PaytmService PaytmService= new PaytmService();
            return Ok(PaytmService.PaymentMethod());
        }
    }
}
