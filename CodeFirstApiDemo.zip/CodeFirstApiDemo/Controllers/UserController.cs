﻿using CodeFirstApiDemo.InterFaces;
using CodeFirstApiDemo.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Xml.Linq;

namespace CodeFirstApiDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserServices Userservice;
        public UserController(IUserServices userService)
        {
            Userservice = userService;
        }

        [HttpGet("GetUserList")]
        public async Task<ReturnResponseModel> GetUserList()
        {
            ReturnResponseModel returnResponseModel = await Userservice.GetUserList();
            return returnResponseModel;
        }

        [HttpGet("GetUser/userId")]
        public async Task<ReturnResponseModel> GetUser(Guid userId)
        {
            ReturnResponseModel returnResponseModel = await Userservice.GetUser(userId);
            return returnResponseModel;
        }

        [HttpPost("AddUser")]
        public async Task<ReturnResponseModel> AddUser(AddUser UserModel)
        {
            ReturnResponseModel returnResponseModel = await Userservice.AddUser(UserModel);
            return returnResponseModel;
        }

        [HttpPost("UpdateUserInfo")]
        public async Task<ReturnResponseModel> UpdateUserInfo(UserModel UserModel)
        {
            ReturnResponseModel returnResponseModel = await Userservice.UpdateUser(UserModel);
            return returnResponseModel;
        }

        [HttpPut("UpdateUserById{userId:guid}")]
        public async Task<ReturnResponseModel> UpdateUserById(Guid userId, AddUser userModel)
        {
            ReturnResponseModel returnResponseModel = await Userservice.UpdateUserById(userId, userModel);
            return returnResponseModel;
        }

        [HttpDelete("DeleteUser{userId:guid}")]
        public async Task<ReturnResponseModel> DeleteUserById(Guid userId)
        {
            ReturnResponseModel returnResponseModel = await Userservice.DeleteUser(userId);
            return returnResponseModel;
        }
    }
}
