using CodeFirstApiDemo.DbContextApp;
using CodeFirstApiDemo.Helpers.AutoMapperHelpers;
using CodeFirstApiDemo.InterFaces;
using CodeFirstApiDemo.Services;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle

builder.Services.AddDbContext<CodeFirstApproachDbContext>(option => option.UseSqlServer(builder.Configuration.GetConnectionString("defaultConnectionString")));

builder.Services.AddScoped<IUserServices, UserService>();
builder.Services.AddScoped<IAddressServices, AddressServices>();

builder.Services.AddAutoMapper(typeof(ApplicationAutoMapper));

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
