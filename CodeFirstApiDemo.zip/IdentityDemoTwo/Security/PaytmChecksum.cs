﻿//using System.Security.Cryptography;
//using System.Text;

//namespace IdentityDemoTwo.Security
//{
//    public class PaytmChecksum
//    {
//        public static string GenerateSignature(string data, string key)
//        {
//            byte[] keyBytes = Encoding.UTF8.GetBytes(key);
//            byte[] dataBytes = Encoding.UTF8.GetBytes(data);
//            using (HMACSHA256 hmac = new HMACSHA256(keyBytes))
//            {
//                byte[] hashBytes = hmac.ComputeHash(dataBytes);
//                return Convert.ToBase64String(hashBytes);
//            }
//        }

//        public static bool VerifySignature(string data, string key, string checksum)
//        {
//            string generatedChecksum = GenerateSignature(data, key);
//            return generatedChecksum == checksum;
//        }
//    }
//}
