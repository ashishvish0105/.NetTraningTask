﻿//using System.Security.Cryptography;
//using System.Text;

//namespace IdentityDemoTwo.Security
//{
//    public static class Checksum
//    {
//        public static string generateSignature(string data, string key)
//        {
//            // This is a simplified example, you need to implement the actual logic to create the checksum
//            using (var hmac = new System.Security.Cryptography.HMACSHA256(Encoding.UTF8.GetBytes(key)))
//            {
//                var hashBytes = hmac.ComputeHash(Encoding.UTF8.GetBytes(data));
//                return Convert.ToBase64String(hashBytes);
//            }
//        }

//    }

//    public static class PaytmChecksum
//    {
//        public static string GenerateSignature(string data, string key)
//        {
//            using (var hmac = new System.Security.Cryptography.HMACSHA256(Encoding.UTF8.GetBytes(key)))
//            {
//                var hashBytes = hmac.ComputeHash(Encoding.UTF8.GetBytes(data));
//                return Convert.ToBase64String(hashBytes);
//            }
//        }

//        public static bool VerifySignature(string data, string key, string checksum)
//        {
//            var generatedChecksum = GenerateSignature(data, key);
//            return generatedChecksum.Equals(checksum, StringComparison.OrdinalIgnoreCase);
//        }
//    }

//}
