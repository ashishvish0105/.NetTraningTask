﻿using IdentityDemoTwo.Models;
using IdentityDemoTwo.Services;

namespace IdentityDemoTwo.InterFace
{
    public interface IUserTableInterface
    {
        public int InsertUserTable(UserModel user);
        UserModel GetActiveUserInfoByUserId(string userId);
        public List<UserFullInfoModel> GetUserFullInfoList();
        public PaginatedViewModel<UserFullInfoModel> TableRecordListAndFunction(UserTableFunctionalityParmetere UsertableFP);
    }
}
