﻿namespace IdentityDemoTwo.InterFace
{
    public interface IEmailSender
    {
        //void SendEmailAsync(string email, string subject, string htmlMessage);

        Task SendEmailWithConfigAsync(string email, string subject, string htmlMessage);
    }
}
