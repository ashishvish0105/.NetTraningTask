﻿namespace IdentityDemoTwo.Models
{
    public class UserModel
    {
        public string? AspNetUserID { get; set; }
        public string? UserName { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? PhoneName { get; set; }

    }

    public class UserFullInfoModel
    {
        public string? Id { get; set; }
        public string? UserName { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? PhoneName { get; set; }
        public string? Email { get; set; }
        public int RoleId { get; set; }
        public string? Name { get; set; }
    }


    public class PaginatedViewModel<T>
    {
        public List<T>? Items { get; set; }
        public int TotalPages { get; set; }
        public int PageSize { get; set; }
        public int PageIndex { get; set; }
        public int TotalItems { get; set; }
        public string? EmailSorting { get; set; }
        public string? UserNameSorting { get; set; }
        public string? currentSorting { get; set; }
        public string? CurrentSerching { get; set; }
        public string? sortOrder { get; set; }
        public bool HasPreviousPage => PageIndex > 1;
        public bool HasNextPage => PageIndex < TotalPages;
        public PaginatedViewModel()
        {
            UserNameSorting = "userNameDesc";
            EmailSorting = "emaildesc";
        }

        //public string ToggleEmailSorting()
        //{

        //    EmailSorting = (EmailSorting == "emaildesc" ? "emailAsc" : "emaildesc");
        //    currentSorting = EmailSorting;

        //    return EmailSorting;
        //}

        //public string ToggleUserNameSorting()
        //{
        //    UserNameSorting = (EmailSorting == "userNameDesc" ? "userNameAsc" : "userNameDesc");
        //    currentSorting = UserNameSorting;
        //    return UserNameSorting;
        //}
    }

    public class UserTableFunctionalityParmetere
    {
        public string? searchString {get;set;}
        public string? sortOrder {get;set;}
        public int pageIndex { get; set; }
    }

    public class FrontendModel
    {
        public UserTableFunctionalityParmetere? UIUserTableFunctionalityParmetere { get; set; }
        public PaginatedViewModel<UserFullInfoModel>? UIPaginatedViewModel { get; set; }
    }

}
