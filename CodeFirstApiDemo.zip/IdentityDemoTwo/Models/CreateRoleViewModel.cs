﻿namespace IdentityDemoTwo.Models
{
    public class CreateRoleViewModel
    {
        public string? RoleName { get; set; }
    }
}
