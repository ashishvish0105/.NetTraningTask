﻿using System.ComponentModel.DataAnnotations;


namespace IdentityDemoTwo.Models.Paytm
{
    public class PaytmPaymentModel
    {
        public string OrderId { get; set; }
        public string CustomerId { get; set; }
        public decimal Amount { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
    }
    public class PaytmSettings
    {
        [Required]
        public string MerchantId { get; set; }

        [Required]
        public string MerchantKey { get; set; }

        [Required]
        public string PaymentUrl { get; set; }

        [Required]
        public string CallbackUrl { get; set; }
    }
}
