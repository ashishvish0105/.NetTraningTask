﻿namespace IdentityDemoTwo.Models.Paytm
{
    public class PaytmModel
    {
        public string? MD_Id { get; set; }
        public string? MD_Key { get; set; }
        public string? Website { get; set; }
        public string? Ind_Type { get; set; }
        public string? Channel_Web { get; set; }
        public string? Channel_Mobile { get; set; }

        public PaytmModel()
        {
            this.MD_Id = "cXzCrh60287769032052";
            this.MD_Key = "TujanvnglKF%e7Jp";
            this.Website = "WEBSTAGING";
            this.Ind_Type = "Retail";
            this.Channel_Web = "WEB";
            this.Channel_Mobile = "WAP";
        }
    }

    public class PaytmCreaticialModel
    {
        public string? Mid { get; set; }
        public string? Key { get; set; }
        public string? Website { get; set; }
        public string? OrderId { get; set; }
        public string? CallbackUrl { get; set; }
        public string? CustomerId { get; set; }
        public decimal Amount { get; set; }
        public string? IndustryTypeId { get; set; }
        public string? ChannelId { get; set; }

        public PaytmCreaticialModel()
        {
            this.Mid = "cXzCrh60287769032052";
            this.Key = "TujanvnglKF%e7Jp";
            this.Website= "WEBSTAGING";
            this.IndustryTypeId = "Retail";
            this.ChannelId = "WEB";
        }
    }
  
}
