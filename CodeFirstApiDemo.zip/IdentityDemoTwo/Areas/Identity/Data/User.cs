﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Build.Framework;

namespace IdentityDemoTwo.Areas.Identity.Data
{
    public class User: IdentityUser
    {
        [Required]
        public string  UserName { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        [Required]
        public string PhoneNumber { get; set; }

    }
}
