﻿using IdentityDemoTwo.Models.Paytm;
using Newtonsoft.Json;
using System.Net;

namespace IdentityDemoTwo.Services
{
    public class PaytmServices
    {
    //    public string PaytmPaymentInitiateTransactionMethod(PaytmModel? paytm)
    //    {
    //        string ReturnUrl="";

    //        Dictionary<string, object> body = new Dictionary<string, object>();
    //        Dictionary<string, string> head = new Dictionary<string, string>();
    //        Dictionary<string, object> requestBody = new Dictionary<string, object>();

    //        Dictionary<string, string> txnAmount = new Dictionary<string, string>
    //{
    //    { "value", "1.00" },
    //    { "currency", "INR" }
    //};

    //        Dictionary<string, string> userInfo = new Dictionary<string, string>
    //{
    //    { "custId", "cust_001" }
    //};

    //        body.Add("requestType", "Payment");
    //        body.Add("mid", paytm.MD_Id);
    //        body.Add("websiteName", paytm.Website);
    //        body.Add("orderId", "ORDERID_98765");  // This should ideally be a dynamic value
    //        body.Add("txnAmount", txnAmount);
    //        body.Add("userInfo", userInfo);
    //        body.Add("callbackUrl", "https://<callback URL to be used by merchant>");  // This should also be dynamic if needed

    //        // Generate checksum by parameters we have in body
    //        string paytmChecksum = Checksum.generateSignature(JsonConvert.SerializeObject(body), paytm.MD_Key);

    //        head.Add("signature", paytmChecksum);

    //        requestBody.Add("body", body);
    //        requestBody.Add("head", head);

    //        string post_data = JsonConvert.SerializeObject(requestBody);

    //        // For Staging
    //        string url = "https://securegw-stage.paytm.in/theia/api/v1/initiateTransaction?mid=" + paytm.MD_Id + "&orderId=ORDERID_98765";

    //        // For Production
    //        // string url = "https://securegw.paytm.in/theia/api/v1/initiateTransaction?mid=" + paytm.MD_Id + "&orderId=ORDERID_98765";

    //        try
    //        {
    //            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
    //            webRequest.Method = "POST";
    //            webRequest.ContentType = "application/json";
    //            webRequest.ContentLength = post_data.Length;

    //            using (StreamWriter requestWriter = new StreamWriter(webRequest.GetRequestStream()))
    //            {
    //                requestWriter.Write(post_data);
    //            }

    //            string responseData = string.Empty;

    //            using (StreamReader responseReader = new StreamReader(webRequest.GetResponse().GetResponseStream()))
    //            {
    //                responseData = responseReader.ReadToEnd();
    //            }
    //            ReturnUrl = responseData;
    //            // Process the response data as needed
    //            Console.WriteLine(responseData);
    //        }
    //        catch (WebException ex)
    //        {
    //            using (StreamReader responseReader = new StreamReader(ex.Response.GetResponseStream()))
    //            {
    //                string errorResponse = responseReader.ReadToEnd();
    //                Console.WriteLine("Error Response: " + errorResponse);
    //                // Handle error response as needed
    //            }
    //        }

    //        return ReturnUrl;
    //    }


    //    public string PaytmPaymentProcessTransactionMethod(PaytmCreaticialModel? model)
    //    {
    //        string returnValue = "";
    //        Dictionary<string, string> body = new Dictionary<string, string>();
    //        Dictionary<string, string> head = new Dictionary<string, string>();
    //        Dictionary<string, Dictionary<string, string>> requestBody = new Dictionary<string, Dictionary<string, string>>();

    //        model.Mid =model.Mid;
    //        model.Key = model.Key;
    //        model.CallbackUrl = "https://localhost:44323/Paytm/Callback";
    //        model.OrderId = "ORDERID_" + new Random().Next(10000, 99999);
    //        model.Amount = 1.00M; // Example amount
    //        model.CustomerId = "CUST_001";
    //        model.IndustryTypeId = "Retail";
    //        model.ChannelId = "WEB";

    //        var paytmParams = new Dictionary<string, object>
    //    {
    //        { "MID", model.Mid },
    //        { "WEBSITE", model.Website },
    //        { "ORDER_ID", model.OrderId },
    //        { "CUST_ID", model.CustomerId },
    //        { "INDUSTRY_TYPE_ID", model.IndustryTypeId },
    //        { "CHANNEL_ID", model.ChannelId },
    //        { "TXN_AMOUNT", model.Amount.ToString() },
    //        { "CALLBACK_URL", model.CallbackUrl }
    //    };


    //        requestBody.Add("body", body);
    //        requestBody.Add("head", head);

    //        string post_data = JsonConvert.SerializeObject(requestBody);

    //        //For  Staging
    //        string url = "https://securegw-stage.paytm.in/theia/api/v1/processTransaction?orderId="+model.OrderId+"";


    //        HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);

    //        webRequest.Method = "POST";
    //        webRequest.ContentType = "application/json";
    //        webRequest.ContentLength = post_data.Length;

    //        using (StreamWriter requestWriter = new StreamWriter(webRequest.GetRequestStream()))
    //        {
    //            requestWriter.Write(post_data);
    //        }

    //        string responseData = string.Empty;

    //        using (StreamReader responseReader = new StreamReader(webRequest.GetResponse().GetResponseStream()))
    //        {
    //            responseData = responseReader.ReadToEnd();
    //            returnValue = responseData;
    //            Console.WriteLine(responseData);
    //        }

    //        return returnValue;
    //    }
    }
}
