﻿namespace IdentityDemoTwo.Services.Paytm
{
    public class PaytmPaymentGateway
    {
        private readonly string _merchantId;
        private readonly string _merchantKey;
        private readonly string _paymentUrl;
        private readonly string _callbackUrl;

        public PaytmPaymentGateway(string merchantId, string merchantKey, string paymentUrl, string callbackUrl)
        {
            _merchantId = merchantId;
            _merchantKey = merchantKey;
            _paymentUrl = paymentUrl;
            _callbackUrl = callbackUrl;
        }

        public void MakePayment()
        {

        }
    }
}
