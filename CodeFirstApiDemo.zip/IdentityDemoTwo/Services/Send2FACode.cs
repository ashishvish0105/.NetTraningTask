﻿namespace IdentityDemoTwo.Services
{
    public class Send2FACode
    {
    }
}
