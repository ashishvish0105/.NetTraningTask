﻿using IdentityDemoTwo.InterFace;
using IdentityDemoTwo.Models;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Diagnostics;

namespace IdentityDemoTwo.Services
{
    public class UserTable: IUserTableInterface
    {
        IConfiguration _config;
        private readonly string ConnectionString;
        public UserTable(IConfiguration config)
        {
            _config = config;
            ConnectionString = _config.GetConnectionString("IdentityDemoTwoContextConnection")?? "ConnectionString not avaible";
        }

        public int InsertUserTable(UserModel user)
        {
            string ConnectionString = _config.GetConnectionString("IdentityDemoTwoContextConnection");
            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();
            string InsertCommand = "insert into UserTable(AspNetUserID,UserName,FirstName,LastName,PhoneName)values(@AspNetUserID,@UserName,@FirstName,@LastName,@PhoneName)";
  
            try
            {
                SqlCommand insertCommand = new SqlCommand(InsertCommand, con);
                insertCommand.Parameters.AddWithValue("@AspNetUserID", user.AspNetUserID);
                insertCommand.Parameters.AddWithValue("@UserName", user.UserName);
                insertCommand.Parameters.AddWithValue("@FirstName", user.FirstName);
                insertCommand.Parameters.AddWithValue("@LastName", user.LastName);
                insertCommand.Parameters.AddWithValue("@PhoneName", user.PhoneName);

                var result = insertCommand.ExecuteNonQuery();
                if (result > 0)
                    return 1;
                else
                    return 0;
         
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
            finally
            {
                con.Close();
            }
        }

        public PaginatedViewModel<UserFullInfoModel> TableRecordListAndFunction(UserTableFunctionalityParmetere UsertableFP)
        {
            int pageSize = 5;
            List<UserFullInfoModel> userFullInfoList = GetUserFullInfoList();
            string userNameSorting = "userNameDesc";
            string emailSorting = "emaildesc";
            string de = "";
            switch (UsertableFP.sortOrder)
            {
                case "userNameDesc":
                    userFullInfoList = userFullInfoList.OrderByDescending(u => u.UserName).ToList();
                    userNameSorting = "userNameAsc";
                    break;
                case "userNameAsc":
                    userFullInfoList = userFullInfoList.OrderBy(u => u.UserName).ToList();
                    userNameSorting = "userNameDesc";
                    break;
                case "emaildesc":
                    userFullInfoList = userFullInfoList.OrderByDescending(u => u.Email).ToList();
                    emailSorting = "emailAsc";
                    break;
                case "emailAsc":
                    userFullInfoList = userFullInfoList.OrderBy(u => u.Email).ToList();
                    emailSorting = "emaildesc";
                    break;
                default:
                    userFullInfoList = userFullInfoList.ToList();
                    de = "default";
                    break;
            }

            if (!string.IsNullOrEmpty(UsertableFP.searchString))
            {
                userFullInfoList = userFullInfoList
                    .Where(u => u.Email.Contains(UsertableFP.searchString, StringComparison.OrdinalIgnoreCase))
                    .ToList();
            }


            int totalUsers = userFullInfoList.Count();

            // Calculate the total number of pages
            int totalPages = (int)Math.Ceiling(totalUsers / (double)pageSize);

            // Fetch the users for the current page
            List<UserFullInfoModel> usersOnCurrentPage = userFullInfoList
                .Skip((UsertableFP.pageIndex - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            // Create a view model to pass pagination data to the view
            var viewModel = new PaginatedViewModel<UserFullInfoModel>
            {
                Items = usersOnCurrentPage,
                PageIndex = UsertableFP.pageIndex,
                TotalPages = totalPages,
                PageSize = pageSize,
                TotalItems = totalUsers,
                UserNameSorting = userNameSorting,
                EmailSorting = emailSorting,
                sortOrder = de,
                CurrentSerching = UsertableFP.searchString
            };

            return viewModel;
        }

        public UserModel GetActiveUserInfoByUserId(string userId)
        {
            UserModel user = new UserModel();

            string ConnectionString = _config.GetConnectionString("IdentityDemoTwoContextConnection");
            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();
            string InsertCommand = "select * from UserTable where AspNetUserID = @AspNetUserID";

            try
            {

                SqlCommand insertCommand = new SqlCommand(InsertCommand, con);
                insertCommand.Parameters.AddWithValue("@AspNetUserID", userId);

                SqlDataReader sqlDataReader = insertCommand.ExecuteReader();

                while (sqlDataReader.Read())
                {
                    user.AspNetUserID = sqlDataReader.GetString("AspNetUserID");
                    user.UserName = sqlDataReader.GetString("UserName");
                    user.FirstName = sqlDataReader.GetString("FirstName");
                    user.LastName = sqlDataReader.GetString("LastName");
                    user.PhoneName = sqlDataReader.GetString("PhoneName");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
            finally
            {
                con.Close();
            }


            return user;
        }

        public UserModel GetActiveUserInfoByEmail(string email)
        {
            UserModel user = new UserModel();

            string ConnectionString = _config.GetConnectionString("IdentityDemoTwoContextConnection");
            SqlConnection con = new SqlConnection(ConnectionString);
            con.Open();
            string InsertCommand = "select UT.UsrId, UT.AspNetUserID,AU.Email, AU.Email,UT.UserName,UT.FirstName,UT.LastName,UT.PhoneName from AspNetUsers As AU Right join UserTable As UT on Au.Id = UT.AspNetUserID where AU.Email = @userEmail";

            try
            {

                SqlCommand insertCommand = new SqlCommand(InsertCommand, con);
                insertCommand.Parameters.AddWithValue("@userEmail", email);

                SqlDataReader sqlDataReader = insertCommand.ExecuteReader();

                while (sqlDataReader.Read())
                {
                    user.AspNetUserID = sqlDataReader.GetString("AspNetUserID");
                    user.UserName = sqlDataReader.GetString("UserName");
                    user.FirstName = sqlDataReader.GetString("FirstName");
                    user.LastName = sqlDataReader.GetString("LastName");
                    user.PhoneName = sqlDataReader.GetString("PhoneName");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
            finally
            {
                con.Close();
            }


            return user;
        }

        public List<UserFullInfoModel> GetUserFullInfoList()
        {
            List<UserFullInfoModel> userFullInfoList = new List<UserFullInfoModel>();
            try
            {
                using (SqlConnection con = new SqlConnection(ConnectionString))
                {
                    string query = "select * from  UserFullInfo";
                    SqlCommand cmd = new SqlCommand(query, con);
                    con.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                        UserFullInfoModel userFullInfo = new UserFullInfoModel();
                        userFullInfo.Id = Convert.ToString(dr.GetValue("Id"));
                        userFullInfo.UserName = Convert.ToString(dr.GetValue("UserName"));
                        userFullInfo.FirstName = Convert.ToString(dr.GetValue("FirstName"));
                        userFullInfo.LastName = Convert.ToString(dr.GetValue("LastName"));
                        userFullInfo.PhoneName = Convert.ToString(dr.GetValue("PhoneName"));
                        userFullInfo.Email = Convert.ToString(dr.GetValue("Email"));
                        userFullInfo.RoleId = dr.IsDBNull(dr.GetOrdinal("RoleId")) ? 0 : Convert.ToInt32(dr["RoleId"]);
                        userFullInfo.Name = Convert.ToString(dr.GetValue("Name"));
                        userFullInfoList.Add(userFullInfo);
                    }
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }

            var userFullInfoListPage = userFullInfoList.Skip(0).Take(5);

            return userFullInfoList;
        }
    }
}
