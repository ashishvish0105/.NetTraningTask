﻿//using MailKit.Net.Smtp;
//using MailKit.Security;
using Microsoft.Extensions.Options;
//using MimeKit;


namespace IdentityDemoTwo.Services
{
    public class EmailServiceMailKit
    {
        private readonly EmailSettings _emailSettings;

        public EmailServiceMailKit(IOptions<EmailSettings> emailSettings)
        {
            _emailSettings = emailSettings.Value;
        }

        //public async Task SendEmailAsync(string toEmail, string subject, string message)
        //{
        //    var email = new MimeMessage();
        //    email.From.Add(new MailboxAddress(_emailSettings.SenderName, _emailSettings.SenderEmail));
        //    //email.To.Add(new MailboxAddress(toEmail));
        //    email.Subject = subject;
        //    email.Body = new TextPart("plain") { Text = message };

        //    using var smtp = new SmtpClient();
        //    smtp.ServerCertificateValidationCallback = (s, c, h, e) => true;
        //    await smtp.ConnectAsync(_emailSettings.SmtpServer, _emailSettings.SmtpPort, SecureSocketOptions.StartTls);
        //    await smtp.AuthenticateAsync(_emailSettings.SmtpUsername, _emailSettings.SmtpPassword);
        //    await smtp.SendAsync(email);
        //    await smtp.DisconnectAsync(true);
        //}
    }
    public interface IEmailService
    {
        Task SendEmailAsync(string toEmail, string subject, string message);
    }

    public class EmailSettings
    {
        public string SenderEmail { get; set; }
        public string SenderName { get; set; }
        public string SmtpServer { get; set; }
        public int SmtpPort { get; set; }
        public string SmtpUsername { get; set; }
        public string SmtpPassword { get; set; }
    }
}
