﻿namespace IdentityDemoTwo.Services
{
    public class PaytemPaymentProccess
    {
    }
}
