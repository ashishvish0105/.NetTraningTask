using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using IdentityDemoTwo.Data;
using IdentityDemoTwo.InterFace;
using IdentityDemoTwo.Services;
using Microsoft.Extensions.DependencyInjection;


var builder = WebApplication.CreateBuilder(args);

string connectionString = builder.Configuration.GetConnectionString("IdentityDemoTwoContextConnection");

builder.Services.AddDbContext<IdentityDemoTwoContext>(options => options.UseSqlServer(connectionString));

//builder.Services.AddDefaultIdentity<IdentityUser>().AddEntityFrameworkStores<IdentityDemoTwoContext>();
builder.Services.AddIdentity<IdentityUser, IdentityRole>()
    .AddEntityFrameworkStores<IdentityDemoTwoContext>()
    .AddDefaultTokenProviders();

builder.Services.AddTransient<IEmailSender, EmailSender>();

builder.Services.AddScoped<IUserTableInterface, UserTable>();

builder.Services.Configure<Dictionary<string, string>>(builder.Configuration.GetSection("Paytm"));


builder.Services.AddAuthorization(options =>
    options.AddPolicy("TwoFactorEnabled", x => x.RequireClaim("amr", "mfa")));

//// Add services to the container.
//builder.Services.AddDbContext<UserTable>(options =>
//    options.UseSqlServer(connectionString));



builder.Services.AddRazorPages();
// Add services to the container.
builder.Services.AddControllersWithViews();

//builder.Services.ConfigureApplicationCookie(options =>
//{
//    options.Cookie.HttpOnly = true;
//    options.ExpireTimeSpan = TimeSpan.FromDays(30);
//    options.LoginPath = "Identity/Account/Login";
//    options.AccessDeniedPath = "Identity/Account/AccessDenied";
//    options.SlidingExpiration = true;
//});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();


app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");
app.MapRazorPages();


app.Run();
