﻿using IdentityDemoTwo.InterFace;
using IdentityDemoTwo.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace IdentityDemoTwo.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<IdentityUser> _userManager;
        private readonly SignInManager<IdentityUser> _signInManager;
        private readonly IEmailSender _emailSender;

        public AccountController(UserManager<IdentityUser> userManager, SignInManager<IdentityUser> signInManager, IEmailSender emailSender)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _emailSender = emailSender;
        }

        public IActionResult Index()
        {
            return View();
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> ManageTwoFactorAuthentication()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound($"Unable to load user with ID '{_userManager.GetUserId(User)}'.");
            }

            //First, we need to check whether the User Phone and Email is confirmed or not
            if (!user.EmailConfirmed)
            {
                ViewBag.ErrorTitle = "You cannot Enable/Disable Two Factor Authentication";
                ViewBag.ErrorMessage = "Your Phone Number and Email Not Yet Confirmed";
                return View("index");
            }

            string Message;
            if (user.TwoFactorEnabled)
            {
                Message = "Disable 2FA";
            }
            else
            {
                Message = "Enable 2FA";
            }

            //Generate the Two Factor Authentication Token
            var TwoFactorToken = await _userManager.GenerateTwoFactorTokenAsync(user, TokenOptions.DefaultPhoneProvider);

            //Send the Token to user Mobile Number and Email Id

            ////Sending SMS
            //var result = await smsSender.SendSmsAsync(user.PhoneNumber, $"Your Token to {Message} is {TwoFactorToken}");

            //Sending Email
            await _userManager.SetEmailAsync(user, user.Email);

            return View(); // View for the user to enter the token
        }

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> ManageTwoFactorAuthentication(string Token)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound($"Unable to load user with ID '{_userManager.GetUserId(User)}'.");
            }

            var result = await _userManager.VerifyTwoFactorTokenAsync(user, TokenOptions.DefaultPhoneProvider, Token);
            if (result)
            {
                // Token is valid
                if (user.TwoFactorEnabled)
                {
                    user.TwoFactorEnabled = false;
                    ViewBag.Message = "You have Sucessfully Disabled Two Factor Authentication";
                }
                else
                {
                    user.TwoFactorEnabled = true;
                    ViewBag.Message = "You have Sucessfully Enabled Two Factor Authentication";
                }

                await _userManager.UpdateAsync(user);

                // Redirect to success page 
                return View("TwoFactorAuthenticationSuccessful");
            }
            else
            {
                // Handle invalid token
                ViewBag.ErrorTitle = "Unable to Enable/Disable Two Factor Authentication";
                ViewBag.ErrorMessage = "Either the Token is Expired or you entered some wrong information";
                return View("Error");
            }
        }

    }
}
