﻿using IdentityDemoTwo.Models.Paytm;
using IdentityDemoTwo.Security;
using IdentityDemoTwo.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Newtonsoft.Json;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace IdentityDemoTwo.Controllers
{
    public class PaytmController : Controller
    {
        private readonly string MId = "cXzCrh60287769032052";
        private readonly string MKey = "TujanvnglKF%e7Jp";
        private readonly string CuttomerID = "TujanvnglKF%e7Jp";
        private readonly string ProductID = "TujanvnglKF%e7Jp";
     

        private readonly IConfiguration _configuration;

        public PaytmController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public IActionResult InitiatePayment()
        {
            return View();
        }

        [HttpPost]
        public IActionResult InitiatePayment(PaytmCreaticialModel model)
        {
            model.Mid = _configuration["Paytm:Mid"];
            model.Key = _configuration["Paytm:Key"];
            model.CallbackUrl = "https://localhost:44323/Paytm/Callback";
            model.OrderId = "ORDERID_" + new Random().Next(10000, 99999);
            model.Amount = 1.00M; // Example amount
            model.CustomerId = "CUST_001";
            model.IndustryTypeId = "Retail";
            model.ChannelId = "WEB";

            var paytmParams = new Dictionary<string, object>
        {
            { "MID", model.Mid },
            { "WEBSITE", model.Website },
            { "ORDER_ID", model.OrderId },
            { "CUST_ID", model.CustomerId },
            { "INDUSTRY_TYPE_ID", model.IndustryTypeId },
            { "CHANNEL_ID", model.ChannelId },
            { "TXN_AMOUNT", model.Amount.ToString() },
            { "CALLBACK_URL", model.CallbackUrl }
        };

            string paytmParamsJson = JsonConvert.SerializeObject(paytmParams);
            string checksum = PaytmChecksum.GenerateSignature(paytmParamsJson, model.Key);

            paytmParams.Add("CHECKSUMHASH", checksum);

            return View("RedirectToPaytm", paytmParams);
        }

        [HttpPost]
        public IActionResult Callback()
        {
            PaytmCreaticialModel model = new PaytmCreaticialModel();
            var paytmParams = new Dictionary<string, string>();


            var formCollection = Request.Form;

            string paytmParamsJsonGenrate = JsonConvert.SerializeObject(Request.Form);
            string checksum = PaytmChecksum.GenerateSignature(paytmParamsJsonGenrate, model.Key);

            paytmParams.Add("CHECKSUMHASH", checksum);



            foreach (var key in formCollection.Keys)
            {
                paytmParams[key] = formCollection[key];
            }

            string paytmChecksum = paytmParams["CHECKSUMHASH"];
            //paytmParams.Remove("CHECKSUMHASH");

            string paytmParamsJson = JsonConvert.SerializeObject(paytmParams);
            bool isValidChecksum = PaytmChecksum.VerifySignature(paytmParamsJson, _configuration["Paytm:Key"], paytmChecksum);

            if (isValidChecksum)
            {
                string resultStatus = paytmParams["STATUS"];
                if (resultStatus == "TXN_SUCCESS")
                {
                    ViewBag.Message = "Payment successful!";
                    // Process the successful payment
                }
                else
                {
                    ViewBag.Message = "Payment failed: " + paytmParams["RESPMSG"];
                    // Handle the failed payment
                }
            }
            else
            {
                ViewBag.Message = "Checksum validation failed.";
            }

            return View();
        }



        public IActionResult RedirectToPaytm()
        {
            return View();
        }

        public IActionResult InitiateTransaction()
        {
            PaytmModel paytm = new PaytmModel();
            PaytmServices paytmServices = new PaytmServices();
            string RedirectUrl = paytmServices.PaytmPaymentInitiateTransactionMethod(paytm);
            return Redirect(RedirectUrl);
        }

        public IActionResult PaytmPaymentProcessTransactionMethod()
        {
            PaytmCreaticialModel paytm = new PaytmCreaticialModel();
            PaytmServices paytmServices = new PaytmServices();
            string RedirectUrl = paytmServices.PaytmPaymentProcessTransactionMethod(paytm);
            return Redirect(RedirectUrl);
        }



    }
}
