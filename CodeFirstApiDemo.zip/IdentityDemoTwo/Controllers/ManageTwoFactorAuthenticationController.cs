﻿using IdentityDemoTwo.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.AspNetCore.Mvc;

namespace IdentityDemoTwo.Controllers
{

    public class ManageTwoFactorAuthenticationController : Controller
    {
        private readonly UserManager<IdentityUser> userManager;
        private readonly SignInManager<IdentityUser> _signInManager;
        private readonly ILogger<TwoFactorController> _logger;
        private readonly EmailSender emailSender;
        public ManageTwoFactorAuthenticationController(
             UserManager<IdentityUser> _userManager,
             SignInManager<IdentityUser> signInManager,
             ILogger<TwoFactorController> logger, EmailSender _emailSender)
        {
            userManager = _userManager;
            _signInManager = signInManager;
            _logger = logger;
            emailSender = _emailSender;
        }

        public IActionResult Index()
        {
            return View();  
        }


        [Authorize]
        [HttpPost]
        public async Task<IActionResult> ManageTwoFactorAuthentication(string Token)
        {
            var user = await userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound($"Unable to load user with ID '{userManager.GetUserId(User)}'.");
            }

            var result = await userManager.VerifyTwoFactorTokenAsync(user, TokenOptions.DefaultPhoneProvider, Token);
            if (result)
            {
                // Token is valid
                if (user.TwoFactorEnabled)
                {
                    user.TwoFactorEnabled = false;
                    ViewBag.Message = "You have Sucessfully Disabled Two Factor Authentication";
                }
                else
                {
                    user.TwoFactorEnabled = true;
                    ViewBag.Message = "You have Sucessfully Enabled Two Factor Authentication";
                }

                await userManager.UpdateAsync(user);

                // Redirect to success page 
                return View("TwoFactorAuthenticationSuccessful");
            }
            else
            {
                // Handle invalid token
                ViewBag.ErrorTitle = "Unable to Enable/Disable Two Factor Authentication";
                ViewBag.ErrorMessage = "Either the Token is Expired or you entered some wrong information";
                return View("Error");
            }
        }

    }
}
