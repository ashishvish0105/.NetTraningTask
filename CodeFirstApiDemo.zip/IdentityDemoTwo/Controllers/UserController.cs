﻿using IdentityDemoTwo.Areas.Identity.Data;
using IdentityDemoTwo.InterFace;
using IdentityDemoTwo.Models;
using IdentityDemoTwo.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;

namespace IdentityDemoTwo.Controllers
{
    public class UserController : Controller
    {
        private readonly IUserTableInterface _UserTable;
        public UserController(IUserTableInterface UserTable)
        {
            _UserTable = UserTable;
        }

        public IActionResult Index(string searchString, string sortOrder, int pageIndex=1)
        {
      
            UserTableFunctionalityParmetere UsertableFP = new UserTableFunctionalityParmetere()
            {
                pageIndex = pageIndex,
                searchString = searchString,
                sortOrder = sortOrder
            };

            PaginatedViewModel<UserFullInfoModel> viewModel = _UserTable.TableRecordListAndFunction(UsertableFP);


            FrontendModel frontendModel = new FrontendModel()
            {
                UIUserTableFunctionalityParmetere = UsertableFP,
                UIPaginatedViewModel = viewModel
            };

            return View(frontendModel);
        }

    }
}
