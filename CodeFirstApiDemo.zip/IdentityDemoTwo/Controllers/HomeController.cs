using IdentityDemoTwo.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Microsoft.AspNetCore.Authorization;
using System.Linq;
using System.Security.Claims;
using Microsoft.AspNetCore.Identity;
using IdentityDemoTwo.Services;
using IdentityDemoTwo.Areas.Identity.Data;
using IdentityDemoTwo.InterFace;

namespace IdentityDemoTwo.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly UserManager<IdentityUser> _userManager;
        private readonly IConfiguration _config;
        private readonly IUserTableInterface _UserService;

        public HomeController(ILogger<HomeController> logger, UserManager<IdentityUser> userManager, IConfiguration config, IUserTableInterface UserService)
        {
            _logger = logger;
            _userManager = userManager;
            _config = config;
            _UserService = UserService;
        }

        public IActionResult Index(string email)
        {
            try
            {
                if(email != null)
                {
                    var uesermail = _userManager.FindByEmailAsync(email);
                    //var uesermail = TempData["usermail"];
                    UserModel user = _UserService.GetActiveUserInfoByUserId(Convert.ToString(uesermail.Result.Id));
                    return View(user);
                }
                else
                {
                    return View();
                }
            }
            catch (Exception)
            {
                return Redirect("/identity/Account/login");
            }
        }

        //public IActionResult Index(string? email)
        //{
        //    UserModel userAddNewField = new UserModel();

        //    return View();
        //}

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
