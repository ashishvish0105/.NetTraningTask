﻿using IdentityDemoTwo.Models.Paytm;
using IdentityDemoTwo.Services.Paytm;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;


namespace IdentityDemoTwo.Controllers
{
    public class PaytemPaymentProccessController : Controller
    {
        private readonly PaytmPaymentGateway _paytmPaymentGateway;
        private readonly IOptions<PaytmSettings> _paytmSettings;
        private readonly IConfiguration _configuration;

        public PaytemPaymentProccessController(IOptions<PaytmSettings> paytmSettings, IConfiguration configuration)
        {
            _paytmSettings = paytmSettings;
      
            _configuration = configuration;
            _paytmPaymentGateway = new PaytmPaymentGateway(
               _paytmSettings.Value.MerchantId,
               _paytmSettings.Value.MerchantKey,
               _paytmSettings.Value.PaymentUrl,
               _paytmSettings.Value.CallbackUrl
           );
        }

        [HttpPost]
        public IActionResult MakePayment(PaytmPaymentModel model)
        {
            PaytmPaymentModel paytmRequest = new PaytmPaymentModel(){
                OrderId = model.OrderId,
                CustomerId = model.CustomerId,
                Amount = model.Amount,
                Email = model.Email,
                Mobile = model.Mobile
            };

            var paytmResponse = _paytmPaymentGateway.MakePayment(paytmRequest);

            if (paytmResponse.IsSuccess)
            {
                return RedirectToAction("PaymentSuccessful");
            }
            else
            {
                return RedirectToAction("PaymentFailed");
            }
        }

        public IActionResult PaymentSuccessful()
        {
            return View();
        }

        public IActionResult PaymentFailed()
        {
            return View();
        }

        [HttpPost]
        public IActionResult PaytmCallback(string orderId, string status)
        {
            if (status == "TXN_SUCCESS")
            {
                // Update the order status to "Paid"
                // ...
            }
            else
            {
                // Update the order status to "Failed"
                // ...
            }

            return RedirectToAction("PaymentSuccessful");
        }

    }
}
