﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using IdentityDemoTwo.Models;
using System.Text.Encodings.Web;
using System.Text;
using IdentityDemoTwo.Services;
using Microsoft.AspNetCore.Authorization;

namespace IdentityDemoTwo.Controllers
{
    public class TwoFactorController : Controller
    {
        private readonly UserManager<IdentityUser> _userManager;
        private readonly SignInManager<IdentityUser> _signInManager;
        private readonly ILogger<TwoFactorController> _logger;
        private readonly EmailSender _emailSender;
        public TwoFactorController(
             UserManager<IdentityUser> userManager,
             SignInManager<IdentityUser> signInManager,
             ILogger<TwoFactorController> logger, EmailSender emailSender)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _logger = logger;
            _emailSender= emailSender;
        }

 

    }
}
