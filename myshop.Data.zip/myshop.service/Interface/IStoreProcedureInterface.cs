﻿using myshop.service.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myshop.service.Interface
{
    public interface IStoreProcedureInterface
    {
        public Task<List<ShopMasterDTO>> getShopListSp();
    }
}
