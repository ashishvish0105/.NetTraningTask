﻿
using myshop.Data.Data;
using myshop.service.Model;

namespace myshop.api.Interface
{
    public interface IShopMasterService
    {
        public Task<List<ShopMasterDTO>> GetListShop();
        public Task<bool> InsertShopDetail(ShopMasterDTO shopMaster);
        public Task<bool> DeleteShopDetail(int ShopID);
        public Task<bool> UpdateShopDetail(ShopMasterDTO shop);
        public Task<ShopMasterDTO> ShopDetail(int ShopID);

    }
}
