﻿//using myshop.Data.Data;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace myshop.service.HelperServices
//{
//    public static class DbServices
//    {
//        private static MyShopContext? _dbContext;
//        //public DataBaseServices(MyShopContext dbContext)
//        //{
//        //    this._dbContext = dbContext;    
//        //}

//        public static void setDbcontext(MyShopContext dbContext)
//        {
//            _dbContext = dbContext;
//        }

//        public static MyShopContext ReturnDbcontext()
//        {
//            return _dbContext;
//        }
//    }
//}
