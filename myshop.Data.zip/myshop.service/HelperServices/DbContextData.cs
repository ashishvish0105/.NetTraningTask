﻿using myshop.Data.Data;

namespace myshop.service.HelperServices
{
    public  class DbContextData
    {

        public static MyShopContext _dbcontext;

        //public static DbContextData(DataBaseServices _dataBaseServices)
        //{

        //}

        public static void Set(MyShopContext dbcontext)
        {
            _dbcontext = dbcontext;
        }

        public static void SetDbcontextData(MyShopContext dbcontext)
        {
            _dbcontext = dbcontext;
        }

        public static MyShopContext Returndata()
        {
            return _dbcontext;
        }
    }
}
