﻿namespace myshop.service
{
    public class Class1
    {

    }
}
