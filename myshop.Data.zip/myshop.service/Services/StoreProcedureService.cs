﻿
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using myshop.Data.Data;
using myshop.service.Interface;
using myshop.service.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myshop.service.Services
{
    public class StoreProcedureService : IStoreProcedureInterface
    {
        private readonly MyShopContext _dbContext;
        public StoreProcedureService(MyShopContext dbcontext) {
            _dbContext = dbcontext;
        }

        public async Task<List<ShopMasterDTO>> getShopListSp()
        {
            //var result = await _dbContext.ShopMasters.FromSql<ShopMaster>($"EXEC GetListShopMaster").ToListAsync();

            List<ShopMaster> result = await _dbContext.Database.SqlQuery<ShopMaster>($"EXEC GetListShopMaster").ToListAsync();


            IMapper mapper = new MapperConfiguration(map =>
            {
                map.CreateMap<ShopMaster, ShopMasterDTO>();
            }).CreateMapper();


            List<ShopMasterDTO> listShopMasterDTO = mapper.Map<List<ShopMasterDTO>>(result);

            //List<ShopMasterDTO> returnObject = new List<ShopMasterDTO>();
            //if (result.Count != 0)
            //{
            //    foreach (var item in result)
            //    {
            //        ShopMasterDTO objectData = new ShopMasterDTO()
            //        {
            //            ShopId = item.ShopId,
            //            ShopName = item.ShopName,
            //            ShopAddress = item.ShopAddress,
            //            ShopContact = item.ShopContact,
            //            OwnerId = item.OwnerId,
            //            OwnerName = item.OwnerName,
            //            OwnerContact = item.OwnerContact,
            //            EmployeeId = item.EmployeeId,
            //            EmployeeName = item.EmployeeName,
            //            EmployeeContact = item.EmployeeContact,
            //        };
            //        returnObject.Add(objectData);
            //    }
            //}

            //return returnObject;

            return listShopMasterDTO;

        }
    }
}
