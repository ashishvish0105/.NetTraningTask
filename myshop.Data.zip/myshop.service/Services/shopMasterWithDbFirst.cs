﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using myshop.api.Interface;
using myshop.Data.Data;
using myshop.service.HelperServices;
using myshop.service.Model;
using System.Collections.Generic;

namespace myshop.api.Services
{
    public class shopMasterWithDbFirst : IShopMasterService
    {


        private MyShopContext _dbcontext = DbContextData.Returndata();

        //private readonly MyShopContext _dbcontextData;

        //public shopMasterWithDbFirst(MyShopContext dbcontext)
        //{
        //    _dbcontextData = dbcontext;
        //}

        public async Task<List<ShopMasterDTO>> GetListShop()
        {
            //List<ShopMasterDTO> listShopMasterDTO = new List<ShopMasterDTO>();

            List<ShopMaster> shopMasters = await DbContextData._dbcontext.ShopMasters.ToListAsync();
            IMapper mapper = new MapperConfiguration(map =>
            {
                map.CreateMap<ShopMaster, ShopMasterDTO>();
            }).CreateMapper();

            List<ShopMasterDTO> listShopMasterDTO = mapper.Map<List<ShopMasterDTO>>(shopMasters);

            return listShopMasterDTO;

        }


        public async Task<ShopMasterDTO> ShopDetail(int ShopID)
        {
            var ShopMasterDTO = await _dbcontext.ShopMasters.FirstOrDefaultAsync(x => x.ShopId == ShopID);

            IMapper mapper = new MapperConfiguration(map =>
            {
                map.CreateMap<ShopMaster, ShopMasterDTO>();
            }).CreateMapper();

            ShopMasterDTO listShopMasterDTO = mapper.Map<ShopMasterDTO>(ShopMasterDTO);

            return listShopMasterDTO;
        }

        public async Task<bool> UpdateShopDetail(ShopMasterDTO shop)
        {
            var shopDetail = await _dbcontext.ShopMasters.FirstOrDefaultAsync(x => x.ShopId == shop.ShopId);

            if (shopDetail == null)
            {
                return false;
            }

            ShopMaster ShopMasterDTO = new ShopMaster()
            {
                ShopAddress = shop.ShopAddress,
                ShopName = shop.ShopName,
                EmployeeContact = shop.EmployeeContact,
                EmployeeId = shop.EmployeeId,
                EmployeeName = shop.EmployeeName,
                OwnerContact = shop.OwnerContact,
                OwnerId = shop.OwnerId,
                OwnerName = shop.OwnerName,
                ShopContact = shop.ShopContact,
            };

            _dbcontext.ShopMasters.Update(ShopMasterDTO);
            int IsUpdatedate = await _dbcontext.SaveChangesAsync();


            return IsUpdatedate > 0 ? true : false;
        }

        public async Task<bool> DeleteShopDetail(int ShopID)
        {
            ShopMaster shopDetail = await _dbcontext.ShopMasters.FirstOrDefaultAsync(x => x.ShopId == ShopID);

            if (shopDetail == null)
            {
                return false;
            }

            _dbcontext.ShopMasters.Remove(shopDetail);
            int ISdelete = await _dbcontext.SaveChangesAsync();

            return ISdelete > 0 ? true : false;
        }

        public async Task<bool> InsertShopDetail(ShopMasterDTO shopMaster)
        {
            ShopMaster ShopMasterDTO = new ShopMaster()
            {
                ShopId = 0,
                ShopAddress = shopMaster.ShopAddress,
                ShopName = shopMaster.ShopName,
                EmployeeContact = shopMaster.EmployeeContact,
                EmployeeId = shopMaster.EmployeeId,
                EmployeeName = shopMaster.EmployeeName,
                OwnerContact = shopMaster.OwnerContact,
                OwnerId = shopMaster.OwnerId,
                OwnerName = shopMaster.OwnerName,
                ShopContact = shopMaster.ShopContact,
            };

            if (shopMaster == null)
            {
                return false;
            }
            _dbcontext.ShopMasters.AddAsync(ShopMasterDTO);

            int ISdelete = await _dbcontext.SaveChangesAsync();

            return ISdelete > 0 ? true : false;
        }

    }
}
