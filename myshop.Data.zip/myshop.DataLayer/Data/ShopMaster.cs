﻿using System;
using System.Collections.Generic;

namespace myshop.Data.Data;

public partial class ShopMaster
{
    public int ShopId { get; set; }

    public string ShopName { get; set; } = null!;

    public string ShopAddress { get; set; } = null!;

    public string? ShopContact { get; set; }

    public int? OwnerId { get; set; }

    public string? OwnerName { get; set; }

    public string? OwnerContact { get; set; }

    public int? EmployeeId { get; set; }

    public string? EmployeeName { get; set; }

    public string? EmployeeContact { get; set; }
}
