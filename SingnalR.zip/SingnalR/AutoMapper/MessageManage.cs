﻿using AutoMapper;
using SingnalR.AppData.TablesEntity;
using SingnalR.Models;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace SingnalR.AutoMapper
{
    public class MessageManage : Profile
    {
        public MessageManage()
        {
            CreateMap<MessageTable, GetMesssage>();
        }
    }
}
