﻿"use strict";

var connection = new signalR.HubConnectionBuilder().withUrl("/chatHub").build();

//Disable the send button until connection is established.
document.getElementById("sendButton").disabled = true;

connection.on("ReceiveMessage", function (user, message) {
    document.getElementById("messageInput").value = "";
    var notification = document.querySelector("#notification > span")
    var messageAvailable = notification.classList.contains("messageAvailable")
    const getCurrentUser = sessionStorage.getItem("currentUser");
    
    
    if (message.length > 0 && getCurrentUser != user) {
        notification.style.display = "inline-block";
    } else {
        notification.style.display = "none";
    }

    //var li = document.createElement("li");





    //// We can assign user-supplied strings to an element's textContent because it
    //// is not interpreted as markup. If you're assigning in any other way, you
    //// should be aware of possible script injection concerns.
    //li.textContent = `${user} says ${message}`;

    let messagesContainer = document.getElementById("messagesList");
    debugger
    let li = document.createElement("li");
    li.className = (user === "User2" ? "sender" : "repaly");


    let dateObject = new Date();

 
        let time = dateObject.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
   

    li.innerHTML = `<p>${message}</p><span class="time">${time}</span>`;
    messagesContainer.appendChild(li);

    //document.getElementById("messagesList").appendChild(li);

    scrollToBottom()


});

connection.start().then(function () {
    document.getElementById("sendButton").disabled = false;
}).catch(function (err) {
    return console.error(err.toString());
});

document.getElementById("sendButton").addEventListener("click", function (event) {
    var user = document.getElementById("userInput").value;
    var message = document.getElementById("messageInput").value;

    connection.invoke("SendMessage", user, message).catch(function (err) {
        return console.error(err.toString());
    });
    event.preventDefault();
});


function messageDisplay() {

    $.ajax({
        url: '/chat/ShowMessageList',
        type: 'GET',
        contentType: 'application/json',
        success: function (response) {
            debugger;
            if (response.success) {
                let messageList = response.data;
                let messagesContainer = document.getElementById("messagesList");
                let couteDate = 0;
                let currentDate = '';

                messageList.forEach(item => {
                    let date = new Date(item.timestamp).toISOString().split('T')[0]; // Extract the date in "yyyy-MM-dd" format

                    if (couteDate == 0) {
                        currentDate = date;
                        couteDate = 1;

                        // Add a date divider
                        let dateDivider = document.createElement("li");
                        dateDivider.innerHTML = `<div class="divider"><h6>${currentDate}</h6></div>`;
                        messagesContainer.appendChild(dateDivider);
                    }

                    if (currentDate !== date) {
                        currentDate = date;

                        // Reset couteDate to add new date divider for the new date
                        couteDate = 0;
                    }

                    // Add message
                    let li = document.createElement("li");
                    li.className = (item.useName === "User2" ? "sender" : "repaly");

                    // Format time in "hh:mm tt" format
                    let time = new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });

                    li.innerHTML = `<p>${item.messgae}</p><span class="time">${time}</span>`;
                    messagesContainer.appendChild(li);
                });
            } else {
                console.log('Error:', response.message);
            }
        },
        error: function (xhr, status, error) {
            console.log('AJAX Error:', error);
        }
    });
}


setTimeout(() => {
    messageDisplay();
    scrollToBottom()
},2000)

function scrollToBottom() {
    var container = document.getElementById("messagesList");
    var lastMessage = container.lastElementChild;
    if (lastMessage) {
        lastMessage.scrollIntoView({ behavior: "smooth" });
    }
}