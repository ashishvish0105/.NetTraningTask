﻿using System.ComponentModel.DataAnnotations;

namespace SingnalR.Models
{
    public class MessageModel
    {
        public required string UseName { get; set; }
        public required string Messgae { get; set; }
    }
    public class NotifiactionModel
    {
        public string UseId { get; set; }
        public int messageCount { get; set; }
    }

    public class GetMesssage
    {
        public string UseId { get; set; }
        public string UseName { get; set; }
        public string Messgae { get; set; }
        public int MessageCoute { get; set; }
        public bool MessageSeen { get; set; }
        public DateTime Timestamp { get; set; }

        //public GetMesssage()
        //{
        //    this.Timestamp= DateTime.Today;
        //}
    }

}
