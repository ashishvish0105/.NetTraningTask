﻿using SingnalR.Models;

namespace SingnalR.InserFaces
{
    public interface IMessage
    {
        public bool InsertMessage(MessageModel message);
        public List<GetMesssage> GetListMessage();
    }
}
