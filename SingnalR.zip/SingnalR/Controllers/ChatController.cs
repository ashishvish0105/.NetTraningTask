﻿using Microsoft.AspNetCore.Mvc;
using SingnalR.InserFaces;
using SingnalR.Models;

namespace SingnalR.Controllers
{
    public class ChatController : Controller
    {
        private readonly IMessage _messageServices;
        public ChatController(IMessage messageServices)
        {
            _messageServices= messageServices;  
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Message()
        {
            return View();
        }

        [HttpGet]
        [Route("MessageList")]
        [Route("/chat/MessageList")]
        public IActionResult MessageList()
        {
            List<GetMesssage> GetListMesssage= _messageServices.GetListMessage();
            return View(GetListMesssage);
        }


        [HttpGet]
        [Route("ShowMessageList")]
        [Route("/chat/ShowMessageList")]
        public ApiResponse ShowMessageList()
        {
            List<GetMesssage> GetListMesssage = _messageServices.GetListMessage();

            ApiResponse apiResponse = new ApiResponse()
            {
                success= true,
                statusCode=200,
                Data = GetListMesssage,
                Message="get message list"
            };
            return apiResponse;
        }
    }
}
