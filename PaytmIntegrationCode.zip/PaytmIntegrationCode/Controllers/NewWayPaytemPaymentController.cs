﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PaytmIntegrationCode.Services;
using System.Net;
using PaytmIntegrationCode.Models;
using System.IO;
using System.Text;
using Microsoft.AspNetCore.WebUtilities;
using paytm;
using System.Collections.Generic;
namespace PaytmIntegrationCode.Controllers
{
    public class NewWayPaytemPaymentController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        //public IActionResult paymentPayMethod()
        //{
        //    // Generating a unique order ID
        //    string orderid = "A" + DateTime.Now.Ticks.ToString();
        //    var enablePaymentMode = new Dictionary<string, string>();
        //    enablePaymentMode.Add("mode", "");
        //    enablePaymentMode.Add("channels", "");
        //    enablePaymentMode.Add("banks", "");

        //    // Creating a dictionary to hold the parameters required by Paytm
        //    Dictionary<string, string> paytmParams = new Dictionary<string, string>
        //    {
        //        { "MID", "cXzCrh60287769032052" },
        //        { "WEBSITE", "WEBSTAGING" },
        //        { "INDUSTRY_TYPE_ID", "Retail" },
        //        { "CHANNEL_ID", "WEB" },
        //        { "ORDER_ID", orderid },
        //        { "CUST_ID", "4554510" },
        //        { "MOBILE_NO", "8866077896" },
        //        { "EMAIL", "ashishvishwakarma.vision@Gmail.com" },
        //        { "BANKTXNID","NULL"},
        //        { "TXN_AMOUNT", Convert.ToString(Request.Form["Amount"])},
        //        { "CALLBACK_URL", "https://localhost:44385/NewWayPaytemPayment/CallBack" },
          

        //        //{ "enablePaymentMode",JsonConvert.SerializeObject(enablePaymentMode)}

        //        //{ "enablePaymentMode","[{\"mode\" : \"UPI\", \"channels\" : [\"UPIPUSH\"]}]"}
        //    };

        //    // Generate checksum using your Paytm library
        //    string checksum = Checksum.generateSignature(paytmParams, "TujanvnglKF%e7Jp");

        //    // Paytm staging URL
        //    string url = $"https://securegw-stage.paytm.in/theia/processTransaction?orderid={orderid}";

        //    // Building the HTML form
        //    StringBuilder outputHtml = new StringBuilder();
        //    outputHtml.Append("<html>");
        //    outputHtml.Append("<head><title>Merchant Checkout Page</title></head>");
        //    outputHtml.Append("<body>");
        //    outputHtml.Append("<center><h1>Please do not refresh this page...</h1></center>");
        //    outputHtml.Append("<form method='post' action='" + url + "' name='paytm_form'>");

        //    // Add the hidden fields for each Paytm parameter
        //    foreach (var key in paytmParams.Keys)
        //    {
        //        outputHtml.Append("<input type='hidden' name='" + key + "' value='" + paytmParams[key] + "'>");
        //    }

        //    // Add the checksum as a hidden field
        //    outputHtml.Append("<input type='hidden' name='CHECKSUMHASH' value='" + checksum + "'>");
        //    outputHtml.Append("</form>");
        //    outputHtml.Append("<script type='text/javascript'>document.paytm_form.submit();</script>");
        //    outputHtml.Append("</body>");
        //    outputHtml.Append("</html>");

        //    // Return the HTML content to the browser
        //    return Content(outputHtml.ToString(), "text/html");
        //}


        public IActionResult PaytmCodeproject()
        {
            String merchantMid = "cXzCrh60287769032052";
            String merchantKey = "TujanvnglKF%e7Jp";
            Dictionary<string, string> parameters = new Dictionary<string, string>();
            parameters.Add("MID", merchantMid);
            parameters.Add("CHANNEL_ID", "WEB");
            parameters.Add("INDUSTRY_TYPE_ID", "Retail");
            parameters.Add("WEBSITE", "WEBSTAGING");
            parameters.Add("MOBILE_NO", "8866077896");
            parameters.Add("EMAIL", "ashishvishwakarma.vision@Gmail.com");
            parameters.Add("CUST_ID", "Cust-86525");
            parameters.Add("ORDER_ID", "Prod-524125");
            parameters.Add("TXN_AMOUNT", "1.00");
            parameters.Add("CALLBACK_URL", "https://localhost:44385/NewWayPaytemPayment/CallBack");


            string checkSum = CheckSum.generateCheckSum(merchantKey, parameters);
           
            string paytmURL = "https://securegw-stage.paytm.in/theia/processTransaction?orderid=" + parameters.FirstOrDefault(x => x.Key == "ORDER_ID").Value;


            string outputHTML = "<html>";
            outputHTML += "<head>";
            outputHTML += "<title>Merchant Check Out Page</title>";
            outputHTML += "</head>";
            outputHTML += "<body>";
            outputHTML += "<center><h1>Please do not refresh this page...</h1></center>";
            outputHTML += "<form method='post' action='" + paytmURL + "' name='f1'>";
            outputHTML += "<table border='1'>";
            outputHTML += "<tbody>";
            foreach (string key in parameters.Keys)
            {
                outputHTML += "<input type='hidden' name='" + key + "' value='" + parameters[key] + "'>";
            }
            outputHTML += "<input type='hidden' name='CHECKSUMHASH' value='" + checkSum + "'>";
            outputHTML += "</tbody>";
            outputHTML += "</table>";
            outputHTML += "<script type='text/javascript'>";
            outputHTML += "document.f1.submit();";  
            outputHTML += "</script>";
            outputHTML += "</form>";
            outputHTML += "</body>";
            outputHTML += "</html>";

            return Content(outputHTML.ToString(), "text/html");
        }



        public IActionResult InitiateTransactionAPI()
        {
            string mKey = "TujanvnglKF%e7Jp";
            string mid = "cXzCrh60287769032052";
            string website = "WEBSTAGING";
            string industryTypeId = "Retail";
            string channelId = "WEB";
            string orderId = "ORDER_" + DateTime.Now.Ticks.ToString();
            string custId = "CUST_" + DateTime.Now.Ticks.ToString();
            string mobileNo = "8866077896";
            string email = "ashishvishwakarma.vision@Gmail.com";
            string txnAmount = "10.00";
            string callbackUrl = "https://localhost:44385/NewWayPaytemPayment/CallBack";

            // Generate the checksum
            string checksum = CheckSum.generateCheckSum(mKey ,new Dictionary<string, string>
    {
        { "MID", mid },
        { "WEBSITE", website },
        { "INDUSTRY_TYPE_ID", industryTypeId },
        { "CHANNEL_ID", channelId },
        { "ORDER_ID", orderId },
        { "CUST_ID", custId },
        { "MOBILE_NO", mobileNo },
        { "EMAIL", email },
        { "TXN_AMOUNT", txnAmount },
        { "CALLBACK_URL", callbackUrl }
    } );

            // Prepare HTML form for redirect
            string outputHtml = "<html><head><title>Paytm Checkout Page</title></head><body>";
            outputHtml += "<center><h1>Please do not refresh this page...</h1></center>";
            outputHtml += $"<form method='post' action='https://securegw-stage.paytm.in/order/process' name='paytm_form'>";

            outputHtml += $"<input type='hidden' name='MID' value='{mid}' />";
            outputHtml += $"<input type='hidden' name='WEBSITE' value='{website}' />";
            outputHtml += $"<input type='hidden' name='INDUSTRY_TYPE_ID' value='{industryTypeId}' />";
            outputHtml += $"<input type='hidden' name='CHANNEL_ID' value='{channelId}' />";
            outputHtml += $"<input type='hidden' name='ORDER_ID' value='{orderId}' />";
            outputHtml += $"<input type='hidden' name='CUST_ID' value='{custId}' />";
            outputHtml += $"<input type='hidden' name='MOBILE_NO' value='{mobileNo}' />";
            outputHtml += $"<input type='hidden' name='EMAIL' value='{email}' />";
            outputHtml += $"<input type='hidden' name='TXN_AMOUNT' value='{txnAmount}' />";
            outputHtml += $"<input type='hidden' name='CALLBACK_URL' value='{callbackUrl}' />";
            outputHtml += $"<input type='hidden' name='CHECKSUMHASH' value='{checksum}' />";

            outputHtml += "</form>";
            outputHtml += "<script type='text/javascript'>document.paytm_form.submit();</script>";
            outputHtml += "</body></html>";

            return Content(outputHtml, "text/html");
        }




        public IActionResult CallBack()
        {
            String merchantKey = "TujanvnglKF%e7Jp";
           

            Dictionary<string, string> parameters = new Dictionary<string, string>();
            string paytmChecksum = "";
            bool isChecksumValid = false;
            foreach (string key in Request.Form.Keys)
            {
                parameters.Add(key.Trim(), Convert.ToString(Request.Form[key]).Trim());
            }

            if (parameters.ContainsKey("CHECKSUMHASH"))
            {
                paytmChecksum = parameters["CHECKSUMHASH"];
                parameters.Remove("CHECKSUMHASH");
            }

            if (CheckSum.verifyCheckSum(merchantKey, parameters, paytmChecksum))
            {
                isChecksumValid = true;
            }
            else
            {
                isChecksumValid = false;
            }

            if (isChecksumValid)
            {
                string transactionStatus = parameters["STATUS"];
                if (transactionStatus == "TXN_SUCCESS")
                {
                    ViewBag.Message = "Payment successful!";
                }
                else
                {
                    ViewBag.Message = parameters["RESPMSG"];
                }
            }
            else
            {
                ViewBag.Message = "Checksum verification failed!";
            }

            return View();
        }


    }
}
