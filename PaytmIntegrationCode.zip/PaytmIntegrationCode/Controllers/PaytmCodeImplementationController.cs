﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Paytm;
using System.Net;

namespace PaytmIntegrationCode.Controllers
{
    public class PaytmCodeImplementationController : Controller
    {
        private const string MID = "cXzCrh60287769032052";
        private const string MERCHANT_KEY = "TujanvnglKF%e7Jp";
        public IActionResult Index()
        {
            return View();
        }   

        public IActionResult PaytmPaymentInitialTranstaction()
        {
            Random rng = new Random();
            int randomNumber = rng.Next(100000, 999999);
            string orderID = $"OrderId_{randomNumber}";

            Dictionary<string, object> body = new Dictionary<string, object>();
            Dictionary<string, string> head = new Dictionary<string, string>();
            Dictionary<string, object> requestBody = new Dictionary<string, object>();

            Dictionary<string, string> txnAmount = new Dictionary<string, string>();
            txnAmount.Add("value", "1.00");
            txnAmount.Add("currency", "INR");
            Dictionary<string, string> userInfo = new Dictionary<string, string>();
            userInfo.Add("custId", "cust_001");
            userInfo.Add("mobile", "8866077896");
            userInfo.Add("email", "ashishvishwakarma.vision@Gmail.com");
            userInfo.Add("firstName", "ashish");
            userInfo.Add("lastName", "vish");


      

            body.Add("requestType", "Payment");
            body.Add("mid", MID);
            body.Add("websiteName", "WEBSTAGING");
            body.Add("orderId", orderID);
            body.Add("txnAmount", txnAmount);
            body.Add("userInfo", userInfo);

  

            body.Add("callbackUrl", "https://localhost:44385/PaytmCodeImplementation/CheckCallBack");

            string paytmChecksum = Checksum.generateSignature(JsonConvert.SerializeObject(body), MERCHANT_KEY);

            head.Add("signature", paytmChecksum);

            requestBody.Add("body", body);
            requestBody.Add("head", head);

            string post_data = JsonConvert.SerializeObject(requestBody);

            string url = "https://securegw-stage.paytm.in/theia/api/v1/initiateTransaction?mid="+MID+"&orderId="+orderID+"";

            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);

            webRequest.Method = "POST";
            webRequest.ContentType = "application/json";
            webRequest.ContentLength = post_data.Length;

            using (StreamWriter requestWriter = new StreamWriter(webRequest.GetRequestStream()))
            {
                requestWriter.Write(post_data);
            }

            string responseData = string.Empty;

            using (StreamReader responseReader = new StreamReader(webRequest.GetResponse().GetResponseStream()))
            {
                TempData["responseData"] = responseReader.ReadToEnd();
                responseData = responseReader.ReadToEnd();
                Console.WriteLine(responseData);
            }
            return View("CheckCallBack");
        }

        public IActionResult CheckCallBack()
        {
            return View();
        }
        
        public void paytmPaymentProcess()
        {
            Dictionary<string, object> body = new Dictionary<string, object>();
            Dictionary<string, string> head = new Dictionary<string, string>();
            Dictionary<string, object> requestBody = new Dictionary<string, object>();

            Dictionary<string, string> txnAmount = new Dictionary<string, string>();
            txnAmount.Add("value", "1.00");
            txnAmount.Add("currency", "INR");
            Dictionary<string, string> userInfo = new Dictionary<string, string>();
            userInfo.Add("custId", "cust_001");
            body.Add("requestType", "Payment");
            body.Add("mid", "YOUR_MID_HERE");
            body.Add("websiteName", "YOUR_WEBSITE_NAME");
            body.Add("orderId", "ORDERID_98765");
            body.Add("txnAmount", txnAmount);
            body.Add("userInfo", userInfo);
            body.Add("callbackUrl", "https://<callback URL to be used by merchant>");

            /*
            * Generate checksum by parameters we have in body
            * Find your Merchant Key in your Paytm Dashboard at https://dashboard.paytm.com/next/apikeys 
            */
            string paytmChecksum = Checksum.generateSignature(JsonConvert.SerializeObject(body), "YOUR_KEY_HERE");

            head.Add("signature", paytmChecksum);

            requestBody.Add("body", body);
            requestBody.Add("head", head);

            string post_data = JsonConvert.SerializeObject(requestBody);

            //For  Staging
            string url = "https://securegw-stage.paytm.in/theia/api/v1/initiateTransaction?mid=YOUR_MID_HERE&orderId=ORDERID_98765";

            //For  Production 
            //string  url  =  "https://securegw.paytm.in/theia/api/v1/initiateTransaction?mid=YOUR_MID_HERE&orderId=ORDERID_98765";

            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);

            webRequest.Method = "POST";
            webRequest.ContentType = "application/json";
            webRequest.ContentLength = post_data.Length;

            using (StreamWriter requestWriter = new StreamWriter(webRequest.GetRequestStream()))
            {
                requestWriter.Write(post_data);
            }

            string responseData = string.Empty;

            using (StreamReader responseReader = new StreamReader(webRequest.GetResponse().GetResponseStream()))
            {
                responseData = responseReader.ReadToEnd();
                Console.WriteLine(responseData);
            }


        }

    }
}
