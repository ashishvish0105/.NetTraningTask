﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Paytm;
using PaytmIntegrationCode.Models;
using System.ComponentModel;
using System.Net;
using System.Transactions;
using Newtonsoft.Json;

namespace PaytmIntegrationCode.Controllers
{
    public class TheCodeHubController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        string orderid = "pro-" + DateTime.Now.Ticks.ToString();
        public IActionResult InitiateTransactionAPI()
        {
            GenerateUniquekeysModel UniqueKey = new GenerateUniquekeysModel();

            Dictionary<string, object> body = new Dictionary<string, object>();
            Dictionary<string, string> head = new Dictionary<string, string>();
            Dictionary<string, object> requestBody = new Dictionary<string, object>();

            Dictionary<string, string> txnAmount = new Dictionary<string, string>();
            txnAmount.Add("value", "1.00");
            txnAmount.Add("currency", "INR");
            Dictionary<string, string> userInfo = new Dictionary<string, string>();
            userInfo.Add("custId", "cust_01");
            body.Add("requestType", "Payment");
            body.Add("mid", UniqueKey.TestMerchantID);
            body.Add("websiteName", UniqueKey.Website);
            body.Add("orderId", orderid);
            body.Add("txnAmount", txnAmount);
            body.Add("userInfo", userInfo);
            body.Add("callbackUrl", "https://localhost:44385/TheCodeHub/CallBack");

            string paytmChecksum = Checksum.generateSignature(JsonConvert.SerializeObject(body), UniqueKey.TestMerchantKey);

            head.Add("signature", paytmChecksum);

            requestBody.Add("body", body);
            requestBody.Add("head", head);

            string post_data = JsonConvert.SerializeObject(requestBody);

            //For  Staging
            string url = $"https://securegw-stage.paytm.in/theia/api/v1/initiateTransaction?mid={UniqueKey.TestMerchantID}&orderId={orderid}";

            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);

            webRequest.Method = "POST";
            webRequest.ContentType = "application/json";
            webRequest.ContentLength = post_data.Length;

            using (StreamWriter requestWriter = new StreamWriter(webRequest.GetRequestStream()))
            {
                requestWriter.Write(post_data);
            }

            string responseData = string.Empty;

            using (StreamReader responseReader = new StreamReader(webRequest.GetResponse().GetResponseStream()))
            {
                responseData = responseReader.ReadToEnd();
                Console.WriteLine(responseData);
             
                ViewBag.message = responseData;
            }

            return View("Index");
        }









        public ActionResult Transaction()
        {
            GenerateUniquekeysModel UniqueKey = new GenerateUniquekeysModel();

            Dictionary<String, String> paytmParams = new Dictionary<String, String>();
            /* Find your MID in your Paytm Dashboard at https://dashboard.paytm.com/next/apikeys */
            paytmParams.Add("MID", UniqueKey.TestMerchantID);
            /* Find your WEBSITE in your Paytm Dashboard at https://dashboard.paytm.com/next/apikeys */
            paytmParams.Add("WEBSITE", UniqueKey.Website);
            /* Find your INDUSTRY_TYPE_ID in your Paytm Dashboard at https://dashboard.paytm.com/next/apikeys */
            paytmParams.Add("INDUSTRY_TYPE_ID", "Retail");
            /* WEB for website and WAP for Mobile-websites or App */
            paytmParams.Add("CHANNEL_ID", "WEB");
            /* Enter your unique order id */
            paytmParams.Add("ORDER_ID", orderid);
            /* unique id that belongs to your customer */
            paytmParams.Add("CUST_ID", "455451");
            /* customer's mobile number */
            paytmParams.Add("MOBILE_NO", "8866077896");
            /* customer's email */
            paytmParams.Add("EMAIL", "ashishvishwakarma.vision@gmail.com");

            paytmParams.Add("TXN_AMOUNT", Convert.ToString(Request.Form["Amount"]));

            paytmParams.Add("CALLBACK_URL", "https://localhost:44385/TheCodeHub/CallBack");
            /**
            * Generate checksum for parameters we have
            * You can get Checksum DLL from https://developer.paytm.com/docs/checksum/
            * Find your Merchant Key in your Paytm Dashboard at https://dashboard.paytm.com/next/apikeys 
*/
            String checksum = Paytm.Checksum.generateSignature(paytmParams, UniqueKey.TestMerchantKey);

            Dictionary<string, string> paytmParams1 = new Dictionary<string, string>();

            /* add parameters in Array */
            paytmParams1.Add("MID", UniqueKey.TestMerchantID);
            paytmParams1.Add("ORDER_ID", orderid);

            if (Paytm.Checksum.verifySignature(paytmParams, UniqueKey.TestMerchantKey, checksum))
            {
                Console.WriteLine("Checksum Matched");
            }
            else
            {
                Console.WriteLine("Checksum Mismatched");
            }

            /* for Staging */
            String url = $"https://securegw-stage.paytm.in/order/process?mid={UniqueKey.TestMerchantID}&orderId={orderid}";
           // string url = $"https://securegw-stage.paytm.in/theia/api/v1/initiateTransaction?mid={UniqueKey.TestMerchantID}&orderId={order}";
            /* for Production */
            // String url = "https://securegw.paytm.in/order/process";
            /* Prepare HTML Form and Submit to Paytm */
            String outputHtml = "";
            outputHtml += "<html>";
            outputHtml += "<head>";
            outputHtml += "<title>Merchant Checkout Page</title>";
            outputHtml += "</head>";
            outputHtml += "<body>";
            outputHtml += "<center><h1>Please do not refresh this page...</h1></center>";
            outputHtml += "<form method='post' action='" + url + "' name='paytm_form'>";
            foreach (string key in paytmParams.Keys)
            {
                outputHtml += "<input type='hidden' name='" + key + "' value='" + paytmParams[key] + "'>";
            }
            outputHtml += "<input type='hidden' name='CHECKSUMHASH' value='" + checksum + "'>";
            outputHtml += "</form>";
            outputHtml += "<script type='text/javascript'>";
            outputHtml += "document.paytm_form.submit();";
            outputHtml += "</script>";
            outputHtml += "</body>";
            outputHtml += "</html>";
            return Content(outputHtml.ToString(),"text/html");
        }

        [HttpPost]
        [Route("TheCodeHub/Callback")]
        public IActionResult CallBack()
        {
            String merchantKey = "TujanvnglKF%e7Jp";


            Dictionary<string, string> parameters = new Dictionary<string, string>();
            string paytmChecksum = "";
            bool isChecksumValid = false;
            foreach (string key in Request.Form.Keys)
            {
                parameters.Add(key.Trim(), Convert.ToString(Request.Form[key]).Trim());
            }

            if (parameters.ContainsKey("CHECKSUMHASH"))
            {
                paytmChecksum = parameters["CHECKSUMHASH"];
                parameters.Remove("CHECKSUMHASH");
            }

            if (Paytm.Checksum.verifySignature(parameters, merchantKey, paytmChecksum))
            {
                isChecksumValid = true;
            }
            else
            {
                isChecksumValid = false;
            }

            if (isChecksumValid)
            {
                string transactionStatus = parameters["STATUS"];
                if (transactionStatus == "TXN_SUCCESS")
                {
                    ViewBag.Message = "Payment successful!";
                }
                else
                {
                    ViewBag.Message = parameters["RESPMSG"];
                }
            }
            else
            {
                ViewBag.Message = "Checksum verification failed!";
            }

            return View();
        }
    }
}
