﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Paytm;
using PaytmIntegrationCode.Models;
using System.Net;
using System.Text;

namespace PaytmIntegrationCode.Controllers
{
    public class PaytmTransactionController : Controller
    {
        private const string MERCHANT_KEY = "MKMo2%0SvLS_5z4%";

        public IActionResult Index()
        {
            return View();  
        }

        [HttpPost]
        public IActionResult InitiateTransaction(string mid= "cXzCrh60287769032052", string orderId= "ORDERID_987", string amount = "500", string userId = "CUST_055")
        {
            var paytmParams = new PaytmRequest
            {
                Body = new Body
                {
                    RequestType = "Payment",
                    Mid = mid,
                    WebsiteName = "WEBSTAGING",
                    OrderId = orderId,
                    CallbackUrl = $"https://securegw-stage.paytm.in/theia/paytmCallback?ORDER_ID={orderId}",
                    TxnAmount = new TxnAmount
                    {
                        Value = amount,
                        Currency = "INR"
                    },
                    UserInfo = new UserInfo
                    {
                        CustId = userId
                    }
                }
            };

            string bodyJson = JsonConvert.SerializeObject(paytmParams.Body, Formatting.None, new JsonSerializerSettings { StringEscapeHandling = StringEscapeHandling.EscapeNonAscii });

            string checksum = Checksum.generateSignature(bodyJson, MERCHANT_KEY);

            paytmParams.Head = new Dictionary<string, string>
        {
            { "signature", checksum }
        };

            string post_data = JsonConvert.SerializeObject(paytmParams, Formatting.None, new JsonSerializerSettings { StringEscapeHandling = StringEscapeHandling.EscapeNonAscii });

            string url = $"https://securegw-stage.paytm.in/theia/api/v1/initiateTransaction?mid={mid}&orderId={orderId}";

            string responseData;
            try
            {
                HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
                webRequest.Method = "POST";
                webRequest.ContentType = "application/json";
                webRequest.ContentLength = Encoding.UTF8.GetByteCount(post_data);

                using (StreamWriter requestWriter = new StreamWriter(webRequest.GetRequestStream()))
                {
                    requestWriter.Write(post_data);
                }

                using (StreamReader responseReader = new StreamReader(webRequest.GetResponse().GetResponseStream()))
                {
                    responseData = responseReader.ReadToEnd();
                }

                // Process the response (for now, just print it)
                Console.WriteLine("Response Data: " + responseData);

                return Content(responseData, "application/json");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.Message);
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
