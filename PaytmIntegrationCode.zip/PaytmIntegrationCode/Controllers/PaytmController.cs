﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Paytm;
using System.Net;

namespace PaytmIntegrationCode.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using Newtonsoft.Json;
    using paytm; // Ensure this matches the namespace used in your DLL
    using PaytmIntegrationCode.Models;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Net;
    using System.Security.AccessControl;

    namespace YourNamespace.Controllers
    {
        public class PaytmController : Controller
        {
            public IActionResult Index()
            {
                return View();
            }

            [Route("InitiateTransaction")]
            [Route("/paytm/InitiateTransaction")]
            public IActionResult InitiateTransaction()
            {

                GenerateUniquekeysModel objectdate = new GenerateUniquekeysModel();

                var paytmParams = new Dictionary<string, object>();
                var head = new Dictionary<string, string>();
                var requestBody = new Dictionary<string, object>();

                var txnAmount = new Dictionary<string, string>
                {
                    { "value", "500.00" },
                    { "currency", "INR" }
                };
                var userInfo = new Dictionary<string, string>
                {
                    { "custId", "CUST_001" }
                };
                paytmParams.Add("requestType", "Payment");
                paytmParams.Add("mid", objectdate.TestMerchantID);
                paytmParams.Add("websiteName", "WEBSTAGING");
                paytmParams.Add("orderId", "ORDERID_98765");
                paytmParams.Add("txnAmount", txnAmount);
                paytmParams.Add("userInfo", userInfo);
                paytmParams.Add("callbackUrl", "https://localhost:44385/paytm/Callback");

                string body = JsonConvert.SerializeObject(paytmParams);

                // Generate checksum
                string paytmChecksum = CheckSum.generateCheckSum( objectdate.TestMerchantKey, body);
                head.Add("signature", paytmChecksum);

                requestBody.Add("body", paytmParams);
                requestBody.Add("head", head);

                string post_data = JsonConvert.SerializeObject(requestBody);

                //For  Staging
                string url = $"https://securegw-stage.paytm.in/theia/api/v1/initiateTransaction?mid={objectdate.TestMerchantID}&orderId=ORDERID_98765";

                try
                {
                    // Making a POST request
                    HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);

                    webRequest.Method = "POST";
                    webRequest.ContentType = "application/json";
                    webRequest.ContentLength = post_data.Length;
                   

                    using (StreamWriter requestWriter = new StreamWriter(webRequest.GetRequestStream()))
                    {
                        requestWriter.Write(post_data);
                    }

                    string responseData;
                    using (StreamReader responseReader = new StreamReader(webRequest.GetResponse().GetResponseStream()))
                    {
                        responseData = responseReader.ReadToEnd();
                        Console.WriteLine(responseData);

                        // Deserialize response for better diagnostics
                        var responseObj = JsonConvert.DeserializeObject<Dictionary<string, object>>(responseData);
                        if (responseObj.ContainsKey("body"))
                        {
                            var bodyObj = responseObj["body"] as Dictionary<string, object>;
                            if (bodyObj != null && bodyObj.ContainsKey("resultInfo"))
                            {
                                var resultInfo = bodyObj["resultInfo"] as Dictionary<string, object>;
                                if (resultInfo != null)
                                {
                                    Console.WriteLine($"Result Status: {resultInfo["resultStatus"]}");
                                    Console.WriteLine($"Result Code: {resultInfo["resultCode"]}");
                                    Console.WriteLine($"Result Message: {resultInfo["resultMsg"]}");
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Exception: " + ex.Message);
                }

                return View("Index");
            }

            [HttpPost]
            [Route("/paytm/Callback")]
            public IActionResult Callback()
            {
                GenerateUniquekeysModel objectdate = new GenerateUniquekeysModel();
                try
                {
                    Dictionary<string, string> paytmParams = new Dictionary<string, string>();
                    foreach (var key in Request.Form.Keys)
                    {
                        var value = Request.Form[key].ToString().Trim();
                        paytmParams.Add(key.Trim(), value);
                    }

                    string paytmChecksum = paytmParams["CHECKSUMHASH"];
                    paytmParams.Remove("CHECKSUMHASH");


                    bool isValidChecksum = CheckSum.verifyCheckSum(objectdate.TestMerchantKey, paytmParams, paytmChecksum);

                    if (isValidChecksum)
                    {
                        // Process the transaction details from paytmParams
                        // Handle your business logic here
                        Console.WriteLine("Checksum is valid.");
                    }
                    else
                    {
                        Console.WriteLine("Checksum is invalid.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Exception: " + ex.Message);
                }
                return View();
            }
        }
    }

}
