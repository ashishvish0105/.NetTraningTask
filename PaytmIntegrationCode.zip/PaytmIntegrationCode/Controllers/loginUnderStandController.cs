﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Paytm;
using PaytmIntegrationCode.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;

namespace PaytmIntegrationCode.Controllers
{
    public class loginUnderStandController : Controller
    {


        public IActionResult Index()
        {
            return View();
        }

        [Route("InitiateTransaction")]
        [Route("/loginUnderStand/InitiateTransaction")]
        public IActionResult InitiateTransaction()
        {
            a();
            GenerateUniquekeysModel generateUniquekeysModel = new GenerateUniquekeysModel();
            Body bodyData = new Body();
            UserInfo UserInfo = new UserInfo();

            var paytmParams = new Dictionary<string, object>();
            var head = new Dictionary<string, string>();
            var requestBody = new Dictionary<string, object>();

            Dictionary<string, string> txnAmount = new Dictionary<string, string>();
            txnAmount.Add("value", "1.00");
            txnAmount.Add("currency", "INR");

            var userInfo = new Dictionary<string, string>();
            userInfo.Add("custId", UserInfo.CustId);
            userInfo.Add("mobile", "5555566666");
            userInfo.Add("email", "test555666@paytm.com");
            userInfo.Add("firstName", "test");
            userInfo.Add("lastName", "testlastName");

            paytmParams.Add("requestType", "Payment");
            paytmParams.Add("mid", generateUniquekeysModel.TestMerchantID);
            paytmParams.Add("orderId", bodyData.OrderId);
            paytmParams.Add("callbackUrl", "https://localhost:44385/loginUnderStand/Callback");
            paytmParams.Add("websiteName", "WEBSTAGING");
            paytmParams.Add("txnAmount", txnAmount);

            string body = JsonConvert.SerializeObject(paytmParams);

            // Generate checksum
            string paytmChecksum = Checksum.generateSignature(body, generateUniquekeysModel.TestMerchantKey);

            head.Add("signature", paytmChecksum);
            head.Add("version", "v1");
            head.Add("channelId", "WEB");

            requestBody.Add("body", paytmParams);
            requestBody.Add("head", head);

            string post_data = JsonConvert.SerializeObject(requestBody);

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://securegw-stage.paytm.in/theia/api/v1/initiateTransaction");
                var request = new HttpRequestMessage(HttpMethod.Post, $"?mid={generateUniquekeysModel.TestMerchantID}&orderId={bodyData.OrderId}");
                request.Content = new StringContent(post_data, Encoding.UTF8, "application/json");

                try
                {
                    var response = client.SendAsync(request).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        var responseData = response.Content.ReadAsStringAsync().Result;

                        Console.WriteLine("Response Data: " + responseData);
                        ViewBag.message = responseData;

                        ResponseResultModel responseObject = JsonConvert.DeserializeObject<ResponseResultModel>(responseData);

                        if (responseObject.Body.ResultInfo.ResultMsg == "Success")
                        {
                            ShowPaymentPage(generateUniquekeysModel.TestMerchantID, bodyData.OrderId, "demoText");
                        } 

                    }
                    else
                    {
                        Console.WriteLine("Error: " + response.StatusCode);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Exception: " + ex.Message);
                }
            }

            return View("Index");
        }


        [HttpPost("loginUnderStand/InitiateSubscriptionAPI")]
        public IActionResult InitiateSubscriptionAPI()
        {
            GenerateUniquekeysModel generateUniquekeysModel = new GenerateUniquekeysModel();
            Body bodyData = new Body();
            UserInfo UserInfo = new UserInfo();

            Dictionary<string, object> body = new Dictionary<string, object>();
            Dictionary<string, string> head = new Dictionary<string, string>();
            Dictionary<string, object> requestBody = new Dictionary<string, object>();

            Dictionary<string, string> txnAmount = new Dictionary<string, string>
            {
                { "value", "1.00" },
                { "currency", "INR" }
            };

            Dictionary<string, string> userInfo = new Dictionary<string, string>
            {
                { "custId", "CUST_001" }
            };
                    
            body.Add("requestType", "NATIVE_SUBSCRIPTION");
            body.Add("mid", generateUniquekeysModel.TestMerchantID);
            body.Add("websiteName", "WEBSTAGING");
            body.Add("orderId", bodyData.OrderId);
            body.Add("subscriptionAmountType", "FIX");
            body.Add("subscriptionFrequencyUnit", "MONTH");
            body.Add("subscriptionExpiryDate", "2031-05-20");
            body.Add("subscriptionEnableRetry", "1");
            body.Add("txnAmount", txnAmount);
            body.Add("userInfo", userInfo);
            body.Add("callbackUrl", "https://localhost:44385/loginUnderStand/Callback");

            // Generate the checksum
            string paytmChecksum = Checksum.generateSignature(JsonConvert.SerializeObject(body), generateUniquekeysModel.TestMerchantKey);

            head.Add("signature", paytmChecksum);

            requestBody.Add("body", body);
            requestBody.Add("head", head);

            string post_data = JsonConvert.SerializeObject(requestBody);

            string url = $"https://securegw-stage.paytm.in/subscription/create?mid={generateUniquekeysModel.TestMerchantID}&orderId={bodyData.OrderId}";

            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
            webRequest.Method = "POST";
            webRequest.ContentType = "application/json";
            webRequest.ContentLength = post_data.Length;

            using (StreamWriter requestWriter = new StreamWriter(webRequest.GetRequestStream()))
            {
                requestWriter.Write(post_data);
            }

            string responseData = string.Empty;

            try
            {
                using (StreamReader responseReader = new StreamReader(webRequest.GetResponse().GetResponseStream()))
                {
                    responseData = responseReader.ReadToEnd();
                    ViewBag.message = responseData;
                    Console.WriteLine(responseData);
                }
            }
            catch (WebException ex)
            {
                Console.WriteLine("Error: " + ex.Message);
                Console.WriteLine("Status Code: " + ((HttpWebResponse)ex.Response).StatusCode);
            }

            return View("Index");
        }

        [HttpPost]
        [Route("loginUnderStand/Callback")]
        public IActionResult Callback()
        {
            GenerateUniquekeysModel generateUniquekeysModel = new GenerateUniquekeysModel();
            try
            {
                Dictionary<string, string> paytmParams = new Dictionary<string, string>();
                foreach (var key in Request.Form.Keys)
                {
                    var value = Request.Form[key].ToString().Trim();
                    paytmParams.Add(key.Trim(), value);
                }

                string paytmChecksum = paytmParams["CHECKSUMHASH"];
                paytmParams.Remove("CHECKSUMHASH");

                bool isValidChecksum = Checksum.verifySignature(paytmParams, generateUniquekeysModel.TestMerchantKey, paytmChecksum);

                if (isValidChecksum)
                {
                    // Process the transaction details from paytmParams
                    // Handle your business logic here
                    Console.WriteLine("Checksum is valid.");
                }
                else
                {
                    Console.WriteLine("Checksum is invalid.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.Message);
            }
            return View();
        }


        public IActionResult ShowPaymentPage(string mid, string orderId, string txnToken)
        {
            string Url = $"https://securegw-stage.paytm.in/theia/api/v1/showPaymentPage?mid={mid}&orderId={orderId}";

            string htmlContext = $@"
        <html>
            <head>
                <title>Show Payment Page</title>
            </head>
            <body>
                <center>
                    <h1>Please do not refresh this page...</h1>
                </center>
                <form method='post' action='{Url}' name='paytm'>
                    <table border='1'>
                        <tbody>
                            <input type='hidden' name='mid' value='{mid}'>
                            <input type='hidden' name='orderId' value='{orderId}'>
                            <input type='hidden' name='txnToken' value='{txnToken}'>
                        </tbody>
                    </table>
                    <script type='text/javascript'> document.paytm.submit(); </script>
                </form>
            </body>
        </html>";

            return Content(htmlContext, "text/html");
        }

        public void a()
        {
            Dictionary<string, object> body = new Dictionary<string, object>();
            Dictionary<string, string> head = new Dictionary<string, string>();
            Dictionary<string, object> requestBody = new Dictionary<string, object>();

            Dictionary<string, string> txnAmount = new Dictionary<string, string>();
            txnAmount.Add("value", "1.00");
            txnAmount.Add("currency", "INR");
            Dictionary<string, string> userInfo = new Dictionary<string, string>();
            userInfo.Add("custId", "cust_001");
            body.Add("requestType", "Payment");
            body.Add("mid", "cXzCrh60287769032052");
            body.Add("websiteName", "WEBSTAGING");
            body.Add("orderId", "ORDERID_98765");
            body.Add("txnAmount", "100");
            body.Add("userInfo", userInfo);
            body.Add("callbackUrl","https://localhost:44385/");


            /*
            * Generate checksum by parameters we have in body
            * Find your Merchant Key in your Paytm Dashboard at https://dashboard.paytm.com/next/apikeys 
            */
            string paytmChecksum = Checksum.generateSignature(JsonConvert.SerializeObject(body), "TujanvnglKF%e7Jp");

            head.Add("signature", paytmChecksum);

            requestBody.Add("body", body);
            requestBody.Add("head", head);

            string post_data = JsonConvert.SerializeObject(requestBody);

            //For  Staging
            string url = "https://securegw-stage.paytm.in/theia/api/v1/initiateTransaction?mid=cXzCrh60287769032052&orderId=ORDERID_98765";

            //For  Production 
            //string  url  =  "https://securegw.paytm.in/theia/api/v1/initiateTransaction?mid=YOUR_MID_HERE&orderId=ORDERID_98765";

            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);

            webRequest.Method = "POST";
            webRequest.ContentType = "application/json";
            webRequest.ContentLength = post_data.Length;

            using (StreamWriter requestWriter = new StreamWriter(webRequest.GetRequestStream()))
            {
                requestWriter.Write(post_data);
            }

            string responseData = string.Empty;

            using (StreamReader responseReader = new StreamReader(webRequest.GetResponse().GetResponseStream()))
            {
                responseData = responseReader.ReadToEnd();
                Console.WriteLine(responseData);
            }

        }
    }
}
