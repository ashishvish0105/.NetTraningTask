﻿namespace PaytmIntegrationCode.Models
{
    public class ResponseHead
    {
        public string RequestId { get; set; }
        public long ResponseTimestamp { get; set; }
        public string Version { get; set; }
    }

    public class ResponseResultInfo
    {
        public string ResultStatus { get; set; }
        public string ResultCode { get; set; }
        public string ResultMsg { get; set; }
    }

    public class ResponseBody
    {
        public object ExtraParamsMap { get; set; }
        public ResponseResultInfo ResultInfo { get; set; }
    }

    public class ResponseResultModel
    {
        public ResponseHead Head { get; set; }
        public ResponseBody Body { get; set; }
    }

}
