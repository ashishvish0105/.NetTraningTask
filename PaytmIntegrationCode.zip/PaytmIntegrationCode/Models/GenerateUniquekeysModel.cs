﻿namespace PaytmIntegrationCode.Models
{
    public class GenerateUniquekeysModel
    {
        public string? TestMerchantID { get; set; }
        public string? TestMerchantKey { get; set; }
        public string? Website { get; set; }
        public string? IndustryType { get; set; }

        public GenerateUniquekeysModel()
        {
            TestMerchantID = "cXzCrh60287769032052";
            TestMerchantKey = "TujanvnglKF%e7Jp";
            Website = "WEBSTAGING";
            IndustryType = "Retail";
        }
    }
    public class TxnAmount
    {
        public string Value { get; set; }
        public string Currency { get; set; }
    }

    public class UserInfo
    {
        public string? CustId { get; set; }

       public UserInfo()
        {
            Random random = new Random();
            int randomNumber = random.Next(1000, 9999);
            CustId = "cus-" + randomNumber;
        }
    }

    public class Body
    {
        public string? RequestType { get; set; }
        public string? Mid { get; set; }
        public string? WebsiteName { get; set; }
        public string? OrderId { get; set; }
        public string? CallbackUrl { get; set; }
        public TxnAmount? TxnAmount { get; set; }
        public UserInfo UserInfo { get; set; }
        public Body()
        {
            Random random = new Random();
            int randomNumber = random.Next(1000,9999);
            string orderid = "order-"+randomNumber;
            OrderId = orderid;

        }
    }

    public class PaytmRequest
    {
        public Body Body { get; set; }
        public Dictionary<string, string> Head { get; set; }
    }

}
