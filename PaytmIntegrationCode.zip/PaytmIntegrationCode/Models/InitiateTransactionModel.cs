﻿namespace PaytmIntegrationCode.Models
{
    public class InitiateTransactionModel
    {
        public string? channelId { get; set; }
        public string? version { get; set; }
        public string? requestTimestamp { get; set; }
        public string? signature { get; set; }
    }


    public class userInfo
    {
        public string custId { get; set; }
        public string mobile { get; set; }
        public string email { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }

        public userInfo()
        {
            custId = "CUST_001";
            mobile = "9988000000";
            email = "vaibhav41094@gmail.com";
            firstName = "vaibhav";
            lastName = "sharma";
        }
    }
    public class GenerateUniqueKeysModel
    {
        public string? TestMerchantID { get; set; }
        public string? TestMerchantKey { get; set; }
        public string? Website { get; set; }
        public string? WEBSTAGING { get; set; }
        public string? IndustryType { get; set; }
        public string? Retail { get; set; }

        public GenerateUniqueKeysModel()
        {
            TestMerchantID = "cXzCrh60287769032052";
            TestMerchantKey = "TujanvnglKF%e7Jp";
            Website = "WEBSTAGING";
            WEBSTAGING = "Retail";
            IndustryType = "WEB";
        }
    }
    public class RequestAttributesBodyModel()
    {
        public string? requestType { get; set; }
        public string? mid { get; set; }
        public string? orderId { get; set; }
        public string? callbackUrl { get; set; }
        public string? websiteName { get; set; }
        public userInfo? userInfo { get; set; }
        public GenerateUniqueKeysModel? GenerateUniqueKeysValue { get; set; }

       
    }

}
