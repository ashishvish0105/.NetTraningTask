﻿using System.Transactions;

namespace PaytmIntegrationCode.Models
{
    public class NewWayPaytemPaymentModel
    {

    }
}
