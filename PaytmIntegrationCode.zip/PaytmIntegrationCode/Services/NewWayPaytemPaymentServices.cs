﻿using PaytmIntegrationCode.Models;

namespace PaytmIntegrationCode.Services
{
    public class NewWayPaytemPaymentServices
    {

        //public string CheckSumReturn(string paytmParams, string TestMerchantKey)
        //{
        //    //GenerateUniqueKeysModel generateUniqueKeysModel = new GenerateUniqueKeysModel();
        //    //Dictionary<string, string> paytmParams = new Dictionary<string, string>();

        //    //paytmParams.Add("MID", generateUniqueKeysModel.TestMerchantID);
        //    //paytmParams.Add("ORDER_ID", OrderId);

        //    String paytmChecksum = Paytm.Checksum.generateSignature(paytmParams, TestMerchantKey);
        //    bool verifySignature = Paytm.Checksum.verifySignature(paytmParams, TestMerchantKey, paytmChecksum);

        //    //Console.WriteLine("generateSignature Returns: " + paytmChecksum);
        //    //Console.WriteLine("verifySignature Returns: " + verifySignature + Environment.NewLine);
        //    if (verifySignature)
        //    {
        //        return paytmChecksum;
        //    }
        //    else
        //    {
        //        return "paytmChecksum is not vailid";
        //    }

        //}

        //public string InitializeJSONCheckSumReturn(string OrderId = "ORDERID_98765")
        //{
        //    GenerateUniqueKeysModel generateUniqueKeysModel = new GenerateUniqueKeysModel();
        //    string body = "{\"mid\":\""+generateUniqueKeysModel.TestMerchantID+"\",\"orderId\":\"" + OrderId + "\"}";

        //    String paytmChecksum = Paytm.Checksum.generateSignature(body, generateUniqueKeysModel.TestMerchantKey);
        //    bool verifySignature = Paytm.Checksum.verifySignature(body, generateUniqueKeysModel.TestMerchantKey, paytmChecksum);

        //    //Console.WriteLine("generateSignature Returns: " + paytmChecksum);
        //    //Console.WriteLine("verifySignature Returns: " + verifySignature + Environment.NewLine);

        //    if (verifySignature)
        //    {
        //        return paytmChecksum;
        //    }
        //    else
        //    {
        //        return "paytmChecksum is not vailid";
        //    }
        //}
    }
}
