﻿namespace WindowsServiceImageCopyPast
{
    partial class ProjectInstaller
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ImageCopyPastInstallerProcess = new System.ServiceProcess.ServiceProcessInstaller();
            this.ImageCopyPastInstaller = new System.ServiceProcess.ServiceInstaller();
            // 
            // ImageCopyPastInstallerProcess
            // 
            this.ImageCopyPastInstallerProcess.Account = System.ServiceProcess.ServiceAccount.LocalService;
            this.ImageCopyPastInstallerProcess.Password = null;
            this.ImageCopyPastInstallerProcess.Username = null;
            // 
            // ImageCopyPastInstaller
            // 
            this.ImageCopyPastInstaller.Description = "For Image Copy Past Other Folder";
            this.ImageCopyPastInstaller.DisplayName = "ImageCopyPastInstaller";
            this.ImageCopyPastInstaller.ServiceName = "ImageCopyPastInstaller";
            this.ImageCopyPastInstaller.StartType = System.ServiceProcess.ServiceStartMode.Automatic;
            // 
            // ProjectInstaller
            // 
            this.Installers.AddRange(new System.Configuration.Install.Installer[] {
            this.ImageCopyPastInstallerProcess,
            this.ImageCopyPastInstaller});

        }

        #endregion

        private System.ServiceProcess.ServiceProcessInstaller ImageCopyPastInstallerProcess;
        private System.ServiceProcess.ServiceInstaller ImageCopyPastInstaller;
    }
}