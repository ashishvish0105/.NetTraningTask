﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace WindowsServiceImageCopyPast
{
    public partial class ImageCopyPast : ServiceBase
    {
        public Timer ScheduleCopyPastImage;
        public ImageCopyPast()
        {
            //InitializeComponent();
            ScheduleCopyPastImageMethod("e");
        }

        protected override void OnStart(string[] args)
        {
            ScheduleCopyPastImageServices();
        }
 
        protected override void OnStop()
        {
            ScheduleCopyPastImage.Dispose();
        }

        public void ScheduleCopyPastImageServices()
        {
            try
            {
                ScheduleCopyPastImage = new Timer(new TimerCallback(ScheduleCopyPastImageMethod));

                DateTime now = DateTime.Now;
                DateTime targetTime = DateTime.Parse(now.ToString("yyyy-MM-dd") + " 5:09 PM");

                if (targetTime <= now)
                {
                    targetTime = targetTime.AddDays(1);
                }   

                TimeSpan timeSpan = targetTime.Subtract(now);
                int dueMilli = Convert.ToInt32(timeSpan.TotalMilliseconds);

                //int periodMilli = 24 * 60 * 60 * 1000;

                int periodMilli = 1 * 60 * 1000;


                if (dueMilli < 0 || dueMilli > Int32.MaxValue)
                {
                    logFileCreate($"dueMilli must be non-negative and less than or equal to Int32.MaxValue, DueMilli = {dueMilli} & DueMilli={dueMilli}.");
                }

                ScheduleCopyPastImage.Change(dueMilli, periodMilli);

                logFileCreate($"Scheduled task to run first at: {targetTime}. Subsequent calls every {periodMilli/(60*1000)} min.");
            }
            catch (Exception ex)
            {
                logFileCreate("Error setting up daily schedule: " + ex.Message);
            }
        }

        private void ScheduleCopyPastImageMethod(object state)
        {
            logFileCreate(DateTime.Now + " - Running scheduled task.");
            try
            {
                //string projectName = Assembly.GetCallingAssembly().GetName().Name;
                string projectName = "WindowsServiceImageCopyPast";
                string BaseDirectory = AppDomain.CurrentDomain.BaseDirectory;

                var slipdata = BaseDirectory.Split('\\');
                var index = Array.IndexOf(slipdata, projectName.ToString());
                string getProjectPath = "";

                if (index != -1)
                {
                    getProjectPath = string.Join("\\", slipdata, 0, index + 1);
                }
                else
                {
                    logFileCreate("Folder not found in the path.");
                    return;
                }


                string imagePath = Path.Combine(getProjectPath, "Folder1");
                string pastImagePath = Path.Combine(getProjectPath, "Folder2\\");
                string[] files = Directory.GetFiles(imagePath);


                if (!files.Any())
                {
                    logFileCreate("not avaible image in the Folder1");
                }

                if (!Directory.Exists(pastImagePath))
                {
                    Directory.CreateDirectory(pastImagePath);
                }

                List<string> extensions =new List<string> { ".jpg", ".JPG", ".png", ".PNG", ".jpeg", ".JPEG" };

                foreach (var item in files)
                {
                    string fileExtension = Path.GetExtension(item);

                    if (extensions.Contains(fileExtension))
                    {
                        string targetFilePath = Path.Combine(pastImagePath, Path.GetFileName(item));
                        File.Copy(item, targetFilePath, true);

                        logFileCreate("Successfully copied image to " + targetFilePath);
                    }

                    

                    //File.Copy(item, pastImagePath + Path.GetFileName(item));
                    //logFileCreate("Successfully copied image to " + item);
                }

                //string targetFilePath = Path.Combine(pastImagePath, Path.GetFileName(imagePath));
                //File.Copy(imagePath, targetFilePath, true);

                //logFileCreate("Successfully copied image to " + targetFilePath);
            }
            catch (Exception ex)
            {
                logFileCreate("Failed to copy image: " + ex.Message);
            }
        }


        public static void logFileCreate(string message)
        {
            StreamWriter sw = null;
            try
            {
                sw = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "\\LogFile.txt", true);
                sw.WriteLine(DateTime.Now.ToString() + ":-" + message);
                sw.Flush();
                sw.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        public void OnDebug()
        {
            OnStart(null);
        }
    }
}
